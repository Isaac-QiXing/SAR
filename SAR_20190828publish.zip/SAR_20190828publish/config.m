function config()
% set the values of parameters of C-Ranker

thresh_nnz_beta = 0.2;

% assign the callers the variables
varName = whos();
varName_c = {varName.name};
for ii = 1:length(varName_c)
    varName = varName_c{ii};
    assignin('caller',varName,eval(varName));
end

end
