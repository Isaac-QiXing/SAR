function v1 = rowVec(v)
% reshape a matrix or (numeric or cell) vector to a row (or cell) vector 

if isRowVector(v)
    v1 = v;
elseif isvector(v) % v is a vector but not a row vector
    v1 = v';
else % v is not a vector    
    v1 = reshape(v,1,numel(v));    
end