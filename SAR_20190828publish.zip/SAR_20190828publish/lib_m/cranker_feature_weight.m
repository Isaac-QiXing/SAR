function [weight varargout] = foapl_feature_weight(dataFile,varargin)
% solve the feature weights
% Inputs:
%   dataFile: mat file name  containing	
%       X:  a data matrix with each row representing a sample;
%       y:  a column vector consisting the labels (1 or -1) of the samples;   
%  varargin: the names and values of arguments of for solving the feature
%        weights;
%    varargin{2*i-1}: a string, the argument name;
%    varargin{2*i}: the argument value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows:
%    'X': Optional, the matrix X;
%    'y': Optional, column vector y; 'X' and 'y' are necessary  if
%           dataFile is not set; if both 'X', 'y' and dataFile is set,
%           only 'X', 'y' is effective;
%    'c': Optional, a positive scalar indicating the weight for training
%           error of SVM;
%    'num_submodel': Optional, a positive integer indicating the number of 
%           sub-models;
%    'maxTrainSize': Optional, indicating the maximum number of samples
%           for training the sub-models;
% Outputs:
%    weight: a column vector, indicating the calculated weights of the
%       features, its length equal the number of column number of matrix X;
%       Note that, the feature weights corresponds to the ``standard''
%           kernel argument value: r1 = 1.0;
%    varargout{1}: a column vector, with same size as weight, indicating 
%       the variance of the observed value of the feature weight by the
%       sub-models;
%    varargout{2}: a matrix with NUM_SUBMODEL column, each column
%       consisting of the indices of the samples in a sub-model;
% Usage:
%  e.g.  w = foapl_feature_weight([],'X',X,'y',y);

% assign the arguments to a structure
arg = [];
len_arg = length(varargin); 
if len_arg>0
    arg = assignStruct('', varargin(1:2:len_arg),varargin(2:2:len_arg));
end
% complete the arguments with default values
[c,  num_submodel, maxTrainSize, negative_rate,rate_trim,verbose] = ...
    problemArg('c','num_submodel_feature_weight',...
                   'maxTrainSize_feature_weight',...
                   'negative_rate_feature_weight',...
                   'rate_trim_feature_weight','verbose');
arg = completeArg(arg, {'X','y','c','num_submodel','maxTrainSize'},...
                       {[],[],   c,  num_submodel, maxTrainSize});

% check input data
flag_dataFile_effective = 0; % whether dataFile is effective
if isempty(arg.X) || isempty(arg.y)
    if ~isempty(dataFile)        
        flag_dataFile_effective = 1;
    else
        error('Either X, y or dataFile is required to set.');
    end
end

% solve feature weights

sampleFile = sprintf('./sampleFile_feature_weight-%s.mat',datestr(now,30));
argAlg = struct('dataFile',sampleFile,'c',arg.c);

% print progress information
if verbose ==1|| verbose==2
    printProgress(0);
end

for k=1:arg.num_submodel
    % sample a certain number of positive and negative samples randomly
	if flag_dataFile_effective
        ind_v = sampleData(dataFile,[],[],sampleFile,arg.maxTrainSize,...
            negative_rate); 
    else
        ind_v = sampleData('',arg.X,arg.y,sampleFile,arg.maxTrainSize,...
            negative_rate);
    end
    % save the indices
    if nargout>2 % put out the indices of the samples in the submodels
        if k==1
            % initialize Ind to store the indices
        	Ind = zeros(length(ind_v),arg.num_submodel);
        end
        Ind(:,k) = ind_v;
    end
    % solve the submodel to get the feature weights     
    tic
        weight_v = feature_weight_SVM(argAlg);
    t = toc;
    if verbose==1 || verbose==2
        printProgress(1,arg.num_submodel);
    elseif verbose>=3
        fprintf(' %d-th submodel of feature weight. Elapsed time: %.1fs.\n',k,t);
    end 
    if verbose >= 3
        fwritef(1,' feature weights:',weight_v','');
    end
    % store the feature weights
    if k==1
        % initialize matrix Weight_mat  to store the feature weights
        Weight_mat = zeros(length(weight_v),arg.num_submodel);
    end
    Weight_mat(:,k) = weight_v;
end

% put out
n_trim = round(arg.num_submodel*rate_trim);
weight = midmean(Weight_mat,[n_trim,n_trim],2); 
if nargout>1
    varargout{1} = std(Weight_mat,0,2);
        % the standard variance of the feature weights
end
if nargout>2
    varargout{2} = Weight_mat;
end

% delete the sampleFile
if exist(sampleFile,'file')
    delete(sampleFile);
end

end
