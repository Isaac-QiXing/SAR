function Num = Date2Num(dateFormat)
% Transform the dateFormat format into decimal number, Date2Num(2011/10/20)  ==>> 0.5 (10/20=0.5)   
% Argument
% Inputs
%       dateFormat: the date in 2011/10/20,11/33 format or 2011-10-20, 11/33
% Outputs
%        Num: the decimal number transformd from dateFormat, e.g. 0.5  or 0.3 
%      

% Email: bebetter@mail.dlut.edu.cn  Oct 20, 2011. in DUT.

char_split = '/'; % character to split the peptide array
p_array = strfind(dateFormat,char_split);

% get the position of the char_split
len_p_array = length(p_array);
if len_p_array==0
    char_split = '-'; % character to split the peptide array
    p_array = strfind(dateFormat,char_split);

    % get the position of the char_split
    p_l = p_array(1);
    p_r = p_array(2);    
    leftNum = str2double(dateFormat(p_l+1:p_r-1));
    rightNum = str2double(dateFormat(p_r+1:end));
end


if len_p_array==1
    p_l = p_array(1);
    leftNum = str2double(dateFormat(1:p_l-1));
    rightNum = str2double(dateFormat(p_l+1:end));
end
if len_p_array==2
    p_l = p_array(1);
    p_r = p_array(2);
    leftNum = str2double(dateFormat(p_l+1:p_r-1));
    rightNum = str2double(dateFormat(p_r+1:end));
end
Num = min(leftNum,rightNum)/max(leftNum,rightNum);

