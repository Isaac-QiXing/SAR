function [d,varargout]= dist_normal_cone_box(g,alpha_v, A_v,B_v)
% calculate the distance of a vector g to the normal cone N_X(alpha_v) at alpha_v of a
% box set 
%   X = { x in R^n  | A_i <= x_i <= B_i, i=1,...,n }
% Inputs:
%   g: a n-by-1 vector
%   alpha_v: a n-by-1 vector
%   A_v, B_v: n-by-1 vectors indicating the box set X
% outputs:
%  d:  a scalar of the distance  
% varargout{1}: Optional, a n-by-1 vector consisting of the distances of each coordinate of g to N_X(alpha_v) 
%       satisfying   d = norm(varargout{1})

tol = 1.0E-5; 

if   max( A_v-alpha_v)>tol || max(alpha_v-B_v)>tol
    d = Inf; % alpha not in X
    return
end

d_v = abs(g); 

d_v(abs(alpha_v - A_v)<=tol & g<=0) = 0; 
d_v(abs(alpha_v - B_v)<=tol & g>=0) = 0; 

d = norm(d_v,2); 
if nargout>1
    varargout{1} = d_v;
end

end