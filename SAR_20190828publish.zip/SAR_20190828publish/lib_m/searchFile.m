function [ind fileName_found inform] = searchFile(fileName,dir_c,arg)
% search file in specified directories (find one occurence)
% 
% Inputs:
%  fileName: a string indicating the file to search; a directory can be
%     contained in this fileName;
%  dir_c: a cell array (column array) containing directories to search;
%  arg: a struct, optional,
%    .ext: a string, specify forcibly the extension of the file to search,
%       regardless the extenstion contained in the fileName;
%       it is started with dot '.' character,  a correct extension 
%       can be specified, for example, as '.mat', '.doc' or '.txt'.
%       default value: ''
%
% Outputs:
%  ind: the index of the directory where the file first occurs; 
%   -1: the file has not been found in the specified directories or in the
%       directory contained in the fileName (if any);  
%    0: the file is found in current directory or in the directory (if any)
%       contained in the fileName; 
%    1, 2 or 3,...: the file exists in the directory dir_c{i}, i=1,2,3,...
%  fileName_found: full name of the found file, including the full directory; 
%     it is empty string if the file is not found, 
%  inform: a struct
%   .ext: 1, 0 ,-1 or []
%    []:  if arg.ext is not specified or empty;
%      Otherwise, if arg.ext is specified and not empty, inform.ext has the
%      following values;
%    1:  the extension of the given file name match the specified
%            extension: arg.ext
%    -1: the extension of the given file name do not match the specified
%            extension: arg.ext
%    0:  the given file name do not specified extension;
%  .existDir: 1 or 0, whether there exists directory in the fileName string;

% set parameter arg
if nargin<=2
    arg = struct();
end
if ~isfield(arg,'ext') 
    arg.ext = '';
end
% reset the starting character of arg.ext
arg.ext = strtrim(arg.ext);
if ~isempty(arg.ext) && arg.ext(1)~= '.'
    arg.ext = ['.' arg.ext]; % add '.' as the starting character
end

% initial the outputs
fileName_found = '';
inform = struct('ext',[],'existDir',[]);
ind = -1;

[path_user,name_user,ext_user] = fileparts(fileName);

% check arg.ext
if isempty(arg.ext)
    inform.ext = [];
else
    if isempty(ext_user)
        inform.ext = 0;
    else
        if strcmpi(arg.ext,ext_user);
            inform.ext = 1;
        else
            inform.ext = -1;
        end
    end    
end

% deal with the path contained in the fileName (if any)
n_dir_c = length(dir_c);
if isempty(path_user) % there is no file path contained in the dataFile 
	inform.existDir = 0;    
    path_user = '.'; % current directory
else
    inform.existDir = 1;    
end

% inseart the path contained in the fileName as the 1st element of dir2_c
n_dir_c = n_dir_c + 1;
dir2_c = cell(n_dir_c,1); % note that dir_c is a column array
dir2_c{1} = path_user;
dir2_c(2:n_dir_c) = dir_c;

% deal with the specified extension
ext_str = '';
if ~isempty(arg.ext)
    ext_str =  arg.ext;
elseif ~isempty(ext_user)
    ext_str = ext_user;
end

% search the file
for ii=1:n_dir_c
    fileName_s =  [addFileSep(dir2_c{ii})  name_user ext_str];
    if exist(fileName_s,'file'); % search the file directly
        ind = ii-1; 
        fileName_found = fileName_s;
        break; % find the first occurance;
    end   
end

end