function [model,ite_inf] = targetRank_CCCP(argData,argAlg)
% Identify the reliable targets by solving the FoApL model by CCCP
%
% Inputs 
%  argData: the argument structure about data
%   .X: matrix of n-by-m, each row consists a sample, i.e.
%          X consists of n samples and m characteristics;
%   .y: a column vector with length n, consisting the label of the samples;
%     1: the targets, -1: decoys
%   .dataFile: Optional, data file name, containing the variable of 
%       X: the same meaning as arg.X
%       y: the same meaning as arg.y
%       sizeX: a 2-by-1 vector, inicating the number of rows and columns of
%         data matrix X
%       Users can set arg.X and arg.y, or   arg.dataFile; but for large scale
%       problem, arg.dataFile is recommended for efficiency use of memory;
%  argAlg: the argument structure about algorithm;
%   .w: Optional, a vector of feature weights, with length equal the number
%       of features; default []: all features are set weight 1.0;
%    .cp
%    .cu 
%   .svm_theta_solver:
%   .mu_pos
%   .mu_neg
%   .r1:
%   .verbose:
%
%   
% Outputs
%  model: the model structure
%   .alpha,  a column vector of the weights if 'svm_theta_solver' == 'CCCP_online'  
%       while  'svm_theta_solver' == 'CCCP_online', model.alpha is a matrix 
%       consisting of the solutions of each submodel 
%   .b:  a scalar if   'svm_theta_solver' == 'CCCP_online'  
%       while  'svm_theta_solver' == 'CCCP_online', model.b is a vector
%       consisting of the intercepts of the discriminant function trained
%       by each submodel  
%   
%       the discriminat function:
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%
%   .ind: a column vector with the same size as alpha_v,  consisting
%            of the indices of the samples employed for training a sub-model;
%        if 'svm_theta_solver' == 'CCCP_online'  
%       while  'svm_theta_solver' == 'CCCP_online', model.ind is a matrix  
%        with the same structure and size as model.alpha
%
% ite_inf: a struct of iteration characteristics



% arguments
[X,y,dataFile] = getArgument(argData,{'X','y','dataFile'});

if isempty(X) || isempty(y)
    if isempty(dataFile)
        error('Either arg.X, arg.y or arg.dataFile should be set.\n');
    else
        load(dataFile,'X','y');        
    end    
end
X_col = full(X)';

if size(X,1)~= length(y)
    error('the number of rows of X should be equal with length of y.')
end

n_train = length(y); % number of training samples

% % % [c1,w] = getArgument(argAlg, {'c1','w'});
 [cp,cu,w,svm_theta_solver] = getArgument(argAlg, {'cp','cu','w','svm_theta_solver'});
% % % [ lambda,svm_theta_solver,...
% % %     r1,verbose,tol_violating_pair_initial,tol_violating_pair_min,...
% % %     mu_neg,mu_pos,n_initial_cardinality_S,fix_train_order] = ...
% % % getArgument(argAlg,{ 'lambda','svm_theta_solver','r1','verbose','tol_violating_pair_initial','tol_violating_pair_min',...
% % %     'mu_neg','mu_pos','n_initial_cardinality_S','fix_train_test_set','fix_train_order'});  

% arg.cp=cp;
% arg.cu =cu;
% % % % arg.lambda = lambda;
% arg.w = w;
% arg.r1 = r1;
% arg.verbose = verbose;
% % % % arg.tol_violating_pair_initial = tol_violating_pair_initial;
% % % % arg.tol_violating_pair_min = tol_violating_pair_min;
% arg.mu_neg = mu_neg;
% arg.mu_pos= mu_pos;
% % % % arg.n_initial_cardinality_S = n_initial_cardinality_S;
% % % % arg.fix_train_order   = fix_train_order;

arg = argAlg; 


ite_inf = struct();  
fval_v = [];
ite_inf = struct();
exitFlag = [];
if strcmpi(svm_theta_solver,'CCCP_batch')  
    [model,fval_v,exitFlag] = pu_batch_repeat(arg,X_col,y);
elseif strcmpi(svm_theta_solver,'double_hinge')
    [model,fval, exitFlag]= pu_dh(arg,X_col,y);
    model.ind = (1:n_train)';
else
    % employ online CCCP
    [model,ite_inf]=pu_CCCP_online(arg,X_col,y);
    model.ind = (1:n_train)';   
end

if argAlg.verbose
    fwritef(1,'exitFlag of the solver:',exitFlag,'%d\t');
end

 
    
end
