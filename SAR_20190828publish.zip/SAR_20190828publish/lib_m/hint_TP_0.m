function flag = hint_TP_0(resultFile)  
% Input: 
%   resultFile: a string of the mat resultFile full name (including the path)
%       If a '*** .txt' file name is provided, the function use the MAT
%       file with the same file name
% Output: 
%   -1: the resultFile not exist
%   0:  not find file 'TP==0, FP==0' phenomeneon
%   1:  'TP==0, FP==0' accurs

    [resultFile_path,resultFile_name,suffix] = fileparts(resultFile); 

    if ~strcmpi(suffix,'.mat')
        resultFile = [ addFileSep(resultFile_path) resultFile_name '.mat'];
    end
    if ~exist(resultFile,'file')
        flag = -1;
        return;
    end
     
    s_result = load(resultFile,'num');     
    flag =  s_result.num{3}.TP==0 &&  s_result.num{3}.FP == 0 ;
        
end