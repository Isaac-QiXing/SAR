function [acc,num,varargout] = accuracyIndex(indexRank,y,digestIndex,arg)
% select indices and calculate accuracies based on specified FDRs
%
% Inputs:
%  indexRank: 
%   (1) a column vector consisting of the scores indicating the rank.
%            A large score indicates a high rank.
%   (2) Or a cell array, with each cell consisting of an independent set of scores 
%   (3) Or empty [], indicating that all the scores corresponding to y are
%      select to calcualte the accuracies          
%
%  y: a column vector consisting of the labels, 1: positive sample, -1: negative sample;
%   (1) if indexRank is a column vector, then length(y) should equal to  length(indexRank)  
%
%  digestIndex: 
%    * a column vector with the same length as y, indicating the digested
%    type of each PSM, it consists of 0, 1 and 2
%       2: full digested, 1: half  digested, 0: none
%    * set [], if not to provide digest information
%
%  arg: the arguments
%   .fdr:   fdr:=2*FP/(TP+FP); this parameter is required if indexRank is set;
%   .accuracyMerge: 0 or 1, whether merge accuracies when  indexRank is a cell array with  length>1
%       default 1; 
%   .index:   a cell array,  this parameter is required when indexRank is a  cell array with  length>1 
%       arg.index{i} is a column vector of  the indices of the samples corresponding to indexRank{i},
%           i.e.   length(arg.index{i}) should equal to  length(indexRank{i}),i = 1,2,...
%   .tolFP:  optional, number of allowed FPs that to be added additionally, default value 0;   
%   .ratio_discount: optional,   for setting the expected number of added  identified  samples  once append one FP     
%       expect_add_sample =  ratio_discount * round(2/arg.fdr);   
%       this parameter is effective when arg.tolFP > 0
%
%  .allowZeroFDR: optional, 1 or 0, whether allow  the extreme case that the calculated FDP == 0, default value 0;    
%
%   Note  
%   (1)  when arg.accuracyMerge ==1, all the indices in { arg.index{i} | i=1,2,..} should be unique   
%       i.e., * the indices in each arg.index{i} is unique, i =1,2.,,
%             * And any two cells arg.index{i}, arg.index{j} contains no  common indices
%   (2)  when  indexRank is a column vector or cell array with  length==1, then arg.index is useless, and not needed  
%   (2)  the parameter arg.selectedTarget is not supported any more.
%
% Outputs:
%  num:  struct array of numbers about TP, FP, etc.
%   (1)  if indexRank is a  column vector or [], or a cell array of length 1, then  length(num) == 1,
%   (2)  if indexRank is a cell array with length>1, then
%       length(num)== length(indexRank),   if arg.accuracyMerge== 0
%       length(num)== length(indexRank)+1, if arg.accuracyMerge== 1
%    num(i) is a struct with files TP, FP ,etc. for indexRank{i}, i=1,2,..., length(indexRank)
%    num(length(indexRank)+1)  is a struct for the  accuracy on the merged dataset
%   
%   .TP : number of true positives 
%   .FP : number of false positives
%   .FN : number of false negative
%   .TN : number of true negative
%   .TP_full: number of TP in full-digested (if digestIndex is provided)
%   .TP_half: number of TP in half-digested (if digestIndex is provided)
%   .TP_none: number of TP in none-digested (if digestIndex is provided)
%   .FP_full: number of FP in full-digested (if digestIndex is provided)
%   .FP_half: number of FP in half-digested (if digestIndex is provided)
%   .FP_none: number of FP in none-digested (if digestIndex is provided)
%     and similarly for 
%   .FN_full
%   .FN_half
%   .FN_none
%   .TN_full
%   .TN_half
%   .TN_none
%
%  acc: struct array of accuracies, with the same length as NUM
%   .FDR: false discovery rate: 2*FP/(FP+TP) 
%   .TPR: true positive rate:  TP/(TP+FN)
%   .FPR: false positive rate: FP/(FP+TN)
%
%  varargot{1}: struct array of indices, with the same fields as NUM; 
%       consists of indices of the identified samples
% varargout{2}: vecter of flags of the identification, with the length length(indexRank),
%   each values has the following values for each indexRank(ii)
%     0: Identified  TP+FPs satisfying that FDR value <= the specified .fdr 
%     -1: dealed with the extreme case that  the selected FDR ==0 and the  identified TP+FPs increases   
%     N (a positive integer): the number of extra added FPs 

% 0.1 check the input size of indexRank and arg.index
if iscell(indexRank) && length(indexRank)>1
    if ~isfield(arg,'index') || length(indexRank)~=length(arg.index) 
        error('when indexRank is a cell array, arg.index is required, and should have the same size as indexRank');        
    end
    for ii=1:length(indexRank)
        if length(indexRank{ii})~=length(arg.index{ii})
            error('when indexRank is a cell array, arg.index{ii} should have the same size as indexRank{ii}');        
        end
    end
end

% 0.2 check the size of y and digestIndex

  % check the size of y
if ~iscell(indexRank) && length(indexRank)~=length(y)
    error('If indexRank is provided, it should have the same size as y');
end
  % check the size of digestIndex
if ~isempty(digestIndex) && length(digestIndex)~=length(y)
    error('If digestIndex is provided, it should have the same size as y');
end

% 0.2 set default parameter values
if ~isfield(arg,'accuracyMerge') || isempty(arg.accuracyMerge)
    arg.accuracyMerge = 1;
end

if ~isfield(arg,'tolFP') || isempty(arg.tolFP)
    arg.tolFP = 3;
end

if ~isfield(arg,'ratio_discount') || isempty(arg.ratio_discount)
    arg.ratio_discount = 0.4;
end

if ~isfield(arg,'allowZeroFDR') || isempty(arg.allowZeroFDR)
    arg.allowZeroFDR = 0;
end


% 0.3 count the length of the output struct array num
if  iscell(indexRank) && length(indexRank)>1
    n_group = length(indexRank);
else     
    n_group = 1; % n_group: number of groups of scores 
end    
if n_group>1 && arg.accuracyMerge 
    len_num = n_group + 1; %len_num: length of the output struct array num, id and acc
else
    len_num = n_group;
end


% % % % 0.4.1 deal with the case that indexRank is empty 
% % % if isempty(indexRank)
% % %     indexRank = cell(len_num,1);
% % % end


% 1. calculate the accuracies


num = struct('TP',num2cell(zeros(len_num,1)),'FP',0,'FN',0,'TN',0,...
    'TP_full',0,'TP_half',0,'TP_none',0,'FP_full',0,'FP_half',0,'FP_none',0,...
    'TN_full',0,'TN_half',0,'TN_none',0,'FN_full',0,'FN_half',0,'FN_none',0);
id =  struct('TP',cell(len_num,1),'FP',[],'FN',[],'TN',[],...
    'TP_full',[],'TP_half',[],'TP_none',[],'FP_full',[],'FP_half',[],'FP_none',[],...
    'TN_full',[],'TN_half',[],'TN_none',[],'FN_full',[],'FN_half',[],'FN_none',[]);
acc = struct('FDR',num2cell(zeros(len_num,1)),'TPR',0,'FPR',0);
flag_exit_v = zeros(len_num,1);

for ii=1:n_group
    if nargout>=3
        if n_group==1 
            if ~iscell(indexRank)            
                [acc(1),num(1),id(1),flag_exit_v(1)] = accuracyIndex_0(indexRank,y,digestIndex,arg);
            else % indexRank is cell 
                [acc(1),num(1),id(1),flag_exit_v(1)] = accuracyIndex_0(indexRank{1},y,digestIndex,arg);
            end
        else % indexRank is a cell and n_group>1
            % set the digestIndex for ii-th group of scores
            if isempty(digestIndex)
                digestIndex_ii = [];
            else 
                digestIndex_ii = digestIndex(arg.index{ii});
            end
            [acc(ii),num(ii),id(ii),flag_exit_v(ii)] = accuracyIndex_0(indexRank{ii},y(arg.index{ii}),digestIndex_ii,arg);         
            
        end
    else % nargout<=2, do not get the 3rd output ID
        if n_group==1 
            if ~iscell(indexRank)            
                [acc(1),num(1),~,flag_exit_v(1)] = accuracyIndex_0(indexRank,y,digestIndex,arg);
            else % indexRank is cell 
                [acc(1),num(1),~,flag_exit_v(1)] = accuracyIndex_0(indexRank{1},y,digestIndex,arg);
            end
        else % indexRank is a cell and n_group>1
            % set the digestIndex for ii-th group of scores
            if isempty(digestIndex)
                digestIndex_ii = [];
            else 
                digestIndex_ii = digestIndex(arg.index{ii});
            end
            [acc(ii),num(ii),~,flag_exit_v(ii)] = accuracyIndex_0(indexRank{ii},y(arg.index{ii}),digestIndex_ii,arg);
        end
    end
end

% update indices of the struct array id
field_num_c = fieldnames(num);
n_field_num = length(field_num_c);
if nargout>=3 && n_group>1
    for ii=1:n_group
        index_ii = arg.index{ii};
        for kk=1:n_field_num
            field = field_num_c{kk};            
            id(ii).(field) = index_ii(id(ii).(field));
        end
    end
end

% 2. merge the accuracies
if arg.accuracyMerge && len_num>1
    for kk=1:n_field_num
        field = field_num_c{kk};
        num(len_num).(field) =  sum( [num(1:n_group).(field)] );
        if nargout>2
            id(len_num).(field) = vertcat(id(1:n_group).(field));
        end
    end
    acc(len_num).FDR = 2*num(len_num).FP/(num(len_num).FP + num(len_num).TP);
    acc(len_num).TPR = num(len_num).TP/(num(len_num).TP + num(len_num).FN);
    acc(len_num).FPR = num(len_num).FP/(num(len_num).FP + num(len_num).TN);    
end

% 3. output 
if nargout>=3
    varargout{1} = id;
end
if nargout>=4
    varargout{2} = flag_exit_v;
end

end %end of the function accuracyIndex()





function [acc,num,varargout] = accuracyIndex_0(indexRank,y,digestIndex,arg)
% calculate the accuracy index

% Inputs:
%  indexRank: the value of a certain index ranking the samples,
%            with a large value indicateing a reliable target;
%           if indexRank is set [], all the samples corresponding to y, will
%           be viewed selected targets;
%  y: a column vector consisting of the labels, 1: targets, -1: decoys;
%
%  digestIndex: a column vector indicating the digested type;
%    2: full digested, 1: half  digested, 0: none
%    * set [], if not to provide digest information
%
%  arg: the arguments
%   .fdr: Optional, upper bound of the fdr:=2*FP/(TP+FP); this parameter
%          is effective only if indexRank is set;
%   .selectedTarget: Optional, a vector consisting a series of rate of predicted
%       positive samples (i.e. x_i's with f(x_i)>0 )
%    e.g. [0.1 0.2 0.3] indicating the selected percentage of the predicted
%      positive samples are 10%, 20%, 30%
%       this parameter is effective if and only if indexRank is set and 
%       .fdr is not effective;
%   .tolFP, refer the inputs of accuracyIndex()
%   .ratio_discount: scalar that for discount the expected number of added  identified  samples  once append one FP    
%       expect_add_sample =  ratio_discount * round(2/arg.fdr);   
%       this parameter is effective when arg.tolFP > 0 
%   .allowZeroFDR: optional, 1 or 0, whether allow  the extreme cast that the calculated FDP == 0, default value 0;   
%
% Outputs:
%  num: array of accuracy structure with the same length as
%    arg.selectedTarget
%   .TP : number of true positives 
%   .FP : number of false positives
%   .FN : number of false negative
%   .TN : number of true negative
%   .TP_full: number of TP in full-digested
%   .TP_half: number of TP in half-digested
%   .TP_none: number of TP in none-digested
%   .FP_full: number of FP in full-digested
%   .FP_half: number of FP in half-digested
%   .FP_none: number of FP in none-digested
%     and similarly for 
%   .FN_full
%   .FN_half
%   .FN_none
%   .TN_full
%   .TN_half
%   .TN_none
%  acc: array of accuracy structure 
%   .FDR: false discovery rate: 2*FP/(FP+TP) 
%   .TPR: true positive rate:  TP/(TP+FN)
%   .FPR: false positive rate: FP/(FP+TN)
%  varargout{1}: id, array of a structure with the same fields as NUM; indexing the
%      selected samples 
% varargout{2}: flag of the identification. 
%     0: Identified  TP+FPs satisfying that FDR value <= the specified .fdr 
%     -1: dealed with the extreme case that  the selected FDR ==0 and the  identified TP+FPs increases   
%     N (a positive integer): the number of extra added FPs 


if ~isempty(digestIndex) && length(y)~=length(digestIndex)
    error('The length of the #2 and #3 should equal.');
end
flag_index = ~isempty(indexRank); % 1: indexRank is set; 0: otherwise
if flag_index && length(y)~=length(indexRank)
    error('If #1 is not empty, the length of the #1 and #2 should equal.');
end
if nargin<=3 || nargin>3 && (~isfield(arg,'selectedTarget') || isempty(arg.selectedTarget))
    selectedTarget = 1.0;
else
    selectedTarget = arg.selectedTarget;
end

if arg.tolFP>0   
    ratio_discount = arg.ratio_discount; 
    % expect_add_sample =  ratio_discount * round(2/arg.fdr);  
    % this parameter is effective when arg.tolFP > 0 
end

n_y = length(y);
if flag_index
    n_pos = nnz(indexRank>0);
else
    n_pos = n_y; % all the samples are viewed selected targets 
end


if flag_index
    [~,i_trRank] = sort(indexRank,'descend');
end

% * calculate rates of the selected targets based on fdr
flag_exit = 0; 
if flag_index && nargin>3 && isfield(arg,'fdr') && ~isempty(arg.fdr)
       
    % *.1 calculate all the  FDR levels    
    FP_max = ceil(n_y * arg.fdr * 0.5);  % maximum number of possible FPs under the specified FDR
    FP_search = FP_max + 1 + arg.tolFP; 
    ind_FP = find(y(i_trRank)==-1,FP_search);
    n_FP = length(ind_FP);
    if n_FP>0
        fdr_search =  2*( (1:n_FP)'-1)./((ind_FP-1)+~(ind_FP-1)); 
            % fdr_search is a vector with the same length as ind_FP
            % FDR values if the selected number of scores are ind_FP(ii)-1, with number of FP ii-1
            %  note that it always hold that fdr_search(1) == 0 
            %  +~(ind_FP-1): avoid the case that ind_FP(1)-1 ==0
    else
        fdr_search = [];
    end
    % *.2 find the biggest index that the FDR value is less than specified FDR level arg.fdr   
    i_act = [];
    if isempty(ind_FP)
        selectedTarget = 1.0; % no FP found, all the indices are selected as correct
    else % n_FP>0
        i_act = find(fdr_search <= arg.fdr,1,'last');         
        selectedTarget = (ind_FP(i_act)-1)/n_y; 
    end    
        
        
    % *.3 deal with the extreme case that  the selected FDR ==0    
    if ~isempty(i_act) && i_act ==1 && ~arg.allowZeroFDR    % arg.zeroFDR: deal with the case 
        fdr_search(1) = Inf; % to avoid fdr_search(1) is selected in the min opereation below
        [fdr_min, i_min] = min(fdr_search); % try to select the minimum FDR 
        if fdr_min <=2*arg.fdr           
            selectedTarget = (ind_FP(i_min)-1)/n_y; % reset selectedTarget
            i_act = i_min; % reset i_act
            flag_exit = -1; 
        end       
    end
      
    % *.4 allow add specified number of FPs additionally
    if arg.tolFP>0 && ~isempty(i_act) && i_act<n_FP
    
         expect_add_sample =   round(2/arg.fdr);   % fdr = 2*FP/(TP+FP)
          % expeted number of added samples once add one FP : expect_add_sample
         expect_add_sample_discount =   round(ratio_discount*2/arg.fdr);   % fdr = 2*FP/(TP+FP)
           % set expected indices of i of the scores that y_i==-1
         ind_expect = Inf(n_FP,1); % a column vector, expected indices of i of the scores that y_i==-1
         ind_FP_discount = min(i_act + arg.tolFP,n_FP);
         ind_expect(i_act+1: ind_FP_discount) = ind_FP(i_act) + expect_add_sample_discount*(1: ind_FP_discount-i_act)';  
            % set expected indices of i with  expeted number of added samples == expect_add_sample_discount  
         if ind_FP_discount < n_FP
            ind_expect(ind_FP_discount+1 : n_FP) = ind_expect(ind_FP_discount) + expect_add_sample *(1 : n_FP - ind_FP_discount)';
            % set expected indices of i with  expeted number of added samples == expect_add_sample
         end
           % find the last index that the expected index of negative sample less than that of the true negative sample   
         i_act_adjust =  find(ind_expect<=ind_FP,1,'last'); % note that i_act_adjust > i_act if i_act_adjust is not empty
         if ~isempty(i_act_adjust)             
              selectedTarget = (ind_FP(i_act_adjust)-1)/n_y; % reset selectedTarget
              if flag_exit~=-1 % set flag_exit
                flag_exit = i_act_adjust-i_act; 
              end
         end
        
    end
end
           
if nargout>=4
    varargout{2} = flag_exit;
end

% calculate the accuracies based on the value of arg.selectdTarget
n_sample = length(y);

len_sel = length(selectedTarget);
num = struct('TP',num2cell(zeros(len_sel,1)),'FP',0,'FN',0,'TN',0,...
    'TP_full',0,'TP_half',0,'TP_none',0,'FP_full',0,'FP_half',0,'FP_none',0,...
    'TN_full',0,'TN_half',0,'TN_none',0,'FN_full',0,'FN_half',0,'FN_none',0);
id =  struct('TP',cell(len_sel,1),'FP',[],'FN',[],'TN',[],...
    'TP_full',[],'TP_half',[],'TP_none',[],'FP_full',[],'FP_half',[],'FP_none',[],...
    'TN_full',[],'TN_half',[],'TN_none',[],'FN_full',[],'FN_half',[],'FN_none',[]);
acc = struct('FDR',num2cell(zeros(len_sel,1)),'TPR',0,'FPR',0);

fieldname_num = fieldnames(num);
for ii=1:len_sel
    if flag_index
        sel_rate = selectedTarget(ii);             
        p = round(n_y*sel_rate);    
        i_pos_rank = i_trRank(1:p);
        i_neg_rank = i_trRank(p+1:n_sample);
    else
        i_pos_rank = 1:n_sample;
        i_neg_rank = [];
    end
    if nargout>=3
        id(ii).TP = i_pos_rank(y(i_pos_rank)==1);
        id(ii).FP = i_pos_rank(y(i_pos_rank)==-1);   
        if ~isempty(digestIndex)
            id(ii).TP_full = i_pos_rank((y(i_pos_rank)==1)&digestIndex(i_pos_rank)==2);
            id(ii).TP_half = i_pos_rank((y(i_pos_rank)==1)&digestIndex(i_pos_rank)==1);
            id(ii).TP_none = i_pos_rank((y(i_pos_rank)==1)&digestIndex(i_pos_rank)==0);
            id(ii).FP_full = i_pos_rank((y(i_pos_rank)==-1)&digestIndex(i_pos_rank)==2);
            id(ii).FP_half = i_pos_rank((y(i_pos_rank)==-1)&digestIndex(i_pos_rank)==1);
            id(ii).FP_none = i_pos_rank((y(i_pos_rank)==-1)&digestIndex(i_pos_rank)==0);    
        end
        if flag_index
            id(ii).FN = i_neg_rank(y(i_neg_rank)==1);
            id(ii).TN = i_neg_rank(y(i_neg_rank)==-1);
            if ~isempty(digestIndex)
                id(ii).FN_full = i_neg_rank((y(i_neg_rank)==1)&digestIndex(i_neg_rank)==2);
                id(ii).FN_half = i_neg_rank((y(i_neg_rank)==1)&digestIndex(i_neg_rank)==1);
                id(ii).FN_none = i_neg_rank((y(i_neg_rank)==1)&digestIndex(i_neg_rank)==0);
                id(ii).TN_full = i_neg_rank((y(i_neg_rank)==-1)&digestIndex(i_neg_rank)==2);
                id(ii).TN_half = i_neg_rank((y(i_neg_rank)==-1)&digestIndex(i_neg_rank)==1);
                id(ii).TN_none = i_neg_rank((y(i_neg_rank)==-1)&digestIndex(i_neg_rank)==0); 
            end
        else
            id(ii).FN = []; id(ii).TN = [];
            id(ii).FN_full =[]; id(ii).FN_half = []; id(ii).FN_none = [];
            id(ii).TN_full =[]; id(ii).TN_half =[]; id(ii).TN_none = [];
        end
        varargout{1} = id;
           % assign num(ii)    
        for k=1:length(fieldname_num)
            fieldName = fieldname_num{k};
            num(ii).(fieldName) = length(id(ii).(fieldName));
        end 
    else % nargour<=2
         % calculate the field values of NUM
         num(ii).TP = nnz(y(i_pos_rank)==1);
         num(ii).FP = nnz(y(i_pos_rank)==-1);   
         num(ii).FN = nnz(y(i_neg_rank)==1);
         num(ii).TN = nnz(y(i_neg_rank)==-1);
    end
      
    % assign acc(ii)
    acc(ii).FDR = 2*num(ii).FP/(num(ii).FP + num(ii).TP);
    acc(ii).TPR = num(ii).TP/(num(ii).TP + num(ii).FN);
    acc(ii).FPR = num(ii).FP/(num(ii).FP + num(ii).TN);
end

end % end function accuracyIndex_0()
