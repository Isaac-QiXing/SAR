function v1 = columnVec(v)
% reshape a matrix or (numeric or cell) vector to a column (or cell) vector 

if isColumnVector(v)
    v1 = v;
elseif isvector(v) % v is a vector but not a column vector
    v1 = v';
else % v is not a vector    
    v1 = reshape(v,numel(v),1);    
end