function [varargout]= sampleData(dataFile,X,y,sampleFile,sampleSize,negative_rate)
% sample certain number of cases randomly
% Inputs:
%  dataFile: Optional,mat data file name,  containing 
%       X: the data matrix, each row represents a sample (case)
%       y: the label, 1 or -1
%    if no dataFile put in, just set it [];
%  X: Optional, the matrix X;
%  y: Optional, column vector y; if no X or y is putin, just set [];
%     Note that either X, y or dataFile is required to be set; 
%  sampleSize: number of cases to sample from the data set;
%  negative_rate: number of negative sample / whole number of samples
%       in the sampled subset;
%  sampleFile: name of a mat file which to store the data of sampled
%     cases, it contains variables
%       X: a matrix, each row consisting a sampled case;
%       y: a column vector, the labels of the sampled cases;
%   sizeX: the size of X;
% Outputs:
%   varargout{1}: the indices of selected samples

% load data
if isempty(X) || isempty(y)
    if  ~isempty(dataFile)    
        load(dataFile,'X','y');
    else
        error('Either dataFile or X, y should be set.');
    end
end

negative_set = find(y==-1);
positive_set = find(y==1);
% the number of negatives and  positives to sample
num_negative_sub = min(length(negative_set),round(sampleSize*negative_rate));      
num_positive_sub = min(length(positive_set),sampleSize-num_negative_sub);
% sampling
negative_sub = subVector(negative_set,num_negative_sub);
positive_sub = subVector(positive_set,num_positive_sub);
ind = [positive_sub; negative_sub];

% save data to file
sizeX = [length(ind) size(X,2)];
saveData(sampleFile,'X',X(ind,:), 'sizeX',sizeX, 'y',y(ind));
% put out 
if nargout>0
    varargout{1} = ind;
end

end