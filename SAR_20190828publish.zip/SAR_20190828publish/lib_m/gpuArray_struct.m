function st2= gpuArray_struct(flag_single,st)
% transform a scalar struct with numeric fields to gpuArray
% Inputs:
%   st: a scalar struct of numeric fields
%   flag_single: 1 or 0, indicate whether to return single gpuArray
% Outputs:
%   st2: a scalar struct with numeric fields of gpuArray

st2 = st; 

fieldnames_c = fieldnames(st2);

for ii=1:length(fieldnames_c)
    field = fieldnames_c{ii};
    if flag_single
        st2.(field) = gpuArray(single(st2.(field)));
    else
        st2.(field) = gpuArray(st2.(field));
    end
end

end 