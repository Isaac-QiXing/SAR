function str_id = ordinal_str(id)
% transform a positive integer to a string ordinal number
%  if the input is not an integer
% Input:
%  id: a positive integer;
% Output:
%  str_id: a string, the ordinal number

if ~isinteger(id)
    id = round(id);
end

switch id
    case 1
        str_id = 'first';
    case 2
        str_id = 'second';
    case 3
        str_id = 'third';
    otherwise
        str_id = sprintf('%dth',id);
end
    

end