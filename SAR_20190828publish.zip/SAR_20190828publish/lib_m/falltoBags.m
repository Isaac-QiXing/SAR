function [num_balls indices_bags]= falltoBags(x,bags)
% account the balls falling to different bags
% Inputs:
%   x: a (column) vector
%   baggs: a (column) vector with elements ordered ascendingly
% Outputs:
%   num_balls: a (column) vector, same size as bags, num_balls[i]: the number of elements
%     of x lie in the section (bags(i-1), bags(i) ], bags(0) is defined
%     as minums infinity
%   indices_bags: a (column) vector, same size as x, indices_bag(i) indicate 
%     the bag which the i-th ball belongs to; all the remaining balls will
%     be indicated into a virtual bag: the length(bags)+1 - th bag

num_balls = zeros(size(bags));
indices_bags=[]; 
if isempty(x) || isempty(bags)
    return
end
nballs = length(x);
nbags = length(bags);
T=[x  zeros(nballs,1); 
   bags ones(nbags,1)];
[T indices_T]= sortrows(T);
inds_T_bags = find(T(:,2)); % indices of balls in T(:,2)
inds_T_balls = find(T(:,2)==0);
num_balls = inds_T_bags - [0; inds_T_bags(1:nbags-1)] - 1;
indices_balls = indices_T(inds_T_balls);
cumT = cumsum(T(:,2));
indices_bags = ones(nballs,1); % initialization
indices_bags(indices_balls,1) = cumT(inds_T_balls)+1;