function [data] = getSpregData(arg)
% generate  simulation data of  linear spatial regression
%  arg: parameters of samples, see getRegData() for detail
%   arg.n_sample: a positive scalar
%   arg.dim_act : a positive scalar
%   arg.dim_inact : a positive scalar
%   arg.mu_beta_act
%   arg.sigma_beta_act
%   arg.mu_noise
%   arg.sigma_noise
%   arg.mu_outlier: optional
%   arg.sigma_outlier: optional
%   arg.weight_outlier: optional
%   arg.rho:  a scalar in [0,1], the coefficient of the spatial weighting matrix
%       =============== refer the parameters of getW() for the following fields ===
%   arg.m: a positive integer, arg.n_sample should be divided by arg.m
%   arg.W: optional, a user-specified spatial squared weighting matrix.
%   arg.mode: mode of noisy weights :  'dense'| 'sparse' | 'null'
%   arg.indexRow: optional, a vector of row indices
%   arg.ratio: optional, a positive scalar in [0,1]
% Outputs:
%   data: the output data struct, with the following fields
%     .X:  n-by-dim matrix
%     .y:  n-by-1 vector of observings: (I- rho*W) * y = X * beta + epsilon
%     .beta: dim-by-1 vector of variables
%     .epsilon: n-by-1 vector of noises
%     .W:  the n-by-n spatial weighting matrix 
%     .W_noise: the spatial weighting matrix with noise 
%     .y_reg: W_noise *y
%     .y_fix: y - rho*W_noise*y
%     .rho: a scalar in [0,1]
%     .arg:  the parameter struct 


[data] = getRegData(arg);
[W, W_noise] = getW(arg);

% generate the dependent variable y:
%      (I- rho*W) * y = X * beta + epsilon
n_sample = arg.n_sample;
y = linsolve( eye(n_sample)-arg.rho*W, data.X* data.beta + data.epsilon);
y_reg = W_noise *y;
y_fix =   y  - arg.rho* y_reg; % y_fix = y - rho*W*y

% assing the variables to data
data.y = y;
data.y_reg = y_reg;
data.y_fix = y_fix;
data.rho = arg.rho;
data.W = W;
data.W_noise = W_noise;
data.arg = arg;

end % end of the function