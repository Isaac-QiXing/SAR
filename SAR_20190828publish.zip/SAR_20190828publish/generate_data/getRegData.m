function [data_st] = getRegData(arg)
% generate  simulation data of linear regression
%  arg: parameters of samples
%   arg.n_sample: a vector of K positive integers, indicating the number of samples of K cases
%   arg.dim_act:  a positive scalar or a vector of positive integers with the length K,
%       indicating the number of nonzero  variables of the K cases
%   arg.dim_inact: a positive scalar or vector with the same size as arg.dim_act,
%       indicating the   number of null variables  of the K cases
%   arg.mu_beta_act: the mean values of the nonzero variables of beta which are Gaussians
%       (1) it is a m-by-1 vector, if arg.dim_act is a scalar, with m==arg.dim_act
%       (2) it is a cell of lenth K, if arg.dim_act is a vector with length>1,
%           in this case, arg.mu_beta_act{i} is a vector of length == arg.dim_act(i),
%           indicating the mean values  of nonzero variables of the i-th tested size;
%   arg.sigma_beta_act: covariance matrix of the variables beta
%       (1) it is a m-by-m symmetric positive semi-definite matrix, if arg.dim_act is a scalar,
%               with m==arg.dim_act
%       (2) it is a cell of lenth K, if arg.dim_act is a vector with length>1,
%           in this case, arg.mu_beta_act{i} is a symmetric positive semi-definite matrix of
%           order == arg.dim_act(i), indicating the covariances of nonzero variables of the i-th
%           tested size;
%
%   arg.mu_noise: the mean value  of the noise vector, epsilon,
%       it is a scalar ;
%       the noises are  i.i.d. mixture Gaussian  distribution;
%
%        epsilon ~  (1- weight_outlier)*Gaussian(mu, sigma) + weight_outlier*Gaussian(mu_outlier, sigma_outlier)
%                                                                                          (*)
%         with 0<= delta <=1,
%             weight_outlier= arg.weight_outlier;
%             mu = arg.mu_noise,
%             sigma = arg.sigma_noise,
%             mu_outlier = arg.mu_outlier,
%             sigma_outlier = arg.sigma_outlier;
%
%   arg.sigma_noise: the variance(s) of the Gaussian distributions of the noise vectors
%       it is a positive scalar;
%
%   arg.mu_outlier: optional, a scalar, the mean value of the outliers  of the mixture Gaussians of
%    the noise, refer Equation (*), default [];
%
%   arg.sigma_outlier: optional, a scalar, the variance of the outliers  of the mixture Gaussians of
%    the noise, refer Equation (*), default [];
%
%   arg.weight_outlier: optional, a scalar in [0,1], the weight of the outlier distribution,  default value [],
%        refer Equation (*).
%
% Outputs:
%  data_st: a struct array of the generated  data, with length K*n_noise, with K the  number of
%  the cases  of the sizes (n and dim), n_noise: the case of the noise vectors, in current
%  version, n_noise == 1  
%   each data consisting of the fields:     
%   X:     n-by-dim matrix, with n the number of samples, dim: the number of variables (features)
%   beta:  dim-by-1 variable
%   y:     n-by-1 vector
%             y = X * beta + epsilon,
%   epsilon: n-by-1 noise  vector
%
% Versions
%   2019.4.24 First version


 

n_size = length(arg.n_sample); % n_size: number of tested sizes
n_noise = max(length(arg.mu_noise),length(arg.sigma_noise));
% in current version, n_noise ==1

% check the input parameters

if  length(arg.dim_act)~= 1 && length(arg.dim_act)~= n_size
    error('arg.dim_act should be a positive scalar or a vector of the same length as arg.n_sample');
end
% check arg.dim_inact
if  length(arg.dim_inact) ~= length(arg.n_sample)
    error('arg.dim_inact should have the same size as arg.n_sample');
end
% % % % check  arg.mu_beta_act
% % % if   arg.dim_act ~= size(arg.mu_beta_act,2)
% % %     error('arg.mu_beta_act should have the column numbers == arg.dim_act');
% % % end

% % % % check arg.sigma_beta_act
% % % if length(arg.dim_act)== 1
% % %     dim = arg.dim_act + arg.dim_inact;
% % %     if size(arg.sigma_beta_act,1) == dim   && size(arg.sigma_beta_act,2) == dim
% % %         error('arg.sigma_beta_act should be a squred matrix with the specified dimension.');
% % %     end
% % % else
% % %     if length(arg.sigma_beta_act) ~= n_size && iscell(arg.sigma_beta_act)
% % %         error('arg.sigma_beta_act should be a cell with the same length as arg.n_sample.');
% % %     end
% % % end


arg = completeArg(arg,{'weight_outlier','mu_outlier','sigma_outlier'},{[],[],[]});

% initialize data_st
data_st = struct('X',[],'y',[],'beta',[],'epsilon',cell(n_size,1));

% 1. generate data matrix X, and variable beta
dim_v = arg.dim_act + arg.dim_inact;
for i_size = 1:n_size
    if ~isscalar(arg.n_sample)
        n_sample = arg.n_sample(i_size);
    else
        n_sample = arg.n_sample;
    end
    
    if ~isscalar(dim_v)
        dim = dim_v(i_size);
        q = arg.dim_inact(i_size); % q: the number of zero coordinates of beta
    else
        dim =dim_v;
        q = arg.dim_inact;
    end
    % 1.1 generaet X
    mu = zeros(1,dim);
    sigma =  matrix_a_power_i_minus_j(0.5,dim);
    X = mvnrnd(mu,sigma,n_sample); % X is n_sample - by- dim
    data_st(i_size).X = standardize(X);
    
    % 1.2 generate the regression variable beta
    
    % 1.2.1 get parameter of the mean value
    if iscell(arg.mu_beta_act) && length(arg.mu_beta_act) == 1
        mu_beta = arg.mu_beta_act{1};
    elseif iscell(arg.mu_beta_act) && length(arg.mu_beta_act) == n_size;
        mu_beta = arg.mu_beta_act{i_size};
    else
        mu_beta = arg.mu_beta_act; % arg.mu_beta_act is a column vector
    end
    % 1.2.2 get parameter of variance
    if iscell(arg.sigma_beta_act) && length(arg.sigma_beta_act) == 1
        sigma_beta = arg.sigma_beta_act{1};
    elseif iscell(arg.sigma_beta_act) && length(arg.sigma_beta_act) == n_size;
        sigma_beta = arg.sigma_beta_act{i_size};
    else
        sigma_beta = arg.sigma_beta_act; % arg.sigma_beta_act is a symmetric matrix
    end
    % 1.2.3 produce beta
    beta_act = columnVec(mvnrnd(mu_beta,sigma_beta,1));
    data_st(i_size).beta  = [beta_act; zeros(q,1)];
end

% 3. generate noise vector, epsilon, and y
mu_noise = arg.mu_noise;
sigma_noise = arg.sigma_noise;
mu_outlier = arg.mu_outlier;
sigma_outlier = arg.sigma_outlier;

for i_size = 1:n_size
    if ~isscalar(arg.n_sample)
        n_sample = arg.n_sample(i_size);
    else
        n_sample = arg.n_sample;
    end
    % 3.1 generate epsilon
    if isempty(arg.weight_outlier) || isempty(arg.mu_outlier)||isempty(arg.sigma_outlier)
        epsilon  = normrnd( mu_noise,sigma_noise,[n_sample,1]); % epsilon is a n_sample-by-1 vector
    else
        weight = arg.weight_outlier;
        epsilon  = (1-weight)* normrnd( mu_noise,sigma_noise,[n_sample,1]) ...
            + weight * normrnd(mu_outlier,sigma_outlier,[n_sample,1]);
    end  
    % 3.2 produce y
    y = data_st(i_size).X * data_st(i_size).beta + epsilon;
    % 3.3 assign epsilon, and y to data_st 
    data_st(i_size).epsilon = epsilon; 
    data_st(i_size).y  = y;
end   
    
end