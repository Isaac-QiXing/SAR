function [par_st,index_c]= getSpregData_para()
% set parameters of sythetic sptial regression data 

% 1. Gaussian white noise 
% 1.0 generate rho
rho_base = [0.8,0.5,0.2];
rho_v = zeros(length(rho_base)+1,1); 
rho_v(1:3) = rho_base + rand_interval([-0.1,0.1],1,3);
rho_v(end) = 0; % append 0  in special

% 1.1 parameter values
%  Note that the remaining settings of  part 2 and 3 are also based on the parameter struct ARG 

arg.n_sample =  {30,30,120,120,360,360}; % group A 
arg.dim_act =   3;  % baseline
arg.dim_inact = {5, 20, 5, 80, 5, 200};  % group A 

arg.mu_beta_act = [3,2,1.6]; % baseline
n_act_coef = arg.dim_act; 
arg.sigma_beta_act = 0.01*eye(n_act_coef,n_act_coef); % baseline

arg.mu_noise = 0;  % baseline
arg.sigma_noise = num2cell(((rand(1,1) - 0.5)*0.2+[1 2 ])); % group B* 
%arg.sigma_noise = ((rand(1,1) - 0.5)*0.2+[1  ]); % 

%arg.mu_outlier = [];  % baseline
%arg.sigma_outlier = []; % baseline

% parameters for W
arg.rho = num2cell(rho_v);   % group B*
arg.m = 6; %3;   %  baseline
 

arg.mu_outlier = [];
 arg.sigma_outlier = []; 
 arg.weight_outlier = [];   
 arg.mode        = [];
 arg.ratioColumn = [];
 arg.ratioRow    = [];

 % set default parameter settings
arg_base = assign_struct('',fieldnames(arg),[]);
arg_base = assign_struct(arg_base,{'dim_act','mu_beta_act','sigma_beta_act','mu_noise','m'},arg);

%1.3 produce parameter settings 
par_style = struct('n_sample','A+','dim_inact','A+','rho', 'B*', 'sigma_noise', 'B*');
[par1_st,index1_tb] = struct2struct_array(arg,par_style,arg_base ); % 6*2*4 = 48 settings

% 2. generate spatial regession data with outliers in the response y
arg2 = arg; 
arg2.n_sample = {60, 120,360}; % group A 
arg2.rho         = num2cell(rand_interval([-0.1,0.1],1,4) + [0.8 0.5 0.2 0.5]); % group B 
arg2.sigma_noise = num2cell(rand_interval([-0.1,0.1],1,4) +[1.0 1.0 1.0 2.0]); % groupB
 arg2.weight_outlier = {0.01, 0.05, 0.2, 0.4 0.8};  % group C 
 
arg2.dim_act = 3;  % baseline
arg2.dim_inact = [5];  % baseline
 arg2.mu_outlier = 10;
 arg2.sigma_outlier = 6*6; 

arg_base2 = assign_struct(arg_base,{'dim_act','dim_inact','mu_outlier','sigma_outlier'},arg2);

 par2_style = struct('n_sample','A*', 'rho', 'B+', 'sigma_noise', 'B+','weight_outlier','C*');
[par2_st,index2_tb] = struct2struct_array(arg2,par2_style,arg_base2 ); % 3*4*5 = 60 settings

% 3. generate spatial regession data with inaccurate spatial matrix W
arg3 = arg; 
arg3.n_sample = {60, 120,360}; % group A 
arg3.mode        = {  'sparse','sparse','sparse','dense','dense', 'dense','dense'};  % group B+
 arg3.ratioColumn = {0.3,      0.5,     0.8,      0.5,     1.0,      1.0,     2.0 };% group B+
 arg3.ratioRow    = {1.0,     1.0,     1.0,      1.0,      1.0,      0.1,     0.1 };  % group B+
 
arg3.dim_act = 3;  % baseline
arg3.dim_inact = [5];  % baseline
arg3.rho = rand_interval([-0.1,0.1],1,1) + [0.5]; % baseline
arg3.sigma_noise = rand_interval([-0.1,0.1],1,1) +[1.0]; % baseline

 arg3.mu_outlier = [];
 arg3.sigma_outlier = []; 
 arg3.weight_outlier = [];   
 
 arg_base3 = assign_struct(arg_base,{'dim_act','dim_inact','rho','sigma_noise'},arg3);
 
par3_style = struct('n_sample','A*',   'mode', 'B+','ratioColumn','B+','ratioRow','B+'); 
[par3_st,index3_tb] = struct2struct_array(arg3,par3_style, arg_base3); % 3* 7 = 21 settings


% merge the settings
n1 = length(par1_st);
n2 = length(par2_st);
n3 = length(par3_st);
n = n1+n2+n3;
par_st(n1+n2+1:n) = par3_st;
par_st(1:n1)      = par1_st;
par_st(n1+1:n1+n2)= par2_st;


index_c = {index1_tb,index2_tb,index3_tb};

end