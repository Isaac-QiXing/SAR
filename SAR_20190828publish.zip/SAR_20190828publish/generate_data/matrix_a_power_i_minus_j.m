function S = matrix_a_power_i_minus_j(a,n)
    % generate a squared n-by-n matrix with s_ij = a^|i-j|
    %  Inputs:
    %   a: a positive scalar 
    %   n: a positive integer indicating the order of the matrix S
    
    S = zeros(n,n);
    
    v = power(a,abs(1-n:1:n-1))'; % v has length of 2*n-1
    
    for ii=1:n
        ia = n-ii+1;
        S(:,ii) = v( ia:ia+n-1);
        
    end
    
end