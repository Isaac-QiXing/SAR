function s=timeStamp(varargin)
% varargin{1}: optional a nonnegative integer  as the  seed if random
%    generator; 
%   s: string of time stamp; 
%
%  usage: 
%   
%  eg 1.  s = timeStamp();
%  eg 2.  s = timeStamp(1);
%  eg 3. 
%       parfor ii=1:10
%           s = timeStamp(ii);
%       end

seed = [];
if nargin>0
    seed = varargin{1};
end

if isempty(seed) || seed<0
    rng('shuffle');
else
    rng(seed);  
end
    
    s = [datestr(now,30),'_' num2str(round(rand(1)*1E8))];
end