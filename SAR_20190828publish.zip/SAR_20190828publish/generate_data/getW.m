function [W, W_noise] = getW(arg)
% generate  spatial weighting matrix, W
%  arg: parameters of samples
%   arg.n_sample: a   positive integer, indicating the number of samples
%   arg.m: a positive integer, used to generated spatial weight matrix W, note that
%       arg.n_sample should be divided by arg.m
%   arg.W: optional, a user-specified spatial squared weighting matrix. default value: [].
%       If arg.W is specified, then arg.n_sample and arg.m takes no effect.
%   arg.y: optional, the response vector, with size arg.n_sample-by-1, effective only if 
%       arg.mode =='matthew';
%   arg.mode: mode of noisy weights
%     'dense':  increase nonzeros randomly in specified rows of W;
%     'sparse': set certain number of nonzeros  to zero randomly in specified rows of  W;
%     'random':  replace  all the nonzeros of a certain number of rows of W  with randomly
%        selected other nonzeros in those rows. 
%        e.g. select i-th row,   there are 3 nonzeros W(i,[ 1 3 5]),
%           then 
%                   set W(i,[1,3,5]) = 0;  randomly set W(i,[ 2 ,19,7]) = [1/3,1/3,1/3];
%     'matthew':  replace  all the nonzeros of a certain number of rows of W  with special 
%           nonzero columns.
%        e.g. select i-th row, arg.y(i)>0, and  there are 3 nonzeros W(i,[ 1 3 5]), 
%           then 
%                   set W(i,[1,3,5]) = 0;  
%                   set W(i,[ 4 ,8]) = [1/3,1/3,1/3];
%           with y([4, 8,9] ) the largest three elements of y; 
%     'null':   no additional operations on the elements of W
%   arg.ratioRow: optional,a positive scalar in [0,1], indicating the propotion of  rows for
%      adding or excluding nonzeros, the parameter is effective if
%      arg.mode~= 'null' , default value: 1.0;
%   arg.ratioColumn: optional, a positive scalar in [0,1], propotion of increased or excluded nonzeros to the
%      number of original nonzeros in each specified rows of W; the parameter is effective if
%      arg.mode~= 'null' ,  default value: 0.5
%   
% Output:
%   W: weighting matrix without noise
%   W_noise: weighting matrix with noise if arg.mode~='null'
%
% Versions
%   2019.7.16
%   ** fix a bug of checking arg.m
%   ** fix a bug of initializing arg.n_sample
%   2019.7.8 
%       * add arg.mode: 'random', 'matthew'
%   2019.4.26 first version
%
debug_on = 0;

% set arg.n_sample
if isfield(arg,'W') && isempty(arg.W)
    arg.n_sample = size(arg.W,1);
end

% % % if ~isfield(arg,'n_sample') || isempty(arg.n_sample)
% % %     arg.n_sample
% % % end
    



% set default parameters
arg = completeArg(arg,{'W','mode','ratioRow','ratioColumn','y','m'},{[],'null',1.0,0.5,[],[]});

% check arg.m
if ~isempty(arg.m)&& mod(arg.n_sample,arg.m)~=0
    error('arg.n_sample should be divided by arg.m');
end

% 1. generate spatial weight matrix W
%n_sample = arg.n_sample ;

if isempty(arg.W)
    n_sample = arg.n_sample ;
    m = arg.m;
    Bm = 1/(m-1)* (ones(m,m)-eye(m,m));
    r = n_sample/m;
    W = kron(eye(r,r),Bm);
else
    W = arg.W;
    n_sample = size(W,1);
end

if debug_on
    fwritef(1,'arg',arg,'');      
end
    
% 2. generate the noisy matrix W_noise
W_noise = W;  % initialize W_noise
indexRow = randperm(n_sample, round(arg.ratioRow * n_sample));

arg.mode = lower(strtrim(arg.mode));
if  strcmpi(arg.mode, 'dense') && ~isempty(indexRow)
    % 2.1.1 number of nonzeros to be added in specified row of W
    nnz_W_row_act = zeros(1,n_sample);
    nnz_W_row = round(sum(W~=0,2) * arg.ratioColumn);    
    nnz_W_row = min(n_sample,nnz_W_row);
    nnz_W_row_act(indexRow) =  nnz_W_row(indexRow);
    % nnz_W_row_act(i): number of nonzeros of to be added for the i-th row
    % 2.1.2 select the specified number of column indices  randomly in each row
    if max(nnz_W_row_act)>=1
        index_W_noise = logical(zeros(n_sample,n_sample));
        
        ind_row = [1:n_sample]';
        ind_col = nnz_W_row;
        ii_row = find(nnz_W_row_act >0);
        
        R = rand(n_sample,n_sample);
        R2 = R;
        R2(ii_row,:) = sort(R(ii_row,:),2,'descend');
        
        linearInd = zeros(n_sample,1);
        linearInd(ii_row) = sub2ind(size(W), ind_row(ii_row), ind_col(ii_row));
        thresh_v =  columnVec( R2(linearInd(ii_row)) );
        
        Thresh  = thresh_v * ones(1,n_sample);
        
        index_W_noise(ii_row,:) =   (R(ii_row,:)>=Thresh);
        if debug_on
            index_W_noise
        end
    else
        return;
    end
    % 2.1.3 add a noisy positive weight on the selected index (i,j) and then standarize
    %    each row
    %%%if strcmpi(arg.mode, 'dense')
        W_noise(index_W_noise) = W_noise(index_W_noise) + R(index_W_noise);
    %%%else %  strcmpi(arg.mode, 'random')
      %%%   W_noise(index_W_noise) =  R(index_W_noise);
% % %     end
    W_noise = standardize_sumToone(W_noise, 2);
elseif strcmpi(arg.mode, 'sparse')&& ~isempty(indexRow)
    % 2.2.1 number of nonzeros to be removed in specified row of W
    if arg.ratioColumn>1 || arg.ratioColumn <0
        error('arg.ratioColumn should be a number located in [0,1] in ''sparse'' mode');
    end
    nnz_W_row_act = zeros(1,n_sample);
    nnz_W_row = round(sum(W~=0,2) * arg.ratioColumn);    
    %%%nnz_W_row = min(n_sample,nnz_W_row);
    nnz_W_row_act(indexRow) =  nnz_W_row(indexRow);
    
    % nnz_W_row_act(i): number of nonzeros of to be removed for the i-th row
    
    % 2.2.2 randomly select the specified number of column indices to be removed  in each row
    if max(nnz_W_row_act)>0 
        
        index_W_noise = logical(zeros(n_sample,n_sample));
        
        ind_row = [1:n_sample]';
        ind_col = nnz_W_row;
        ii_row = find(nnz_W_row_act >0);
        
        R = rand(n_sample,n_sample).*W;
        R2 = R;
        R2(ii_row,:) = sort(R(ii_row,:),2,'descend');
        
        linearInd = zeros(n_sample,1);
        linearInd(ii_row) = sub2ind(size(W), ind_row(ii_row), ind_col(ii_row));
        thresh_v =  columnVec( R2(linearInd(ii_row)) );
        
        Thresh  = thresh_v * ones(1,n_sample);
        index_W_noise(ii_row,:) =   (R(ii_row,:)>=Thresh);
        if debug_on
            index_W_noise
        end
    else
        return;
    end
    % 2.2.3 remove the selected indices and then standarize each row
    W_noise(index_W_noise) = 0;
    W_noise = standardize_sumToone(W_noise, 2);
    
elseif ((strcmpi(arg.mode, 'matthew')) ||  strcmpi(arg.mode, 'random')) &&  ~isempty(indexRow)
    if isempty(arg.y) && (strcmpi(arg.mode, 'matthew'))
        warning('In ``matthew'' mode, arg.y should be specified');
        return;
    end
    % 2.1.1 number of nonzeros to be added in specified row of W
    nnz_W_row_act = zeros(1,n_sample);
    nnz_W_row = round(sum(W~=0,2) * arg.ratioColumn);    
    nnz_W_row = min(n_sample,nnz_W_row);
    
     nnz_W_row_act(indexRow) =  nnz_W_row(indexRow);
     
     %%%%
% %      indexRow
% %      nnz_W_row(indexRow)
     %%%%
  % nnz_W_row_act(i): number of nonzeros of to be set for the i-th row
    % 2.1.2 determine the   number of column indices   according the values of y
    flag_matthew = strcmpi(arg.mode, 'matthew');
    if max(nnz_W_row_act)>=1
        if flag_matthew
            [~,ind] =  sort(arg.y,'descend');        
        end
        for ii =1:length(indexRow)
            irow = indexRow(ii); % deal with irow-th row
            nnz_set = nnz_W_row(irow); % number of nonzeros  to be added             
            W_noise(irow,:) = 0; 
            if flag_matthew
                if arg.y(irow)>0
                    W_noise(irow,ind(1:nnz_set)) = 1;
                else
                    W_noise(irow,ind(end-nnz_set+1:end)) = 1;
                end
            else% arg.mode== 'random'
                ind0 = randperm(n_sample,nnz_set);
                W_noise(irow,ind0) = 1;
            end
        end
    else
        return;
    end    
    
    W_noise = standardize_sumToone(W_noise, 2);    
end

end