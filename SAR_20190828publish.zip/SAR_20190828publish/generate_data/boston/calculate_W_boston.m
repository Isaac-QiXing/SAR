% version
%  2019.8.13 
clear
clc

load('LONLAT.mat');
n = length(LONLAT);
W = zeros(n);
for i = 1:n
    for j = 1:i-1
       W(i,j) =  Distance_boston(LONLAT(i,:),LONLAT(j,:));
       W(j,i) = W(i,j);
    end
end
% A = zeros(1,n);
% for i = 1:n
%     A(i) = norm(W(:,i));
% end
% A = repmat(A,n,1);
% W = W./A;
for i = 1:n  
    W(i,:) = W(i,:)/sum(W(i,:));  
end  
stamp = timeStamp(); 
save('W_distance','W','stamp');