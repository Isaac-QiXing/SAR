function dist = Distance(A,B)
% calculte the diatance of two points(A,B) by longitude and latitude
%   A,B: are vector of two points' longitude and latitude. A:(lonA,latA),B:(lonB,latB)
%        negetive if located at east longitude and positive else.
%   dist: is the distance of two points,unit:km
R = 6371.004; % unit:km
A = pi*A/180;
B = pi*B/180;
angle = sin(A(2))*sin(B(2)) + cos(A(2))*cos(B(2))*cos(A(1) - B(1));
dist = R*acos(angle);