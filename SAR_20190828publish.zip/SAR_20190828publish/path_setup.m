function path_setup()
% set up the path.
% this function is to be called any time the package is stalled on a new
% machine to ensure that the paths are set properly.

% add paths to Matlab serching path
currPath = fileparts(mfilename('fullpath')); % current path
subpaths = {'','lib_m','lib_var','generate_data','Lasso_ISTA'};
for ii=1:length(subpaths)
    path_str = subpaths{ii};
    path_full_str = [currPath filesep path_str];
    if exist(path_full_str,'dir')
        addpath(path_full_str);
    end
end
savepath; % save the current path


%if flag_success
    fprintf('Succeed to set up the path of SAR.\n');
%end
end
