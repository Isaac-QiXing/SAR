% main_var_spa_select
% versions
%   * 2019.7.24
%      **  set par_opt.lambda manually if flag_cv = 0 and cross-validation file do not exist
%      ** use parfor loops for all the tested cases
%   * 2019.5.8  set cross-validation searching parameters
%   * First version. 2019.4.5.

clc
clear

flag_have_a_try =1;  % 1 or 0, whether just have a try to see whether the code run well
debug_on = 0;  % 1 or 0, indicating the debug mode or not

time_str = timeStamp();
dataPath = ['E:\data_var_selection\dataVarSel_' datestr(now,29) '\'];
resultFile = [dataPath 'result_var_select_' time_str '.mat'];

dataPath0 = ['E:\data_var_selection\dataVarSel_' '2019-07-24' '\'];
cvFile = [dataPath0 'result_cv_' '2019-07-24' '.mat'];

if ~exist(dataPath,'dir')
    mkdir(dataPath);
end

if flag_have_a_try
    max_ite_CCCP_batch = 500;
    verbose = 0;% 3; %3;
    test_case_v  = 1:2; % 6:6; % 1:1;% %1; %65:65;
    %n_test_case0 = 1; % 5 %2
    %n_parModel0 = 9;
    
    i_model_v = 1:2; % 3:3; % 2:2; % 1:1; %1:9; %[7]; % 1:9,
    n_repeat = 1; %2
    
    flag_cv = 0; % 1;  % whether to operate cross-validation
    flag_parfor = 0; % whether to operate parfor
else
    max_ite_CCCP_batch = 500;
    verbose =  0; % 1;
    n_repeat =  30; %100;
    
    flag_cv = 0; %1;
    flag_parfor = 0; %1;
    test_case_v = [];
end



%thresh_nnz_beta = 0.2;
[thresh_nnz_beta] = problemArg('thresh_nnz_beta');

% 1.1 generate model parameter
%loss_c = {'exp-square','square'};
loss_c = {'exp-square','square','lad'};
regularizer_c = {'l1', 'adaptive-l1','null'};% 'SCAD',

n_parModel =  length(loss_c)*length(regularizer_c);


parModel_c = cell(1,n_parModel);
i_model = 1;
for i_loss = 1:length(loss_c)
    for i_reg = 1:length(regularizer_c)
        parModel.loss = loss_c{i_loss};
        parModel.regularizer = regularizer_c{i_reg};
        parModel.a=  3.7; % 2.0
        parModel_c{i_model} = parModel;
        i_model = i_model + 1;
    end
    
end


% 1.2 algorithm parameter

%par_alg.TolFun = 1E-5;
%par_alg.TolX = 1E-4;
par_alg.TolFun = 1E-5;
par_alg.TolX = 1E-5;

par_alg.verbose  = verbose;

par_alg.maxIter =  max_ite_CCCP_batch;
par_alg.maxIter_spa = 8;

% 2. generate data parameters

index_c = [];
for ii=n_repeat:-1:1
    %     [data] = getSpregData(par_st(ii));
    %     data_c{ii} = data;
    if ii==n_repeat
        [par0_st,index_c]= getSpregData_para();
    else
        [par0_st]= getSpregData_para();
    end
    par_st_m(ii,:)= par0_st;
    % par_st_m a n_repeat-by-n_case struct matrix consisting of the parameters
end



% specify number of tested cases
n_test_case = size(par_st_m,2);

if ~flag_have_a_try
    test_case_v = 1:n_test_case;
end
% specify i_model_v
if ~flag_have_a_try
    i_model_v = 1:n_parModel;
end
n_model = length(i_model_v);
% 3 variable selection


% 3.0 initialize the accuracy measures
zeros3 = zeros(n_test_case,n_parModel,n_repeat);
sol_c = cell(n_test_case,n_parModel,n_repeat);
%%%par_opt_c = cell(n_test_case,n_parModel,n_repeat);
iteInf_c = cell(n_test_case,n_parModel,n_repeat);
par_opt_c =  cell(n_test_case,n_parModel);


% acc.TP = zeros3;
% acc.FP = zeros3;
% acc.TN= zeros3;
% acc.FN= zeros3;
% acc.resNorm = zeros3;
% acc.MSE = zeros3;
% acc.sol_1= zeros3;
% acc.sol_2= zeros3;
% acc.sol_3= zeros3;
% acc.time  = zeros3; % elapsed time

TP_m = zeros3;
FP_m = zeros3;
TN_m= zeros3;
FN_m= zeros3;
resNorm_m = zeros3;
MSE_m = zeros3;
rho_ite_m = zeros3;
rho_mse_m = zeros3;
dev_m = zeros3;
sol_1_m= zeros3;
sol_2_m= zeros3;
sol_3_m= zeros3;
time_m  = zeros3; % elapsed time



% % % if ~flag_cv
% % %     cv = load(cvFile,'par_opt_c');
% % % end
poolobj = [];
if flag_parfor
    delete(gcp); % To terminate the existing session
    poolobj = parpool;
end



parfor i_case = test_case_v %%%1:n_test_case
% for i_case = test_case_v %%%1:n_test_case
    par_st_v = par_st_m(:,i_case);
    
    par_opt0_c = cell(1,n_parModel);
    zeros2 = zeros(n_parModel,n_repeat);
    TP_mm = zeros2;
    FP_mm = zeros2;
    TN_mm= zeros2;
    FN_mm= zeros2;
    resNorm_mm = zeros2;
    MSE_mm = zeros2;
    rho_ite_mm = zeros2;
    rho_mse_mm = zeros2;
    dev_mm = zeros2;
    sol_1_mm= zeros2;
    sol_2_mm= zeros2;
    sol_3_mm= zeros2;
    time_mm  = zeros2; % elapsed time
    
    sol_ccc = cell(n_parModel,n_repeat);
    iteInf_ccc = cell(n_parModel,n_repeat);
    
    
    fileName_cv = [];
    if flag_cv
        %[data_st] = getSpregData(par_st_m(1,i_case)); % get data
        [data_st] = getSpregData(par_st_v(1)); % get data
        fileName_cv =   [dataPath 'data_cv_' timeStamp(i_case) '.mat'];
        %save(fileName_cv,'-struct','data_st');
        saveStructMat(fileName_cv,data_st);
    end   
  
    
    for i_model = i_model_v %1:n_parModel
        %for ii_m = 1:n_model %1:n_parModel
        %    i_model = i_model_v(ii_m);
        fprintf(1,'(i_case,i_model): (%d,   %d)/(%d,  %d)\n',...
            i_case,i_model,n_test_case,n_parModel);
        % 3.1 cross validation  to determine the value of lambda, i.e., the weight of regularization term (if any)
        parModel = parModel_c{i_model};
        %%fileName = file_c{i_case,1};
        
        if flag_cv
            par_alg2 = completeArg(par_alg,fieldnames(parModel),parModel);
            par_alg2.search_gamma = 0;
            % the parameter gamma (of the Exponential-square loss) is calculated manually
            par_alg2.search_rho = 0;
            % the parameter rho is updated iteratively
            par_alg2.search_lambda = 1;
            %n_sample = par_st_m(1,i_case).n_sample;
            n_sample = par_st_v(1).n_sample;
            lambda = log(n_sample)/n_sample;
            %par_search.lambda = [ 2^(-9) 2^(-6)  2^(-3)   ]*lambda;
            par_search = struct();
            par_search.lambda = [  2^(-6)  2^(-3)   ]*lambda;
            par_opt = var_cv(fileName_cv,parModel.loss,parModel.regularizer,par_alg2,par_search);
            %par_opt_c{i_case,i_model} = par_opt;
            par_opt0_c{i_model} = par_opt;            
            %save(cvFile,'par_opt_c');
            %             saveData(cvFile,'par_opt_c',par_opt_c);
        else
            if exist(cvFile,'file') && varIsInMat('par_opt_c',cvFile)
                cv = load(cvFile,'par_opt_c');
                par_opt = cv.par_opt_c{i_case,i_model};
                fprintf(1,'CV file found.\t');
            else
                %n_sample = par_st_m(1,i_case).n_sample;
                n_sample = par_st_v(1).n_sample;
                lambda = log(n_sample)/n_sample;
                par_opt.lambda =   2^(-6)  *lambda;
                warning('CV file is not found, use specified value of lambda.');
            end
        end
        % 3.1.2 put out par_opt.lambda
        if isfield(par_opt,'lambda') && ~isempty(par_opt.lambda)
            fwritef(1,'  par_opt.lambda: ',par_opt.lambda,'');
        end
        % 3.1.3 assign the selected value to parModel
        if isfield(par_opt,'lambda')&& ~isempty(par_opt.lambda)
            parModel.lambda = par_opt.lambda;
        end
        
        % 3.2 variable  selection
        % 3.2.1 initialization and assign parameters
        acc_t = struct('MSE',cell(1,n_repeat),'TP',[],'FP',[],'TN',[],'FN',[]);
        sol0_c = cell(1,n_repeat);
        iteInf0_c = cell(1,n_repeat);
        resNorm_v = zeros(1,n_repeat);
        time_v = zeros(1,n_repeat);
        dev_v= zeros(1,n_repeat);
        rho_min_v= zeros(1,n_repeat);
        rho_true_v = zeros(1,n_repeat);
        
        
        %parfor i_repeat = 1:n_repeat
        for i_repeat = 1:n_repeat
            %         for i_repeat = 1:n_repeat
            %fprintf(1,'(i_case,i_model,i_repeat): (%d, %d, %d)/(%d, %d, %d)\n',...
            %    i_case,i_model,i_repeat,n_test_case,n_parModel,n_repeat);
            fprintf(1,'=');
            
            %fileName = file_c{i_case,i_repeat};
            %             d = load(fileName,'arg', 'X', 'beta','y_fix','y_reg','y','W','rho');
            %para_fileName = [dataPath 'temp_data_para_' time_str '_' num2str(i_repeat) '.mat'];
            %para_fileName = [dataPath 'temp_data_para_' timeStamp(i_case*1000+i_model) '_' num2str(i_repeat) '.mat'];
            %para_t = load(para_fileName);
            
            par_i = par_st_v(i_repeat);
                      
            %d = getSpregData(para_t.par); % get data
            d = getSpregData(par_i); % get data
            
            parModel2 = parModel;  % used to be saved in the output file
            parModel3 = parModel;
            parModel3.W = d.W;
            rho_true_v(i_repeat) = d.rho;
            % 3.2.2 variable selection
            tic
            %[sol,resNorm,~,iteInf] = var_select(d.X, d.y_fix, parModel,par_alg);
            if debug_on
                fwritef(1,'par_alg',par_alg,'');
            end
            [sol,rho_min,dev, iteInf] = var_spa_select(d.X, d.y, d.y_reg,parModel3,par_alg);
            t = toc;
            iteInf.parModel = parModel2;
            iteInf.parAlg = par_alg;
            resNorm = iteInf.resNorm;
            % 3.2.3 calculate accuracy
            [acc0] = var_accuracy(sol,d.beta,thresh_nnz_beta);
            acc_t(i_repeat) = acc0;
            resNorm_v(i_repeat) = resNorm;
            rho_min_v(i_repeat) = rho_min;
            if ~isempty(dev)
                dev_v(i_repeat) = dev;
            end
            sol0_c{i_repeat} = sol;
            iteInf0_c{i_repeat} = iteInf;
            time_v(i_repeat) = t;
        end % end parfor
        
        % 3.2.4 assign results
        %  (1) assign acc
        %             acc.TP(i_case,i_model,:) = [acc_t(:).TP];
        %             acc.FP(i_case,i_model,:) = [acc_t(:).FP];
        %             acc.TN(i_case,i_model,:) = [acc_t(:).TN];
        %             acc.FN(i_case,i_model,:) = [acc_t(:).FN];
        %             acc.MSE(i_case,i_model,:) = [acc_t(:).MSE];
        %             acc.resNorm(i_case,i_model,:) = resNorm_v;
        %             acc.time(i_case,i_model,:) = time_v;
        %             acc.rho_ite(i_case,i_model,:) = rho_min_v; % the calculated values of rho
        %             acc.rho_mse(i_case,i_model,:) =  (rho_min_v - rho_true_v).^2;
        %             acc.dev(i_case,i_model,:) = dev_v;
        %              TP_m(i_case,i_model,:) = [acc_t(:).TP];
        %              FP_m(i_case,i_model,:) = [acc_t(:).FP];
        %              TN_m(i_case,i_model,:) = [acc_t(:).TN];
        %              FN_m(i_case,i_model,:) = [acc_t(:).FN];
        %              MSE_m(i_case,i_model,:) = [acc_t(:).MSE];
        %              resNorm_m(i_case,i_model,:) = resNorm_v;
        %              time_m(i_case,i_model,:) = time_v;
        %              rho_ite_m(i_case,i_model,:) = rho_min_v; % the calculated values of rho
        %              rho_mse_m(i_case,i_model,:) =  (rho_min_v - rho_true_v).^2;
        %              dev_m(i_case,i_model,:) = dev_v;
        
        TP_mm( i_model,:) = [acc_t(:).TP];
        FP_mm( i_model,:) = [acc_t(:).FP];
        TN_mm( i_model,:) = [acc_t(:).TN];
        FN_mm( i_model,:) = [acc_t(:).FN];
        MSE_mm( i_model,:) = [acc_t(:).MSE];
        resNorm_mm( i_model,:) = resNorm_v;
        time_mm( i_model,:) = time_v;
        rho_ite_mm( i_model,:) = rho_min_v; % the calculated values of rho
        rho_mse_mm( i_model,:) =  (rho_min_v - rho_true_v).^2;
        dev_mm( i_model,:) = dev_v;
        
        
        
        %   (2) assign sol_c
        %sol_c(i_case,i_model,:) = sol0_c;
        sol_ccc(i_model,:) = sol0_c;
        for iii_repeat=1:n_repeat
            sol_i = sol0_c{iii_repeat};
            %                 acc.sol_1(i_case,i_model,iii_repeat) = sol_i(1);
            %                 acc.sol_2(i_case,i_model,iii_repeat) = sol_i(2);
            %                 acc.sol_3(i_case,i_model,iii_repeat) = sol_i(3);
            %                 sol_1_m(i_case,i_model,iii_repeat) = sol_i(1);
            %                 sol_2_m(i_case,i_model,iii_repeat) = sol_i(2);
            %                 sol_3_m(i_case,i_model,iii_repeat) = sol_i(3);
            sol_1_mm( i_model,iii_repeat) = sol_i(1);
            sol_2_mm( i_model,iii_repeat) = sol_i(2);
            sol_3_mm( i_model,iii_repeat) = sol_i(3);
        end
        % (3) assign iteInf
        %iteInf_c(i_case,i_model,:) = iteInf0_c;
        iteInf_ccc(i_model,:) = iteInf0_c;
        
        fprintf(1,'\n');
        %save(resultFile,'acc','sol_c','iteInf_c');
    end % end loop of i_model
    
    
    
    TP_m(i_case,:,:) =  TP_mm;
    FP_m(i_case,:,:) =  FP_mm;
    TN_m(i_case,:,:) =  TN_mm;
    FN_m(i_case,:,:) =  FN_mm;
    MSE_m(i_case,:,:) =  MSE_mm;
    resNorm_m(i_case,:,:) =  resNorm_mm;
    time_m(i_case,:,:) = time_mm;
    rho_ite_m(i_case,:,:) =  rho_ite_mm;
    rho_mse_m(i_case,:,:) =   rho_mse_mm;
    dev_m(i_case,:,:) =  dev_mm;
    sol_1_m(i_case,:,:) = sol_1_mm;
    sol_2_m(i_case,:,:) = sol_2_mm;
    sol_3_m(i_case,:,:) = sol_3_mm;
    
    par_opt_c(i_case,:) = par_opt0_c;
    sol_c(i_case,:,:) = sol_ccc;
    iteInf_c(i_case,:,:) = iteInf_ccc;
    
        % delete the mat file    fileName_cv
        if  flag_cv && exist(fileName_cv,'file')
            delete(fileName_cv);
        end
% % %     % delete temparay mat data parameter file
% % %     for ii = 1:n_repeat
% % %         if exist(file_para_c{ii},'file')
% % %             delete(file_para_c{ii});
% % %         end
% % %     end
end % end loop of i_case

% save result file
acc.TP = TP_m;
acc.FP =FP_m;
acc.TN=TN_m;
acc.FN=FN_m;
acc.MSE=MSE_m;
acc.resNorm= resNorm_m;
acc.time= time_m;
acc.rho_ite= rho_ite_m; % the calculated values of rho
acc.rho_mse=   rho_mse_m;
acc.dev= dev_m;
acc.sol_1 = sol_1_m;
acc.sol_2 = sol_2_m;
acc.sol_3 = sol_3_m;
save(resultFile,'acc','sol_c','iteInf_c');
save(cvFile,'par_opt_c');
%save(resultFile,'index_tb','-append');
save(resultFile,'index_c','-append');


if ~isempty(poolobj)
    delete(poolobj);
end

