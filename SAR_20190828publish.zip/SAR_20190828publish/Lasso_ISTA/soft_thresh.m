function [y,varargout]= soft_thresh(x,t)
% soft thresholding operation on a vector
%    y(i) = sgn(x(i)) * max(|x(i)|-t,0),   if t is a scalar
%    y(i) = sgn(x(i)) * max(|x(i)|-t_i,0),   if t is a scalar
% this operator is also called shrinkage operator
% Inputs:
%   x: a vector;
%   t: a nonnegative scalar or a vector of nonnegative scalars with the same size as x;
% Outputs:
%   y: a vector with same size as x, the result of the operation;
%  varargout{1}: a vector with same size as x: varargout{1} = x-y;
% Version
%  * 2019.3.7  t is generalized as a vector ( the code is not updated)
%  * 2013. the first version

y = sign(x) .* max(abs(x)-t,0);
if nargout>1
    varargout{1} = x-y;
end

end
