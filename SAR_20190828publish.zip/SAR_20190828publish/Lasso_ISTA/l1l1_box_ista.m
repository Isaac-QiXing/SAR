function [x,fval,ite_s] = l1l1_box_ista(A,y,w,lambda,arg)
% solve the l1-regularized least l1 with box-constraints by ISTA (or
% FISTA)
%   This function  solves
%       min_{x}  ||Ax-y||_1  +  lambda* sum_i |x_i * eta_i| 
%       s.t.    w_i*|x_i| <= 1,
%   where w_i>=0 is scale factor, i = 1,...,n�� eta_i >=0, 
%   lambda>0 is a given parameter. 
% Inputs:
%	A           A m-by-n matrix, with m<=n;
%	y           vector of length m.
%   w           the scale factors. 
%   lambda      a given postive scalar;  
%   arg         Optional, a structue with following fields:
%   .x0: a column vector, indicating the initial point;
%   .solver: 
%      'ista': employ backward iterative shrinkage thresholding algorithm;
%      'fista': employ fast backward iterative shrinkage thresholding
%          algorithm; default value;
%   .eta: optional, a  vector with the same size as arg.x0, each coordinate is nonnegative; 
%        default value [], arg.eta would set as [1,1,...1]';   
%   .maxIter: maximum iteration number, default 1E4;
%   .TolX: termination tolerence of solution x; default 1E-4;
% Outputs:
%  x: optimal solution;
%  fval: ojective function value;
%  ite_s: a struct consisting of the iteration infromation:
%     .exitflag: 
%       1: succeed to solve;
%       -1: exceeds the maximum iteration number;
%     .iterations: iteration number;
%     .fun_num: number of function evaluations;
%     .grad_num: number of gradient evaluations;
% Versions: 
% * 2019.3.11  first version. 

A_trans = A';
fun = @(x) norm(A*x-y,1);
grad = @(x) sum(A_trans * diag(sign(A*x-y)),2);
dim = size(A,2);
arg.box = w;

if ~isfield(arg,'eta') || isempty(arg.eta)
    arg.eta = ones(dim,1);
end
[x,fval,ite_s] = ista(fun,grad,lambda,dim,arg);

end