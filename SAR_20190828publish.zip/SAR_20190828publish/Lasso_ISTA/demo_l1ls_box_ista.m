% demo to test l1ls_box_ista
%

clear,clc
size=[50,70];
n = size(1);
dim = size(2); 

% A = ones(size(1),size(2));
% y = ones(size(1),1);
A = rand(size(1),size(2));

x_true = rand(size(2),1);
x_true(x_true<0.7) = 0;
%noise_v = random('Normal',0,1,n,1);
noise_v = zeros(n,1);
y = A*x_true + noise_v;

%y = rand(size(1),1);

% for i=1:size(1)
%     A(i,:)=A(i,:)*i;
%     y(i)=y(i)*(10-i);
% end
w=[];
lambda =  0.5* norm(A,1);
arg.x0 = ones(size(2),1);
%arg.solver = 'ista';
arg.solver = 'fista';
arg.eta = [];
%arg.eta = (rand(size(2),1))/10;
arg.maxIter = 400;
% arg.TolX = 1e-3;


%[x,fval,ite] = l1ls_box_ista(A,y,w,lambda,arg);
 [x,fval,ite] = l1l1_box_ista(A,y,w,lambda,arg);
err = norm(A*x-y);
mse = norm(x-x_true);
nnz_x = nnz(x);
fprintf(1,'norm(y): %f\t err: %f\t mse: %f\t nnz_x: %d nnz_x_ture: %d\n',norm(y),err,mse, nnz_x,nnz(x_true)); 
