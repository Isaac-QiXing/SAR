function [x,fval,ite_s] = ista(fun,grad,c,dim,arg)
% Iterative Shrinkage Thresholding Algorithm to solve 
%      min_{x in Omega} f(x) + c phi(x)
%  with f:R^n -->R smooth and having Lipschitz continous gradient,
%   c>0 a constant, phi(x) the l1 norm (or the weighted l1 norm) of x
%            phi(x) = sum_i eta_i*|x_i|,
%   where eta_i=  1     for l1 norm, and eta_i>=0 for weighted l1 norm
%
% Inputs:
%  fun: function handle of f(x)
%  grad: function handle of the gradient function of f(x)
%  c: a positive scalar;
%  dim: number of the elements of the solution;
%  arg: Optional, a struct consisting of the parameters
%   .x0: a column vector, indicating the initial point;
%   .eta: optional, a  vector with the same size as arg.x0, each coordinate is nonnegative; 
%        default value [1,1,...1]';   
%   .solver: 
%      'ista': employ backward iterative shrinkage thresholding algorithm;
%      'fista': employ fast backward iterative shrinkage thresholding
%          algorithm; default value;
%   .maxIter: maximum iteration number, default 1E4;
%   .TolX: termination Tolerence of solution x; default 1E-4;
%   .box: a n-by-1 vector indicating the box constraint for the feasible set
%      of variable x: 
%           Omega = {x : w_i*|x_i| <=1 }
%       default [] (no box constraint, Omega := R^n);
% Outputs:
%  x: optimal solution;
%  fval: ojective function value;
%  ite_s: a struct consisting of the iteration infromation:
%     .exitflag: 
%       1: succeed to solve;
%       -1: exceeds the maximum iteration number;
%     .iterations: iteration number;
%     .fun_num: number of function evaluations;
%     .grad_num: number of gradient evaluations;
%
% Versions: 
% * 2019.5.25 fix a bug of the output optimal function value
% * 2019.3.7 generalize the l1 norm as the weighted l1 norm
%    add a parameter 
%       arg.eta
% * 2013.12 first version. 


debug_on = 1;

% set the argument
if nargin<=4
    arg = struct();
end
arg = completeArg(arg,{'x0','solver','maxIter','TolX','box','eta'},...
            {zeros(dim,1),  'fista',  1E3,1E-4,[],[]},[]);

ite_s = struct('exitflag',0,'iterations',0,'fun_num',0,'grad_num',0);
flag_ista = strcmpi(arg.solver,'ista'); % whether employ ISTA iteration
flag_box = ~isempty(arg.box) && norm(arg.box,1)>1E-15; % whether a box feasible set has been set

if ~isempty(arg.eta)
    if length(arg.eta)~= dim
        error('arg.eta should have the same size as the initial point x0.' );
    end
    %c = c*arg.eta;  
    weight_feature_v = c*arg.eta;  
else 
    weight_feature_v = c;
end

% iteration
L1 = 1; % estimation of the Lipschitz constant
eta = 2;
ite = 1;
ite_L_max = 30; % maximum iteration number for serching Lipschitz constant
fun_num = 0;
x0 = arg.x0;
y1 = x0;
t0 = 1;
while 1
    % stopping criteria 
    if ite>arg.maxIter
        ite_s.exitflag = -1;
        break;
    end
    % find the smallest nonnegative integer k, with L1 = eta^k * L0:
    %   F(p_L1(y1)) <= Q_L1 (p_L1(y1),y1)
    %  <==> f(x1) <= f(y1) + <x1-y1, grad(y1)> + 0.5L||x1-y1||^2
    % where x1:=p_L1(y1),
    %       F(x) = f(x) + c |x|_1 
    %       Q_L(x,y) = f(x) + <x-y,grad f(y)> + 0.5L|x-y|^2 + c |x|_1
    ite_L = 0;
    fy1 = fun(y1);
    grad0 =grad(y1);
    fun_num = fun_num + 1; % fun_num: number of calling the function values
    while 1
        %%%x1= soft_thresh(y1-1/L1*grad0,c/L1); %p_L1(y1);
        x1= soft_thresh(y1-1/L1*grad0,weight_feature_v/L1); %p_L1(y1);
        if flag_box % box constraints has been set
            x1= proj_box(x1,arg.box); %project x1 to the box
        end
        err = x1 - y1;
        fx1 = fun(x1);
        fun_num = fun_num + 1;
        if fx1 <= fy1 + dot(err,grad0) + 0.5*L1*dot(err,err) 
            break;
        end
        if ite_L>ite_L_max
            if debug_on
                fprintf('ite %d: exceeds the maximum iteration number to determine L.',ite);
            end
            break;
        end
        ite_L = ite_L + 1;
        L1 = L1 * eta;
    end % when the loop terminate we obtain a new iteration point x1 
    ite = ite + 1;    
    if norm(x1-x0)/max(norm(x1),1) < arg.TolX
        ite_s.exitflag = 1;
        break;
    end        
    % update y1,x0
    if flag_ista
        y1 = x1;
        x0 = x1;
    else % FISTA
        t1 = 0.5*(1+sqrt(1+4*t0*t0)); % calculate t1
        y1 = x1 + (t0-1)/t1 * (x1-x0); 
        x0 = x1;
        t0 = t1; % update t0
    end
end
% output
x = x1;
if isempty(arg.eta)
    fval = fun(x) + c*norm(x,1);  
else
    fval = fun(x) + c*norm(x.*arg.eta,1);  
end
fun_num = fun_num + 1;
ite_s.iterations = ite;
ite_s.fun_num = fun_num;
ite_s.grad_num = ite;
    % the number of calling the gradients equals the iteration number
end