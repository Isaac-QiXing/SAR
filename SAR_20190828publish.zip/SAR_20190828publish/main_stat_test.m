function main_stat_test

% version
%  * 2019.8.8

%  compare the results of the exp-square loss with  the square loss and the LAD loss

clc
clear

% 0. load data
dataPath ='.\result\';

resultFile1 = [dataPath 'result20190807-repeat30-129cases\result_var_select_20190807T161055_67839602.mat'];

dt = load(resultFile1,'result_s' , 'result1_s', 'result2_s','result3_s','index_c');
result1_s= dt.result1_s;
result2_s= dt.result2_s;
result3_s= dt.result3_s;
index_c = dt.index_c;
% only keep  index-outlier = 1, 2 (i.e., the value of 0.01, 0.05)
index2_tb = index_c{2};
ind2 = index2_tb.weight_outlier <= 2; % 1 or 2
selectRows = @(mat) mat(ind2,:);

field_c =   {'MedSE','TN'};
for ii=1:length(field_c)
    field = field_c{ii};
    result2_s.(field) = selectRows(result2_s.(field));
end

result1_s.MedSE = -1.0 * result1_s.MedSE; % since the largest value would be given 1st rank
result2_s.MedSE = -1.0 * result2_s.MedSE;
result3_s.MedSE = -1.0 * result3_s.MedSE;

matResultFile = [dataPath 'result_stat_var_select_' datestr(now,29) '.mat'];


% the two columns of each of gmean, ..., kappa are OS-ELM, BOW-ELM


% 1. On the results of the table 1-1 and 1-2
field_penalty_c = {'MedSE','TN'};
field_nopenalty_c = {'MedSE'};
method_ind_penalty = [ 1:2, 4:5,7:8];
method_ind_nopenalty = [3,6,9];


dt =  result1_s;
field_c = field_nopenalty_c;
ind_method = method_ind_nopenalty;
varName = 'stat_table01';
getStat(dt,field_c,ind_method,matResultFile,varName);

% 2. On the results of the table 3-1 and 3-2
dt =  result1_s;
field_c = field_penalty_c;
ind_method = method_ind_penalty;
varName = 'stat_table03';
getStat(dt,field_c,ind_method,matResultFile,varName);

% 3. On the results of the table 2-1 and 4-1, wiht outliers in y
dt =  result2_s;
field_c = field_nopenalty_c;
ind_method = method_ind_nopenalty;
varName = 'stat_table02_1';
getStat(dt,field_c,ind_method,matResultFile,varName);

dt =  result2_s;
field_c = field_penalty_c;
ind_method = method_ind_penalty;
varName = 'stat_table04_1';
getStat(dt,field_c,ind_method,matResultFile,varName);

% 4. On the results of the table 2-2 and 4-2, wiht outliers in W
dt =  result3_s;
field_c = field_nopenalty_c;
ind_method = method_ind_nopenalty;
varName = 'stat_table02_2';
getStat(dt,field_c,ind_method,matResultFile,varName);

dt =  result3_s;
field_c = field_penalty_c;
ind_method = method_ind_penalty;
varName = 'stat_table04_2';
getStat(dt,field_c,ind_method,matResultFile,varName);

end

function getStat(dt,field_c,ind_method,matResultFile,varName)
tol = 0.01;
n_field = length(field_c);
for ii=n_field:-1:1
    field = field_c{ii};
    Acc = dt.(field)(:,ind_method);
    alpha= 0.05;
    [stat_005(ii)] = friedman_f(Acc,tol,alpha);   %
    alpha= 0.1;
    [stat_01(ii)] = friedman_f(Acc,tol,alpha);
end

if ~exist(matResultFile,'file')
    saveData(matResultFile,[varName '_005'],stat_005,  [varName '_01'],stat_01);
else
    saveData(matResultFile,[varName '_005'],stat_005,  [varName '_01'],stat_01,'-append');
end
end
