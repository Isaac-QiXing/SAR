% main_get_data_boston

clear 
clc

dataFile = ['./data/data_boston_' datestr(now,29) '.mat'];
d = load(dataFile,'X_table');
X_table = d.X_table;

% 0. variables used in the regression
% field  brief description

field_Y_c = {'CMEDV',   'Home value (corrected)'};
field_X_c = {...
'CRIM',        'Crime rate';
'ZN',        'Residential land proportion';
'INDUS',        'Proportion nonretrail business';
'CHAS' ,       'Location contiguous to the Charles River';
'NOX' ,       'Nitrogen xoide concentrations';
'RM'   ,     'Number of rooms ';
'AGE'  ,      'Old units rate';
'DIS'  ,      'Distance to the employment center';
'RAD'  ,     'Highway access index';
'TAX'  ,      'Tax rate' ;
'PTRATIO',     'Pupil-teacher ratio';
'B'    ,    'Black proportion';
'LSTAT',     'Lower status population proportion'};


% 1. transform the feature values

% 1.1 take logarithm
field_log = {'CMEDV','DIS','RAD','LSTAT'};
for i_log = 1:length(field_log)
    field = field_log{i_log};    
    X_table.(field) = log(X_table.(field));
end
% 1.2 processed with square
field_square = {'RM','NOX' };
for ii = 1:length(field_square)
    field = field_square{ii};    
    X_table.(field) =  (X_table.(field)).^2;
end
% 1.3 centalization so that the sample means are zero
X_name_c = field_X_c(:,1);
Y_name_c = field_Y_c(:,1);
y = table2array(X_table(:,Y_name_c));
X = table2array(X_table(:,X_name_c));
    
y = y-mean(y);
for ii=1:size(X,2)
    X(:,ii) = X(:,ii) - mean(X(:,ii));
end

std(y) 
std(X) 

% save the data
save(dataFile,'X','y','field_X_c','field_Y_c','field_log','field_square','-append');



