function main_putout_result
% main_putout_result
% versions
%  * 2019.8.6 
%       ** re-organize the results of the outputs (merge TP, FP and sol1,sol2,sol3)
%       ** fix a bug of the levelA legend of columns
%  * 2019.7.29
%       
%  * 2019.2.20 15:00
%  * 2019.2.1 21:48

flag_detail_print = 0; %1; 
    % 1 or 0
    % 1: print out detailed information to excels
    % 0: print out brief information to excels, which is suitable to show in the paper
    
% 0. load data
dataPath ='.\result\';


%resultFile = '20190201_2\result_var_select_20190201T113132_92552242.mat';
resultFile = 'result20190725-repeat30-129cases\result_var_select_20190725T220816_94162529.mat';
resultFile = [dataPath resultFile];

if flag_detail_print
    flag_str = 'detail';
else
    flag_str = 'brief';
end
xlsResultFile = [dataPath 'result_var_select_print_' flag_str '_' datestr(now,29) '.xlsx'];


rs = load(resultFile,'acc','sol_c','index_c','iteInf_c');
acc = rs.acc;
index_c = rs.index_c; %%%
iteInf_c = rs.iteInf_c;
index1_tb = index_c{1};
index2_tb = index_c{2};
index3_tb = index_c{3};

len(1) = height(index_c{1});
len(2) = height(index_c{2});
len(3) = height(index_c{3});

%  1 get the result items

% 1.0 get parameters

[par_st ]= getSpregData_para();
%save(resultFile,'par_st','-append');

% 1.1 get accuracies
mean_3 = @(x) mean(x,3);
std_3 = @(x) std(x,0,3);
median_3 = @(x) median(x,3);
acc_mean = structfun(mean_3,acc,'UniformOutput',false);
acc_std = structfun(std_3,acc,'UniformOutput',false);
acc_median = structfun(median_3,acc,'UniformOutput',false);

result_s = acc_mean;

result_s.MedSE = acc_median.MSE;  % median of the squared error of beta

% 1.2 get BIC values
getBIC = @(st) st.BIC;
BIC_m = cellfun(getBIC,iteInf_c,'UniformOutput',true);
result_s.BIC = mean_3(BIC_m);
 

% ------------- future version ---------
% % 1.3 get the values of iter_CCCP_subprob and iter_rho 
% getIter = @(st) st.iter_CCCP_subprob;
% getIterRho = @(st) st.iter_rho;
% Iter_CCCP_m = cellfun(getIter,iteInf_c,'UniformOutput',true);
% Iter_rho_m = cellfun(getIterRho,iteInf_c,'UniformOutput',true);
% result_s.iter_CCCP_subprob = mean_3(Iter_CCCP_m);
% result_s.iter_rho = mean_3(Iter_rho_m);
% ---------------------------------------------


% 1.4 devide the struct of the result 
ind1 = 1:len(1);
ind2 = len(1)+1: len(1)+len(2);
ind3 = (len(1)+len(2)+1): (len(1)+len(2)+len(3));

getSubRows01 = @(x) x(ind1,:);
getSubRows02 = @(x) x(ind2,:);
getSubRows03 = @(x) x(ind3,:);

result1_s = structfun(getSubRows01,result_s,'UniformOutput',false);
result2_s = structfun(getSubRows02,result_s,'UniformOutput',false);
result3_s = structfun(getSubRows03,result_s,'UniformOutput',false);

 
if ~varIsInMat('result_s',resultFile)
    save(resultFile,'result_s','result1_s','result2_s','result3_s','-append');
end


% 2. put out the results

% fields of result_s:
%    TP, FP, TN, FN, MedSE, resNorm, time, rho_ite, rho_mse, dev, sol_1, sol_2, sol_3,BIC
%  methods:
%       1: exp-square + l1
%       2: exp-square + adaptive-l1
%       3: exp-square + null
%       4: square + l1
%       5: square + adaptive-l1
%       6: square + null
%       7: LAD + l1
%       8: LAD + adaptive-l1
%       9: LAD + null

title_s.method = {'exp-square+l1','exp-square + adaptive-l1', 'exp-square + null', ...
                'square+l1',       'square + adaptive-l1',  'square + null', ...
                'LAD + l1',      'LAD + adaptive-l1',     'LAD + null'            };
            
title_s.size =  {'n=30,q=5', 'n=30,q=20','n=120,q=5','n=120,q=80','n=360,q=5', 'n=360,q=200'};

title_s.sigma_rho = {'rho=0.8,sigma=1', 'rho=0.5,sigma=1','rho=0.2,sigma=1','rho=0,sigma=1',...
                     'rho=0.8,sigma=2', 'rho=0.5,sigma=2','rho=0.2,sigma=2','rho=0,sigma=2'};
 
% fields of index_tb
% n_sample, dim_act, dim_inact, mu_beta_act, sigma_beta_act, mu_noise, sigma_noise, rho, m, mu_outlier, sigma_outlier, weight_outlier, mode, ratioColumn, ratioRow

% Table 1-1: null penalty, clean data, q= 5 
% Table 1-2: null penalty, clean data, q> 5 

% Table 2-1: null penalty, outliers in y 
% Table 2-2: null penalty, outliers in W 

% Table 3-1: with penalty, clean data, q= 5 
% Table 3-2: with penalty, clean data, q> 5 

% Table 4-1: null penalty, outliers in y 
% Table 4-2: null penalty, outliers in W 


row_levelB_no_penalty        = {'sol_1',   'sol_2',   'sol_3',      'rho_ite','dev', 'MedSE'};
row_levelB_legend_no_penalty = {'$\beta_1$','$\beta_2$','$\beta_3$','$\hat{\rho}$', '$\hat{\sigma}^2$', 'MedSE'};

if flag_detail_print
    row_levelB_penalty       ={'TN',      'FN',       'sol_1',   'sol_2','sol_3',      'rho_ite','dev', 'MedSE'};
    row_levelB_legend_penalty={'Correct', 'Incorrect','$\beta_1$','$\beta_2$','$\beta_3$','$\hat{\rho}$', '$\hat{\sigma}^2$', 'MedSE'};
    method_ind_penalty = [ 1:2,4:5,7:8];     
    n_sample_q_5= [1,3,5]; 
    n_sample_q_gt_5= [2,4,6];
else
    row_levelB_penalty       ={'TN',      'FN',             'rho_ite',  'MedSE'};
    row_levelB_legend_penalty={'Correct', 'Incorrect','$\hat{\rho}$',   'MedSE'};
    method_ind_penalty = [ 1:2, 4:5,7:8];
    n_sample_q_5= [1,5]; 
    n_sample_q_gt_5= [2,6];
end
%%%%%%%%%%%%%%% here deal with n_sample %%%%%%%%%%

% output results
% Table 1
%   var selection results with no penalty function (q=5)
%         Exp-square / Square / LAD

row_levelB       =row_levelB_no_penalty;
row_levelB_legend=row_levelB_legend_no_penalty;
n_sample = [1, 3,5]; % q=5, corresponds to the elements of  title_s.size
method_ind = [ 3,6,9];
sigma_rho =[1	1
1	2
1	3
1	4
2	1
2	2
2	3
2	4];
weight_outlier = [];
mode = [];
% print the result to xls files
sheetName = 'table1-1';
[Result_m ]= get_result(index1_tb,result1_s, title_s, n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);

sheetName = 'table1-2';
n_sample = [2, 4,6]; % for q>5
[Result_m ]= get_result(index1_tb,result1_s, title_s,n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);


% Table 3-1
%   var selection results with  penalty function (q=5)
%       Exp-square + l1 / Exp-square + Apative-l1 / Square + l1/square + Apative-l1 / LAD + l1 / LAD + Adaptive-l1

row_levelB        = row_levelB_penalty;
row_levelB_legend = row_levelB_legend_penalty;

%n_sample = [1, 3,5]; % for q =5
n_sample = n_sample_q_5; % for q =5
method_ind = method_ind_penalty;
%%%title_s.size =  {'n=30,q=5', 'n=120,q=5','n=360,q=5'};
% title_s.size should has length >= max(n_sample)
sheetName = 'table3-1';
[Result_m ]= get_result(index1_tb,result1_s, title_s,n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);
% Table 3-2
%   var selection results with  penalty function (q>5)
%     (when the dimention is relatively close to the sample size)
% n_sample = [2, 4,6]; % for q>5
n_sample = n_sample_q_gt_5; % for q>5
method_ind = method_ind_penalty;
sheetName = 'table3-2';
[Result_m ]= get_result(index1_tb,result1_s,title_s, n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

% Table 2-1,  outliers in response, null regularier 
% Table 4-1,  outliers in response + regularier 
row_levelB       =row_levelB_no_penalty;
row_levelB_legend=row_levelB_legend_no_penalty;
title2_s = title_s;
title2_s.size =  {'n=30,q=5', 'n=120,q=5','n=360,q=5'};
title2_s.weight_outlier ={'delta=0.01','delta=0.05','delta=0.2','delta=0.4','delta=0.8'};

n_sample = [1, 2,3]; %  correspond to title2_s.size
method_ind = [3,6,9];   % no penalty term
if flag_detail_print
    title2_s.sigma_rho = {'rho=0.8,sigma=1', 'rho=0.5,sigma=1' ,...
                       'rho=0.2,sigma=1','rho=0.5,sigma=2'};
    sigma_rho = [1,1;2,2;3,3;4,4]; % 4 cases
    weight_outlier = 1:5;        
else
    title2_s.sigma_rho = {  'rho=0.5,sigma=1' ,...
                            'rho=0.5,sigma=2'};
    sigma_rho = [2,2;4,4]; % 2 cases
    weight_outlier = 1:4;         
end

mode = [];
% print the result to xls files
sheetName = 'table2-1';
[Result_m ]= get_result(index2_tb,result2_s,title2_s, n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);

% table 4-1, noisy y, with penalty term
row_levelB        = row_levelB_penalty;
row_levelB_legend = row_levelB_legend_penalty;
method_ind = method_ind_penalty;   
if flag_detail_print
    n_sample = [1, 2, 3];
else
    n_sample = [1,  3];
end
sheetName = 'table4-1'; 
[Result_m ]= get_result(index2_tb,result2_s,title2_s, n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Table 2-2,  outliers in W,        null regularier     
% Table 4-2,  outliers in W        + regularier     

row_levelB        = row_levelB_no_penalty;
row_levelB_legend = row_levelB_legend_no_penalty;

title3_s = title_s;
title3_s.size =  {'n=30,q=5', 'n=120,q=5','n=360,q=5'};
title3_s.sigma_rho = {  'rho=0.5,sigma=1'};                   
title3_s.weight_outlier ={};
title3_s.mode ={'mode=sparse, ratioCol=0.3, ratioRow=1.0', 'mode=sparse, ratioCol=0.5, ratioRow=1.0',...
    'mode=sparse, ratioCol=0.8, ratioRow=1.0', 'mode=dense, ratioCol=0.5, ratioRow=1.0', ...
    'mode=dense, ratioCol=1.0, ratioRow=1.0',  'mode=dense, ratioCol=1.0, ratioRow=0.1', ...
    'mode=dense, ratioCol=2.0, ratioRow=0.1'};

n_sample = [1, 2,3]; % d = 5

sigma_rho = []; % 1 case
weight_outlier = [];
mode = 1:7;
% print the result to xls files

method_ind = [3,6,9]; % no penalty
sheetName = 'table2-2';
[Result_m ]= get_result(index3_tb,result3_s, title3_s,n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);


method_ind = method_ind_penalty; % with penalty
row_levelB        = row_levelB_penalty;
row_levelB_legend = row_levelB_legend_penalty;
if flag_detail_print
    n_sample = [1, 2, 3];
else
    n_sample = [1,  3];
end
sheetName = 'table4-2';
[Result_m ]= get_result(index3_tb,result3_s, title3_s,n_sample, method_ind ,...
    sigma_rho, weight_outlier, mode);

 
    function [Result_m, row_s,column_s]= get_result(index_tb,result_s, title_s, n_sample, method_ind ,...
            sigma_rho, weight_outlier, mode)
        % print the values of result_s to Excel files
        %   n_sample: a vector of nonnegative indices of the index of training sample size
        %   method_ind:  a vector of nonnegative indices of the solver
        %   sigma_rho: a matrix of two columns
        %         the 1st column: indices of the values of sigma_noise
        %         the 2nd column: indices of the values of rho
        %       e.g.
        %           sigma_rho = [1,1;  1,2; 2,2];
        %       indicating  the case of (sigma,rho) pair taking the (1st,1st) tested value
        %           (1st, 2nd) tested value,  and     (2nd, 2nd) tested value
        %  weight_outlier:  a vector of nonnegative indices of the weight_outlier values
        %  mode:  a vector of nonnegative indices of the  values of mode
        %  index_tb: a table   at least containing the following fields
        %    n_sample,   sigma_noise, rho,  weight_outlier, mode
        %  result_s: a struct array with the length = the number of rows of index_tb
        %  title_s: a struct of the title information
        
        n_col_levelA = length(n_sample); % number of column items of the first level
        n_col_levelB = length(method_ind);% number of column items of the 2nd level
        n_item_col = n_col_levelA* n_col_levelB; % number of columns
        
        n_row_levelB = length(row_levelB); % number of row items for each case
        n_row_levelA = [];
        
        Result_m = [];
        i_col_A = 0;
        n_row = height(index_tb); %length(result_s);
         
        % construct row lengends
            row_title_c = cell(n_row,1);
            if ~isempty(sigma_rho)
                index_sigma_rho = [index_tb.sigma_noise  index_tb.rho ];                
                [ind0,loc] =  ismember(index_sigma_rho,sigma_rho,'rows');
                row_title_c(ind0) =  title_s.sigma_rho(loc(ind0));
                row_title_c = columnVec(row_title_c);
            end
            if ~isempty(weight_outlier)
                [ind0,loc]= ismember(index_tb.weight_outlier,weight_outlier); 
                mode_c = [row_title_c(ind0) columnVec(title_s.weight_outlier(loc(ind0)))];
                 mode2_c = cell(nnz(ind0),1);
                 for ii=1:size(mode2_c,1)
                     mode2_c(ii) =  mode_c(ii,1);
                     if isempty(mode_c{ii,1})
                         mode2_c(ii) = mode_c(ii,2);
                     else
                         mode2_c{ii} = strjoin(mode_c(ii,:),',');
                     end
                 end
                 row_title_c(ind0) = mode2_c;                
            end
            if ~isempty(mode)
                [ind0,loc]  =ismember(index_tb.mode, mode);
                %%%
                %save('temp20190730.mat','ind0','loc','row_title_c','title_s');
                %%%
                 mode_c = [row_title_c(ind0) columnVec(title_s.mode(loc(ind0)))];
                 mode2_c = cell(nnz(ind0),1);
                 for ii=1:size(mode2_c,1)
                     mode2_c(ii) =  mode_c(ii,1);
                     if isempty(mode_c{ii,1})
                         mode2_c(ii) = mode_c(ii,2);
                     else
                         mode2_c{ii} = strjoin(mode_c(ii,:),',');
                     end
                 end
                 row_title_c(ind0) = mode2_c; 
            end          
                        
         % assign column title 
        len_n_sample = length(n_sample);
        len_n_method = length(method_ind);
        column_title_c = cell(2,len_n_sample *len_n_method);
        column_title_c(1,1:len_n_method:end) = title_s.size(n_sample);
        ind_method_rep = kron(ones(1,len_n_sample), method_ind);
        column_title_c(2,:) = title_s.method(ind_method_rep);
        i_row_excel_start = 1;
          % print the column title
        cell_str = ['B' num2str(i_row_excel_start)];
        fwritexls(xlsResultFile,[],column_title_c,cell_str,sheetName);
        
        
        for iii_case = n_sample % column_level_A
            % update the index of column
            i_col_A = i_col_A + 1; % column indices of the first level
            % get row indices
            ind = (index_tb.n_sample ==iii_case);
            if ~isempty(weight_outlier)
                ind = ind& ismember(index_tb.weight_outlier,weight_outlier);
            end
            if ~isempty(mode)
                ind = ind& ismember(index_tb.mode, mode);
            end
            if ~isempty(sigma_rho)
                index_sigma_rho = [index_tb.sigma_noise  index_tb.rho ];
                
                ind = ind& ismember(index_sigma_rho,sigma_rho,'rows');
            end
            
            % initialize Result_m
            if isempty(Result_m)
                Result_m = zeros(n_row_levelB*nnz(ind),n_item_col);
                n_row_levelA = nnz(ind);
                ind_row_levelA = find(ind);
                fwritef(1,'size of Result_m:',size(Result_m),'');
            end
            
            % get the results
            result_c = cell(1,n_row_levelB);
            for i_item_row = 1:n_row_levelB
                row_item = row_levelB{i_item_row};
                result_c{i_item_row} = result_s.(row_item)(ind,method_ind);
            end
            
            % assign the result to Result_m
            ind_col = (i_col_A-1)*n_col_levelB +1: i_col_A *n_col_levelB;
            % column indices corresponding to i_col_A
            
            for i_item_row = 1:n_row_levelB
                Result_m(i_item_row:n_row_levelB:end,ind_col) =  result_c{i_item_row};
            end
        end
        
        % assign row parameters and column parameters
        n_sample = rowVec(n_sample);
        method_ind = rowVec(method_ind);
        
        row_s.levelA = index_tb(ind,:);
        % note that ind corresponds to the one of the last loop in the above
        row_s.levelB = row_levelB;
        column_s.levelA.n = n_sample;
        column_s.levelB.method = method_ind;
        
        % print the result
        i_row_excel_start = 3;           
        for ii=1:n_row_levelA
            
            i_row = (ii-1)*n_row_levelB+1 : ii *n_row_levelB;
            
% % %             cell_row_str = ['A' num2str(i_row_excel_start+ n_row_levelB)];
% % %             cell_row_str2 = ['A' num2str(i_row_excel_start+ n_row_levelB+1)];
% % %                     % start cells to print row legends 
% % %             i_row_excel_start = i_row_excel_start + n_row_levelB + 1;
% % %             cell_str = ['B' num2str(i_row_excel_start)];
            cell_row_str = ['A' num2str(i_row_excel_start)];
            cell_row_str2 = ['A' num2str(i_row_excel_start+1)];
                    % start cells to print row legends             
            cell_str = ['B' num2str(i_row_excel_start+1)];
            i_row_excel_start = i_row_excel_start + n_row_levelB + 1;

            % print the row legneds
               % the row legend of levelA
            irow_levelA =  ind_row_levelA(ii); % irow_levelA: row index of the result
            fwritexls(xlsResultFile,[], row_title_c(irow_levelA),cell_row_str,sheetName);
                % the row legend of levelB                     
            %fwritexls(xlsResultFile,[], columnVec(row_levelB), cell_row_str2,sheetName);
            fwritexls(xlsResultFile,[], columnVec(row_levelB_legend), cell_row_str2,sheetName);
                
            % print the result
            fwritexls(xlsResultFile,[],Result_m(i_row,:),cell_str,sheetName);
        end
        
% % %         % print row_s.levelA
% % %         i_row_excel_start = i_row_excel_start + n_row_levelB + 2;
% % %         cell_str = ['B' num2str(i_row_excel_start)];
% % %         fwritexls(xlsResultFile,[],table2array(index_tb(ind,:)),cell_str,sheetName);
    end % end function of get_result

end

