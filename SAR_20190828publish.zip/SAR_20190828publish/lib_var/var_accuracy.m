function [acc] = var_accuracy(beta_predict,beta_true,thresh_nnz_beta)
%  calculate accuracy of variable selection 
%   Inputs:
%       beta_predict: predicted regression coefficient beta
%       beta_true: true regression coefficient beta
%       thresh_nnz_beta: a positive sclar indicating the theshold of a nonzero beta coordinate 
%   Outputs:
%      acc: struct of accuracy 
%       .TP: number of true nonzero coornidates of beta_predict
%       .FP: number of false nonzero coornidates of beta_predict
%       .TN: number of true zero coornidates of beta_predict
%       .FN: number of false zero coornidates of beta_predict
%       .MSE: norm(beta_predict-beta_true,2)
%  Version
%   1st version. 2019.1.30 pm 16:44

% MSE
acc.MSE = norm(beta_predict-beta_true,2);

% TP, FP, TN, FN
beta_p_abs = abs(beta_predict);
beta_abs = abs(beta_true);
acc.TP = nnz( beta_p_abs>=thresh_nnz_beta & beta_abs>0);
acc.FP = nnz( beta_p_abs>=thresh_nnz_beta & beta_abs==0);
acc.TN = nnz( beta_p_abs<thresh_nnz_beta & beta_abs==0);
acc.FN = nnz( beta_p_abs<thresh_nnz_beta & beta_abs>0);





