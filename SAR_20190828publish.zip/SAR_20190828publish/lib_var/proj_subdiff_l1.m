function v2 = proj_subdiff_l1(v,x,C,varargin)
% project a vector v to   the subdifferential of l1 norm
%   i.e., 
%       v2 = Proj( v,  C* nabla |x|_w),  with |x|_w : = sum_i w(i)*|x(i)|
%  Inputs:
%       v: a d-by-1 vector 
%      x: a d-by-1 vector 
%       C: a  positive scalar 
%       varargin{1}:
%           w: optional, a d-by-1 vector of nonnegative numbers; default value: ones(d,1);
%   Outputs: 
%    v2: a d-by-1 vector 

if nargin<=3
    w = ones(size(x));
else
    w = varargin{1};
end
x = columnVec(x);
v = columnVec(v);
w = columnVec(w);

%ind = x == 0;
ind = (abs(x) <= 0.005);

v2 = C*sign(x);
 
if ~isempty(ind) 
     v2(ind) = proj(v(ind), -C*w(ind),C*w(ind) );    
end
end