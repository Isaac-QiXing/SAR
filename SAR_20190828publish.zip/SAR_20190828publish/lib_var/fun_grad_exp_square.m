function [y,gd] = fun_grad_exp_square(x,gamma)
    v = exp(-x.*x/gamma);
    y = 1- v;
    gd = 2/gamma * x .* v;
end

% function [y,gd]= fun_grad_exp_square(x)
% 
% gamma = 2.0 ; 
% [y,gd]= exp_square(x,gamma);
% end

% function [y,gd] = exp_square(x,gamma)
%     v = exp(-x.*x/gamma);
%     y = 1- v;
%     gd = 2/gamma * x .* v;
% end