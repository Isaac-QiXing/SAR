% main_var_select
% versions
%   * 2019.2.1 9:50 
%     ** add  parfor mode 
%   * First version. 2019.1.30. 16:46-16:50, 20:49-21:10

clc
clear

flag_have_a_try = 1;  % 1 or 0, whether just have a try to see whether the code run well

% file_cv = 'result_cv_20190130T104810_396767.mat';

time_str = timeStamp();
dataPath ='E:\data_var_selection\dataVarSel_20190316_1\';
resultFile = [dataPath 'result_var_select_' time_str '.mat'];
cvFile = [dataPath 'result_cv_' datestr(now,29) '.mat'];
% cvFile = [dataPath 'result_cv_' '2019-01-31' '.mat'];

% cvFile = 'result_cv_20190130T110501_396767.mat';

%cv= load('result_cv_20190130T110501_396767.mat','par_opt_c');
% cv= load(file_cv,'par_opt_c');


if flag_have_a_try
    max_ite_CCCP_batch = 800;
    verbose = 3;
    n_test_case0 = 1; %2 
    n_parModel0 = 1;
    n_repeat = 1; %2
    flag_generate_data = 1;
% % %     flag_cv = 0;  % whether to operate cross-validation
else
    max_ite_CCCP_batch = 200;
    verbose =  0; % 1;
    n_repeat = 100;
    flag_generate_data = 1;
% % %     flag_cv = 1;
end


thresh_nnz_beta = 0.2;

% 1.1 generate model parameter
%loss_c = {'exp-square','square'};
loss_c = {'exp-square','square','lad'};
regularizer_c = {'l1', 'adaptive-l1','null'};% 'SCAD', 

n_parModel =  length(loss_c)*length(regularizer_c);
if flag_have_a_try
 n_parModel = n_parModel0;
end

parModel_c = cell(1,n_parModel);
i_model = 1;
for i_loss = 1:length(loss_c)
    for i_reg = 1:length(regularizer_c)
        parModel.loss = loss_c{i_loss};
        parModel.regularizer = regularizer_c{i_reg};
        parModel.a=  3.7; % 2.0
        parModel_c{i_model} = parModel;
        i_model = i_model + 1;
    end
    
end
%%parModel_c(5) = []; % remove 'square' + 'l1'


% 1.2 algorithm parameter
%%%arg.C = 1.0; % n_case;
par_alg.TolFun = 1.0E-5;
par_alg.TolX = 1.0E-4;
par_alg.verbose  = verbose;

par_alg.maxIter =  max_ite_CCCP_batch;
% % % par_alg.maxIter_spa = 10;
%%%par_alg.adaptive_regularizer = 1;

% 2. generate data files
if flag_generate_data
    n_test_case = [];
    for i_repeat = 1:n_repeat
        [file0_c, index_tb ]= generateSPRdata(dataPath);
        if i_repeat ==1
            file_c = cell(length(file0_c),i_repeat);  % initialize file_c
            n_test_case = length(file0_c);
        end
        file_c(:,i_repeat) = file0_c;
    end
    save('fileName.mat','file_c','index_tb');
else
    s = load('fileName.mat','file_c','index_tb');
    file_c = s.file_c;
    index_tb = s.index_tb;
end
if flag_have_a_try
    n_test_case = n_test_case0;
end

% 3 variable selection


% 3.0 initialize the accuracy measures
zeros3 = zeros(n_test_case,n_parModel,n_repeat);
sol_c = cell(n_test_case,n_parModel,n_repeat);
par_opt_c = cell(n_test_case,n_parModel,n_repeat);
iteInf_c = cell(n_test_case,n_parModel,n_repeat);

acc.TP = zeros3;
acc.FP = zeros3;
acc.TN= zeros3;
acc.FN= zeros3;
acc.resNorm = zeros3;
acc.MSE = zeros3;
acc.sol_1= zeros3;
acc.sol_2= zeros3;
acc.sol_3= zeros3;
acc.time  = zeros3; % elapsed time


% % % if ~flag_cv
% % %     cv = load(cvFile,'par_opt_c');
% % % end

%poolobj = parpool;


for i_case = 1:n_test_case
    %%%par_opt = cv.par_opt_c{i_case}; % load parameter
    for i_model = 1:n_parModel
       fprintf(1,'(i_case,i_model): (%d,   %d)/(%d,  %d)\n',...
            i_case,i_model,n_test_case,n_parModel);
% % % %         % 3.1 cross validation
% % % %                 
% % % %         parModel = parModel_c{i_model};
% % % %         fileName = file_c{i_case,1};
% % % %         if flag_cv             
% % % %             par_alg2 = completeArg(par_alg,fieldnames(parModel),parModel);
% % % %             par_opt = var_cv(fileName,parModel.loss,parModel.regularizer,par_alg2);
% % % %             par_opt_c{i_case,i_model} = par_opt;
% % % %             save(cvFile,'par_opt_c');
% % % %         else
% % % %             par_opt = cv.par_opt_c{i_case,i_model};
% % % %         end
        
        % 3.1 determine the model parameter (cancel)
        
        % 3.2 variable  selection
        % 3.2.1 initialization and assign parameters
        
% % %          par_opt2 = completeArg(par_opt,fieldnames(parModel),parModel);
% % %         par_opt2.adaptive_regularizer = par_alg.adaptive_regularizer;
        
        acc_t = struct('MSE',cell(1,n_repeat),'TP',[],'FP',[],'TN',[],'FN',[]);
        sol0_c = cell(1,n_repeat);
        iteInf0_c = cell(1,n_repeat);
        resNorm_v = zeros(1,n_repeat);
        time_v = zeros(1,n_repeat);
        %parfor i_repeat = 1:n_repeat
        parModel = parModel_c{i_model};
        for i_repeat = 1:n_repeat
            %fprintf(1,'(i_case,i_model,i_repeat): (%d, %d, %d)/(%d, %d, %d)\n',...
            %    i_case,i_model,i_repeat,n_test_case,n_parModel,n_repeat);
            fprintf(1,'=');
            fileName = file_c{i_case,i_repeat};
            %d = load(fileName,'arg', 'X', 'y','beta', 'rho', 'epsilon', 'W','y_fix' );
            d = load(fileName,'arg', 'X', 'beta','y_fix' );
            
            % 3.2.2 variable selection
            tic
            [sol,resNorm,~,iteInf] = var_select(d.X, d.y_fix, parModel,par_alg);
            t = toc;
            % 3.2.3 calculate accuracy
            [acc0] = var_accuracy(sol,d.beta,thresh_nnz_beta);
            acc_t(i_repeat) = acc0;
            resNorm_v(i_repeat) = resNorm;
            sol0_c{i_repeat} = sol;
            iteInf0_c{i_repeat} = iteInf;
            time_v(i_repeat) = t;
        end % end parfor
        
         % 3.2.4 assign results
         %  (1) assign acc
            acc.TP(i_case,i_model,:) = [acc_t(:).TP];
            acc.FP(i_case,i_model,:) = [acc_t(:).FP];
            acc.TN(i_case,i_model,:) = [acc_t(:).TN];
            acc.FN(i_case,i_model,:) = [acc_t(:).FN];
            acc.MSE(i_case,i_model,:) = [acc_t(:).MSE];             
            acc.resNorm(i_case,i_model,:) = resNorm_v;
            acc.time(i_case,i_model,:) = time_v;
        %   (2) assign sol_c            
            sol_c(i_case,i_model,:) = sol0_c;  
            for iii_repeat=1:n_repeat
                sol_i = sol0_c{iii_repeat};
                acc.sol_1(i_case,i_model,iii_repeat) = sol_i(1);
                acc.sol_2(i_case,i_model,iii_repeat) = sol_i(2);
                acc.sol_3(i_case,i_model,iii_repeat) = sol_i(3);
            end 
        % (3) assign iteInf
        iteInf_c(i_case,i_model,:) = iteInf0_c;
        
        fprintf(1,'\n');
        save(resultFile,'acc','sol_c','iteInf_c');
    end
end
save(resultFile,'index_tb','-append');
%delete(poolobj);
