function x2 = hard_thresh(x,thresh)
    x2 =x;
    x2(abs(x2)<thresh) =0;
end