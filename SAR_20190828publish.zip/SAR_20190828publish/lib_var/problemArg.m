function varargout = problemArg(varargin)
% get the value of the specified argument
% Inputs:
%   varargin{i}: string indicating the argument name;
% Outputs:
%  varrgout{i}: the value of the argument indicated by varargin{i};
%
% e.g,[xcorr_name, deltacn_name,  basic_w]= problemArg('feature_name_xcorr',...
%    'feature_name_deltacn', 'basic_feature_weight');


% get arguments  set by users 

config();
    
 

% user set arguments 
userSetting();


% put out
for ii=1:nargin
    if exist(varargin{ii},'var')
        varargout{ii} = eval(varargin{ii});
    else
        varargout{ii} = [];
    end
end

end

