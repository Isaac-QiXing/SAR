function vec2= proj(vec,a,b)
% projection a vector to the interval [a,b]
% vec: a row or column vector of n real numbers
% a:  a scalar or a vector of n numbers, indicating the lower bound of the interval for vec(i)
% b:  a scalar or a vector of n numbers, indicating the upper bound of the interval for vec(i)
% Outputs:
%  vec2: the projected vector

vec2 = vec; 

% % % a = min(int);
% % % b = max(int);

vec2(vec2<a) = a(vec2<a);
vec2(vec2>b) = b(vec2>b);
end