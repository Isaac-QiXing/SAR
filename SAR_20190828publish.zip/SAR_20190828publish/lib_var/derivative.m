function H = derivative(F,x,arg)
% calculate the finite-difference derivatives of a given (vector-valued)
% function

% Inputs:
%  F: handle of the given function, F: R^n --> R^m
%  x: a n-by-1 vector, calculate the derivative at x;
%  arg: Optional, arguments
%    .pre: a positive scalar indicating the separation of x;
% Outputs:
%  H: a n-by-m matrix, the derivative of F at x;
%       H(i,j) = dF_j/dx_i,   i = 1,...,n; j=1,...,m

if nargin>2 && isfield(arg,'pre')
    pre = arg.pre; 
else
    pre = 1.0E-3;
end

n = length(x); % dimension of x;
g = F(x);
m = length(g); 

H = zeros(m,n); % note that H is transposed at last: the size of the 
                % derivative  is in fact n-by-m;
for ii=1:n
    x_plus_delta_x = x;
    x_plus_delta_x(ii) = x_plus_delta_x(ii) + pre;
    H(:,ii) = F(x_plus_delta_x)-g;
end
H = H'/pre;


end