function [y,gd] = fun_grad_square(x)
% function of square 
%   f(t) = 0.5*t^2
    
    y = 0.5*(x.*x);
    gd = x;
end
