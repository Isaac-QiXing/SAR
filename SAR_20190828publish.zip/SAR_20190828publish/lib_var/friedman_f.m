function [stat] = friedman_f(x,tol, varargin)
% Using F_F statistic (Iman and Davenport 1980) and F-distribution for Friedman test
%   for two-algorithm comparisions
% Inputs: 
%   x:  matrix with 2 columns, indicating the accurac
% The Friedman test is a non-parametric statistical test developed by the U.S.
% economist Milton Friedman. Similar to the parametric repeated measures ANOVA,
% it is used to detect differences in treatments across multiple test attempts.
% The procedure involves ranking each row (or block) together, then considering
% the values of ranks by columns. Applicable to complete block designs, it is
% thus a special case of the Durbin test. The Friedman test is used for two-way
% repeated measures analysis of variance by ranks. In its use of ranks it is
% similar to the Kruskal-Wallis one-way analysis of variance by ranks. 
% When the number of blocks or treatments is large the probability
% distribution can be approximated by chi-square or F distribution. If n or
% k is small, the  approximation to chi-square becomes  poor and the
% p-value should be obtained from tables of Q specially prepared 
% for the Friedman test. The MatLab function FRIEDMAN only uses the chi-square
% approximation. On the contrary, MYFRIEDMAN uses the exact distribution for
% small size samples and chi-square and F distribution for large sample
% size. If the p-value is significant, a post-hoc multiple comparisons
% tests is performed. 
%
% Syntax: 	myfriedman(X,ALPHA,REPS)
%      
%     Inputs:
%           X - data matrix
%           ALPHA - Significance levele (default=0.05)
%           REPS - If there is more than one observation per row-column pair,
%           then the argument REPS indicates the number of observations per
%           "cell". A cell contains REPS number of rows (default=1).
%     Outputs:
%           - Used Statistic
%           - Multiple comparisons (eventually)
%
%      Example: 
%
% x=[115 142 36 91 28; 28 31 7 21 6; 220 311 108 51 117; 82 56 24 46 33; 256 298 124 46 84; 294 322 176 54 86; 98 87 55 84 25];
%
%           Calling on Matlab the function: myfriedman(x)
%
%           Answer is:
%
% FRIEDMAN TEST FOR IDENTICAL TREATMENT EFFECTS:
% TWO-WAY BALANCED, COMPLETE BLOCK DESIGNS
% ------------------------------------------------------------------------------------------

% To cite this file, this would be an appropriate format:
% Cardillo G. (2009). MYFRIEDMAN: Friedman test for non parametric two way ANalysis Of VAriance
% http://www.mathworks.com/matlabcentral/fileexchange/25882

%Input Error handling
p = inputParser;
addRequired(p,'x',@(x) validateattributes(x,{'numeric'},{'2d','real','finite','nonnan','nonempty'}));
addOptional(p,'alpha',0.05, @(x) validateattributes(x,{'numeric'},{'scalar','real','finite','nonnan','>',0,'<',1}));
addOptional(p,'reps',1, @(x) validateattributes(x,{'numeric'},{'scalar','real','finite','nonnan','positive','integer'}));
parse(p,x,varargin{:});
assert(size(x,1)>1,'Warning: X must be a matrix, not a vector')
alpha=p.Results.alpha; reps=p.Results.reps;
clear p

[b,k]=size(x);  % b: number of datasets (blocks), k : number of algorithms (treatments)
R=zeros(b,k); 
ties=zeros(b/reps,1); z=1; %array preallocation

% tol
% alpha 

% 1.1 calculate the avereage ranks 

for I=1:reps:b
    % Keep REPS rows and transform them into an array
    S=reshape(x(I:I+reps-1,:),1,k*reps); 
    % Rank the values
%    [Sr,ts]=tiedrank(S);
    Sr = mytiedrank(S,tol);
    % Reshape the S array into REPSxk matrix and assign it to the proper R
    % slice.
    R(I:I+reps-1,:)=reshape(Sr,reps,k);
% % %     if ts % check for ties
% % %         ties(z)=1;
% % %     end
% % %     z=z+1;
end

%T=sum(R); %The observed sum of ranks for each treatment
% A=sum(sum(R.^2)); %sum of squared ranks
% Te=b*(k*reps+1)/2; %The expected value of ranks sum under Ho
% Tx=sum((T-Te).^2); % The Friedman statistic
% clear S Sr ts z Te I

%R = k+1-R;
stat.R = R; 
rank_mean = mean(R);
stat.meanrank  =rank_mean;

% 1.2 calculate the  chi-squre and F_F statistics 
chi_square = 12*b/(k*(k+1)) * (sum(rank_mean.*rank_mean) - 0.25*k*(k+1)^2);
F_F = (b-1)*chi_square /(b*(k-1)-chi_square);

% assign to the output STAT 
stat.chi_square = chi_square;
stat.f = F_F;

% 1.3 determine whether reject the H0 hypothesis. 

stat.quantile_f = finv(1-alpha, k-1,(k-1)*(b-1));
if F_F>stat.quantile_f
    stat.reject = 1; % reject null hypothesis that all the treatment have no evdient difference
else
    stat.reject = 0; 
end

% 2. Nemenyi test for pairwise comparisons 

% calculate the CD (critical difference)

q_nemenyi_0_05 = [1.960 2.343 2.569 2.728 2.850 2.949 3.031 3.102 3.164];
    % coefficients for treatment = 2,3, ...,10 for Nemenyi test under alpha = 0.05
q_nemenyi_0_10 = [1.645 2.052 2.291 2.459 2.589 2.693 2.780 2.855 2.920];
    % coefficients for treatment = 2,3, ...,10 for Nemenyi test under alpha = 0.10

stat.cd_nemenyi = [];
if k>10
    warning('CD values only support 2<=k<=10 ');
    return
end

if alpha==0.05
    coef = q_nemenyi_0_05(k-1);
elseif alpha==0.1
    coef = q_nemenyi_0_10(k-1);
else
    warning('CD values only support alpha=0.05 or 0.1. ');
end
stat.q_nemenyi = coef;
stat.cd_nemenyi = coef * sqrt(k*(k+1)/(6*b));

% 3. Bonferroni-dunn test 
q_dunn_0_05 = [1.960 2.241 2.394 2.498 2.576 2.638 2.690 2.724 2.773];
% coefficients for treatment = 2,3, ...,10 for Bonferroni-dunn test under alpha = 0.05
q_dunn_0_10 = [1.645 1.960 2.128 2.241 2.326 2.394 2.450 2.498 2.539];
% coefficients for treatment = 2,3, ...,10 for Bonferroni-dunn test under alpha = 0.10

% calculate the CD (critical difference)
stat.cd_dunn = [];  
if alpha==0.05
    coef = q_dunn_0_05(k-1);
elseif alpha==0.1
    coef = q_dunn_0_10(k-1);
else
    warning('CD values only support alpha=0.05 or 0.1. ');
end
stat.q_dunn = coef;
stat.cd_dunn = coef * sqrt(k*(k+1)/(6*b));
end