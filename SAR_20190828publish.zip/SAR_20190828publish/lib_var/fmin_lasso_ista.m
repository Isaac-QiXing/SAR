function [sol,fval,exitflag] = fmin_lasso_ista(fun,x0, w, arg)
% minimize a differentiable function with adaptive-l1 norm 
% i.e.         min_x   f(x) + C sum_i w_i*|x_i|
% by ISTA  iterations
% Inputs:
%   fun:  a function handle of the form
%           [fval, gd] = fun(x)
%       with fval and gd the objective fucntion value and the gradient of fun at x
%   x0: the initial point;
%   w: a  vector with  size of d-by-1, with d the length of x,
%       consisting of nonnegative weights;
%   arg: a struct of parameters, with the following fields:
%   arg.C: a positive scalar of the weight of regularization term
%   arg.maxIter: optional, maximum loops number 
% % % %   arg.TolFun: optioanl, tolerance of iterated difference of  function values
%   arg.TolX: optional, tolerance of iterated difference of  solutions
%   arg.verbose: optional, 1 or 0, whether print iteration information
% Outputs:
%  sol: a d-by-1 vector of the solved solution
%  fval: objective function value at sol
%  exitflag
% Versions:
%    * 2019.5.28 first version, to replace the function fmin_lasso() where
%    fmincon() with sqp solver stuck  sometimes; 

arg.x0 = x0; % initial point
arg.eta = w; 
arg.solver = 'fista'; 
arg.box = [];
c = arg.C; 

dim = length(x0);

 [sol,fval,ite_s] = ista(@myfval,@mygrad,c,dim,arg);
 
 exitflag = ite_s.exitflag; 
 
 
    function fval =  myfval(x)
        fval  = fun(x);
    end
    function grad_v  = mygrad(x)
        [~,grad_v] = fun(x); 
    end
 
end