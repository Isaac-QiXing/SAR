 function [result_test ] = var_predict_spa(matTrainFile,matTestFile, par_alg)
%      matTrainFile, matTestFile: mat file name for traing and test,
%       it contain  the same data variables;
%      par_alg: a struct of algorithm  parameters
%      result_test: a struct of the predicted results on test sets 
%          Each field  of result_test is a numeric scalar.
% Version
%   2019.3.8 
%       * call spatial regression algorithm
%   2019.2.1 15:41
%       * for spatial autoregressive model


 
    
   
    fileName =  matTrainFile;
    d = load(fileName,  'X', 'y','y_reg','W','index_v'  );  
        % y_reg = W* y
        % Note that y_reg is required for spatical arutoregression data
    par_alg.W = d.W(:,d.index_v);    % 
    
%     y_fix = d.y- par_alg.rho * d.y_reg;
    %[sol] = var_select(d.X,y_fix, par_alg,par_alg);
    
    [sol,rho_min,~] = var_spa_select(d.X,d.y,d.y_reg,par_alg,par_alg);
    
    % on test file 
    t  = load(matTestFile,  'X',   'y','y_reg' );   
    
    %y_test = t.y - par_alg.rho * t.y_reg; 
    y_test = t.y - rho_min * t.y_reg; 
    error_v = abs(y_test - t.X *  sol);
    
    
    result_test.err_norm = norm(error_v); 
    result_test.err_norm1 = norm(error_v,1); 
    result_test.err_median = median(error_v);
    
    gamma = 8.0; 
    result_test.err_exp_square = sum(exp_square(error_v,gamma));
 end
    

 