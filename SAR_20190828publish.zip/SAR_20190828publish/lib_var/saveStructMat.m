function saveStructMat(fileName,data_st)
    save(fileName,'-struct','data_st');
end