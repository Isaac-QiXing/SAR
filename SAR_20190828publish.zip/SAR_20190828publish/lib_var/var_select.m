function [sol,varargout] = var_select(X,y, par_model,par_alg)
%     variable selection
%   Inputs:
%       X: n-by-dim data matrix
%       y: n-by-1  observation vector
%       parModel: struct of model parmeters
%           .loss:  loss function name: 'exp-square' or 'square' or 'lad'
%                indicating exponential square loss, square loss and absolute loss, resp.
%
%           .regularizer:   regularization term,  'SCAD', 'l1', 'adaptive-l1', or 'null'
%               indicating SCAD, 1-norm, adaptive l1 norm and no regularization term, resp.
%           .gamma: optional, parameter of  exp-square loss, default value determined by  select_gamma();
%           .lambda: parameter of the regularizer;
%       par_alg: struct of algorithm parameters
%           .maxIter optional, indicates the maximum iteration number of CCCP solver or ISTA solver
%            .x0: initial point
%           .TolFun: optioanl, tolerance of iterated difference of  function values
%           .TolX: optional, tolerance of iterated difference of  solutions
%           .verbose: optional, 1 or 0, whether print iteration information
%           .FixInitialPoint: 1 or 0, whether to fix the inital point at each call
%              such that the result are repeatable
%   Outputs:
%      sol: solution
%      varargout{1}: residual norm:  norm(y-X*sol)
%      varargout{2}: iteInf
%           iteInf.gamma: the calculated parameter value of the Exponential-square loss,
%                   for other loss functions it would be set [];
%       iteInf.iter: the solving number of the convex subproblems for  the exponential-square loss;
% version
%   * 2019.8.13
%       fix a bug of the setting of w for LAD Loss +  adptive-l1  regularizer
%   * 2019.8.5
%       ** add iteInf.iter
%   * 2019.5.13
%       remove parameter  parModel.C
%   * 2019.3.16
%    **  set the input parameter parModel.gamma as optional, default value is determined by select_gamma()
%    **  set the input parameter parModel.C as optional, default value is set as log(n)/n
%   * 2019.3.13-16
%       **  add 'lad' loss,
%       **  add 'adaptive-l1' regularizer
%       **  remove the input parameter parModel.adaptive_regularizer
%       **  remove the input parameter parModel.w_regularizer
%       **  remove the input parameter parModel.a
%
%   * 1st version. 2019.1.30 pm 16:38

% % % %           .a: parameter of SCAD regularizer, which is often set 3.7
% % %           .w_regularizer: a vector of nonnegativer weights of regularizer 'SCAD' or 'l1'
% % %               it has the length = size(X,2), default value = [];
% % %               It takes no effect if par.regularizer = 'null'.
% % %               for SCAD and l1 loss the weight lambda for coordinate beta_i would be
% % %                       par_model.lambda * par_model.w_regularizer
% % %           .adaptive_regularizer: 0 or 1, whether use apative regularizer
% % %               if 1, the algorithm adjust the weight of each coordinates by the pre-solved  solution
% % %               if 0, all the coornidates would be equally compressed or compressed by
% % %                   user-supplied weights
% % %               default value 1.
% % %               it takes no effect if par.regularizer = 'null'
% % % %           .C: optional, weight of regulartion term, takes no effect if par.regularizer = 'null'
% % % %               default value: log(n)/n

debug_on = 0; % 0,

% 0. identify the loss function and the regulaizer
par_model.loss = lower(strtrim(par_model.loss));
switch par_model.loss
    case 'exp-square'
        loss_id = 1;
    case 'square'
        loss_id = 2;
    case 'lad'
        loss_id = 3;
    otherwise
        loss_id = -1;
end

par_model.regularizer = lower(strtrim(par_model.regularizer));
switch par_model.regularizer
    case {'null'}
        reg_id = 0;
    case {'scad','adaptive-scad'}
        reg_id = 1;
    case {'l1', 'adaptive-l1'}
        reg_id = 2;
    otherwise
        reg_id = -1;
end
flag_adaptive_regularizer = strncmpi(par_model.regularizer, 'adaptive',8);
% 1 or 0, whether specified 'adaptive' regularizer

if par_alg.verbose>=2
    fwritef(1,'loss_id',loss_id,'','reg_id',reg_id,'','flag_adaptive_regularizer',int8(flag_adaptive_regularizer),'');
end

if  loss_id ==-1
    error('Do not  support the specified loss function: %s.\n',par_model.loss);
end
if reg_id == -1
    error('Do not support the specified regularizer: %s.\n',par_model.regularizer);
end

% 1. set model and algorithm parameters
[n,dim] = size(X);

% 1.1 set model paramter
% C_default =  log(n)/n; % default weight of regularizer
lambda_default =  0.1*log(n)/n; % default weight of regularizer
% % % par_model = completeArg(par_model,{'w_regularizer','adaptive_regularizer','a'},{ones(dim,1),0,3.7});
% % % par_alg =    completeArg(par_alg,{'C'},{C_default});


par_model = completeArg(par_model,{'w_regularizer','lambda','gamma','a'},{ones(dim,1),lambda_default,[],3.7});
par_alg =    completeArg(par_alg,{'verbose','x0','TolFun','TolX','maxIter','FixInitialPoint'},...
    {1,        [],  1E-4,    1E-3,  [],     1});

% set parameter gamma
if loss_id==1 && isempty(par_model.gamma)  % exp-square loss
    par_model.gamma = select_gamma( X,y);
end

if par_alg.verbose>=2
    fwritef(1,'selected gamma',par_model.gamma,'');
end
% 1.2 set n_loop
if flag_adaptive_regularizer
    n_loop = 2;
else
    n_loop = 1;
end

% 1.3 set algorithm parameter for ISTA algorithm
if  reg_id == 2 && (loss_id ==2 || loss_id==3)
    % Square Loss (or lad loss) + l1 (or adaptive-l1) regularizer
    arg_ista.x0 = par_alg.x0;
    arg_ista.solver = 'fista';
    arg_ista.eta = [];
    arg_ista.maxIter = par_alg.maxIter;
    arg_ista.TolX =  par_alg.TolX;
    arg_ista = completeArg(arg_ista,{'maxIter' },{400 });
end

iteInf = struct();
exitflag = [];
iter = 0;
for i_loop=1:n_loop
    w = [];
    if i_loop ==2 % i_loop ==2 ==> flag_adaptive_regularizer == true
        w = par_model.w_regularizer;
    end
    if  loss_id == 2 && reg_id == 0 % Square Loss + Null regularizer
        solver_str = 'lsqlin';
        [sol,~,~,exitflag] =  lsqlin(X,y,[],[]);
    elseif loss_id==2 && reg_id == 2  % Square Loss + l1 (or adptive-l1) regularizer
        solver_str = 'l1ls_box_ista';
        %%%w = [];
        [sol,~,iteInf] = l1ls_box_ista(X,y,w,par_model.lambda,arg_ista);
    elseif loss_id == 3 && reg_id == 2 % LAD Loss + l1 (or adptive-l1) regularizer
        solver_str = 'l1l1_box_ista';        
        [sol,~,iteInf] = l1l1_box_ista(X,y,w,par_model.lambda,arg_ista);
    elseif loss_id==3 && reg_id == 0 % LAD  Loss + Null regularizer
        solver_str = 'lad';
        [sol,~,exitflag] = lad(X,y);
    else
        solver_str = 'CCCP_reg';
        % DC decomposition
        [loss_cvx,loss_cav,regular_cvx,regular_cav]= make_fun();
        %  variable selection
        par_cccp = par_alg;
        par_cccp.C = par_model.lambda;
        if reg_id ==2  % l1 (or adptive-l1) regularizer
            par_cccp.w_l1 = par_model.w_regularizer;
        end
        [sol, ~,iteInf] = CCCP_reg( X, y,loss_cvx,loss_cav,regular_cvx,regular_cav,par_cccp);
        iter = iter + iteInf.iter;
    end
    if par_alg.verbose>=2
        fprintf(1,'solver_str: %s\n', solver_str);
    end
    if flag_adaptive_regularizer
        % reset par_model.w_regularizer
        sol2 = abs(sol);
        sol2(sol2<=.001) = 0.001;
        w = 1./(sol2);
        par_model.w_regularizer = min(par_model.w_regularizer.* w,1E4);
        % reset the initial point
        par_alg.x0 =  sol;
        if   debug_on>0
            fwritef(1,'i_loop',i_loop,'','sol',rowVec(sol),'','w_regularizer',rowVec(par_model.w_regularizer),'');
        end
    end
end


if loss_id==1
    iteInf.iter = iter;
end

% assign output
res = y-X*sol;
resNorm = norm(res);
if nargout>1
    varargout{1} = resNorm;
end
% % % if nargout>2
% % %     varargout{2} = res;
% % % end
if nargout>2
    iteInf = completeArg(iteInf,{'solver','exitFlag','gamma'},{solver_str,exitflag,[]});
    if loss_id==1
        iteInf.gamma= par_model.gamma;
    end
    varargout{2} = iteInf;
end

    function [loss_cvx,loss_cav,regular_cvx,regular_cav]= make_fun()
        par_model0 = par_model;
        % DC decomposition of the specified loss function
        if loss_id == 1  % exp-square loss
            [loss_cvx,loss_cav]= make_dc_fun(@fun_grad_exp_square,@exp_square_cvx,par_model0.gamma);
        elseif loss_id ==2 % square loss
            loss_cvx = @fun_grad_square;
            loss_cav = [];
        elseif loss_id==3 % lad loss
            loss_cvx = @fun_grad_l1;
            loss_cav = [];
        else
            error('Do not support the specified loss function.\n');
        end
        % DC decomposition of the specified regularizer
        if reg_id ==1 % scad regularizer
            [regular_cvx,regular_cav]= make_dc_fun(@fun_grad_SCAD,@SCAD_cvx,par_model0);
        elseif reg_id==2 % l1 or adaptive-l1 regularizer
            [regular_cvx,regular_cav]= make_dc_fun(@fun_grad_l1,[],par_model0);
        elseif reg_id==0 % null regularizer
            regular_cvx = [];
            regular_cav = [];
        else
            error('Do not support the specified regularizer.\n');
        end
    end % end of the function make_fun

end % end of the function var_select






