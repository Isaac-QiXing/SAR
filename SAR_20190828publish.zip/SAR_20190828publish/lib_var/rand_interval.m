function X= rand_interval(interval,varargin)
 % generate random number uniformlly located in the specified interval
 %  Inputs: 
 %   interval: a 1-by-2 vector indicating an interval, 
 %      e.g., [-2, 3]
 %   varargin: refer the Input parameters of rand()
 %  Outputs:
 %     X: the generated array 

a = min(interval);
b = max(interval);
X = (b-a).*rand(varargin{:}) + a;

end