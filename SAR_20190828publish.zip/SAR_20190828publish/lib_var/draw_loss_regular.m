function draw_loss_regular(loss_cvx,loss_cav,regular_cvx,regular_cav)

lbound = -5.5;
rbound = 5.5;
lbound2 = -0.1;
rbound2 = 0.1;
linewidth = 2;

x_v = linspace(lbound,rbound,1000);
x2_v = linspace(lbound2,rbound2,1000);
[f_v,gd_v] = loss_cvx(x_v);
[f2_v,gd2_v] = loss_cav(x_v);
[f3_v,gd3_v] = regular_cvx(x2_v);
[f4_v,gd4_v] = regular_cav(x2_v);

% plot the functions
 
%hh= fplot(f,[lbound,rbound],'LineWidth',linewidth);
subplot(2,3,1)
plot(x_v,f_v,x_v,gd_v,'LineWidth',linewidth);
subplot(2,3,2)
plot(x_v,f2_v,x_v,gd2_v,'LineWidth',linewidth);
subplot(2,3,3)
plot(x_v,f_v+f2_v,x_v,gd_v+gd2_v,'LineWidth',linewidth);


subplot(2,3,4)
plot(x2_v,f3_v,x2_v,gd3_v,'LineWidth',linewidth);
subplot(2,3,5)
plot(x2_v,f4_v,x2_v,gd4_v,'LineWidth',linewidth);
subplot(2,3,6)
plot(x2_v,f3_v+f4_v,x2_v,gd3_v+gd4_v,'LineWidth',linewidth);

end