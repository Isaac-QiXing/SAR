function flag = varIsInMat(varName,fileName)
% check whether a variable exists in a Mat File
flag =  ~isempty(who( varName,'-file',fileName));
end