function [Xp] = standardize_sumToone(X,varargin)
% make  the absolute values of each row or column of a matrix  X sum to 1 (except zero rows or columns)
% varargin{1}: indicate the dimension
%   1: make the absolute values of each column each row of X sum to 1
%   2: make the absolute values of each row each row of X sum to 1

if nargin>1
    dim = varargin{1};
else
    dim = 1;
end

[nrow,ncol] = size(X);

Xp = zeros(size(X));
if dim==1
    sum_v = sum(abs(X),1);
    for i=1:ncol
        Xp(:,i)=(X(:,i))/(sum_v(i)+~sum_v(i));    
            % sum_v(i)+~sum_v(i): deal with the case that  that sum_v(i) == 0
    end
elseif dim==2
    sum_v = sum(abs(X),2);    
    for i=1:nrow
        Xp(i,:)=(X(i,:))/(sum_v(i)+~sum_v(i));    
            % sum_v(i)+~sum_v(i): deal with the case that  that sum_v(i) == 0
    end
end