function [y,gd] = exp_square_cvx(x,gamma)

    y =  1/(3*gamma*gamma) * x.^4;
    gd = 4/(3*gamma*gamma) * x.^3; % derivative of y at x
end