function gamma_opt = select_gamma( X,y)
% determine the  value of gamma for exponential-square loss
%   Inputs:
%       X: n_case-by-dim data matrix
%       y: n_case-by-1  observation vector
%   Outputs:
%       gamma_opt: optimal value of gamma

[n,dim] = size(X);
%  debug_on = 1; 
   debug_on = 0; 
flag_gamma_opt = 0;  % whether minimizing det(V(gamma)) to search gamma_opt

%1. Find the pseudo outlier set of the sample

% 1.1 Calculate a robust estimation beta_n
% x0 = zeros(dim,1);
% beta_n = fminsearch(@(beta) norm(y -X*beta,1), x0 ); % absolute 1-norm minimization

lambda =  0.1* norm(X,1);
arg.x0 =  zeros(dim,1);
arg.solver = 'fista';
arg.eta = [];
arg.maxIter = 400;
arg.TolX = 1e-3;
w = [];
[beta_n] = l1l1_box_ista(X,y,w,lambda,arg);

% 1.2  error vector

r = y-X * beta_n;


% 1.3 calculate Sn and Dm

Sn = 1.4826* median(abs(r-median(r)));

ind_outlier = abs(r ) >= 2.5*Sn;
n_outlier = nnz( ind_outlier);

if n_outlier > 0.5*n
    [~,ind] = sort(abs(r),'descend');
    ind_outlier = ind(1:floor(0.45*n));
    if debug_on
        fprintf(1,'outliers exceeds the maximum allowed capacity, and are adjusted.\n');
    end
end

if debug_on
    fwritef(1,'n',n,'', 'dim',dim,'','n_outlier',n_outlier,'','norm(err)',norm(r),'%f\t');
    fwritef(1,'median(r)',median(r),'',  'Sn', Sn,'' );
end

% 1.4 determine the function zeta(gamma)
% zeta(gamma) = 2m/n + 2/n * \sum_{i=m+1}^n phi(r_i, gamma)
%  with m the number of outliers
%  phi the exponetial-square function

a = exp(-r.*r);  % a(i) \in (0,1)


%   function val = zeta(gamma)
%       val = 2*n_outlier/n + 2/n*  sum(fun_grad_exp_square(r(~ind_outlier),gamma);
%   end
    function val = zeta(t)
        val = 2*n_outlier/n + 2/n*  sum(1-power(a(~ind_outlier),t))-1;  % t :=1/gamma
        % note that zeta(t) is an increasing function of t
    end

% 1.5  determine the lower bound of gamma  such that zeta(gamma)<=1
t1 = log(n/(2*(n-n_outlier))) / log(min(a));
t2 = log(n/(2*(n-n_outlier))) / (log(max(a))-1E-8); % avoid the case that max(a) == 1
if debug_on
    fwritef(1, 'zeta(t1)', zeta(t1),'', 'zeta(t2)',zeta(t2),'');
end
[t_star,exitflag] = bisection(@zeta,t1,t2);  % solve the equlate zeta(t) = 0 according to bisection method
if exitflag ==-1
    if debug_on    
        disp('bisection failed. try again.');
    end
    [t_star,exitflag] = bisection(@zeta,1E-4,1E4);  % solve the equlate zeta(t) = 0 according to bisection method
end
gamma_star = 1/t_star; % lower bound of gamma
if debug_on
    fwritef(1,  'gamma_star', gamma_star,'', 'zeta_star',zeta(t_star),'','exitflag_bisection',exitflag,'');
end

% 2. Update the tuning parameter  gamma_n
if ~flag_gamma_opt
    if gamma_star<1
        gamma_opt = 30* gamma_star ; % gamma_opt is located in the interval [gamma_star, +Inf)     
    elseif gamma_star<10
        gamma_opt = 10* gamma_star ; % gamma_opt is located in the interval [gamma_star, +Inf)
    else
        gamma_opt = 6* gamma_star ; % gamma_opt is located in the interval [gamma_star, +Inf)
    end
    return
end

% 2.1 define function det(V(gamma))

r_square = r.*r;
X_tran = X';
I1_0 = zeros(dim,dim);
for ii = 1:n
    x = X_tran(:,ii);
    I1_0 = I1_0 + x*x';
end
det_I1_0 = det(I1_0);

    function val = det_V(gamma)
        
        exp_r_square = exp(-r_square/gamma);
        % calculate the matrix I1
        coef_I1 = (2/gamma)* sum(exp_r_square.*(2*r_square/gamma-1))/n;
        %coef_I1 = (2/gamma)* sum(exp_r_square.*(2*r/gamma-1))/n;
        
        det_I1 =  (coef_I1/n).^dim * det_I1_0;  % I1 = coef_I1/n * I1_0;
        
        % calculate the covariance matrix Sigma
        coef_sigma =  (2/gamma) * r .*exp_r_square;
        Sigma = cov(diag(coef_sigma) * X);
        % calculate the function value
        val =  det(Sigma)/ (det_I1.^2);
    end



% 2.2 find the minimum of  det_V
%     min  det_V(gamma)
%     s.t.   0< gamma <= gamma_2

 lb = gamma_star;
 ub = Inf;
 

gamma_opt = fminbnd(@det_V,lb,ub);

fplot(@det_V, [lb,lb+10]);



%3. Update beta


end