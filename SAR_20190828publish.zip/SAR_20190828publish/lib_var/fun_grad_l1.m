function [y,gd]= fun_grad_l1(x,varargin)
% f(x) = w.*|x|, with w(i) >=0

if nargin>1
    arg = varargin{1};
    
% % %     lambda = arg.lambda;
    w =  ones(size(x));
    if isfield(arg,'w_regularizer') && ~isempty(arg.w_regularizer)
        w =  arg.w_regularizer;
    end
    
% % %     if isscalar(lambda)
% % %         lambda = lambda * ones(size(x));
% % %     end
    
    y = dot(w,abs(x));
    gd = w.*sign(x);
else % nargin==1
    y = norm(x,1);
    gd = sign(x);
end


end