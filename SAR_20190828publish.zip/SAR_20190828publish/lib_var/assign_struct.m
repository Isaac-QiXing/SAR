function var3 = assign_struct(var1, field_name, var2,mod)
% assign  values to fields of a struct (array), if the speified fields 
%  do not exist, creat them;
%
% Inputs:
%   var1: a struct to assign; set empty if to create a new struct (array);
%   field_name: a string cell array indicating the fieldnames to assign;
%       it can be set empty, if the var2 is a struct;
%       In this case, it equals to set field_name as all the items of
%       var2;
%   var2: May be the following cases,
%      1)  a cell vector: it has same length as field_name,  with each
%        cell the values (a vector or a cell vector) of corresponding
%        specified field, and each vector has same length as var1, expcept
%        case a. var1 is set empty; Or
%        case b. each (cell) vector of the cell values, in which case
%            the item values of all the struct member of var1 are set to
%            the corresponding specified value;
%      2)  a struct (array): it contains the fields indicated by
%        field_name for assigning;
%        if it is strcut array, it should have the same length as var1,
%        and fields of var1(i) is assigned with those of var2(i), i=1,...
%        to produce struct array var2, except the  case a or b listed
%        above;
%      3) empty value: assign the struct (array) with each specified
%        field empty value;
%   mod: Optional,  a string indicating the assign mode, 'update' or
%     'reserve'. If var1 has some fields specified in field_name, then
%      'update': all the values of these fields are updated by the new ones;
%     'reserve': reserve the values of these fields;
% Default value 'update';
%
% Outputs:
%   var3: the struct array with added fields;
% Examples:
% % example 1(1). create a struct
% item_c = {'name','id'};
% val_c = {'Marry',0,};
% st0 = assign_struct([],item_c,val_c);
%
%  --> st0.name	= Marry
%         .id	= 0
%
% example 1(2) 
%    s = assign_struct('',{'a','b'},{ { 1,2},{3,4}})
% -->
%  s(1).a =  1
%  s(1).b = 3
%  s(2).a =  1
%  s(2).b = 3
%
% % example 2. creat a struct array
% st1 = struct('name','Jocob','val',num2cell(1:2));
% st2 = assign_struct('',{'name','val','flag'},st1);
% 
%   --> st2(1).name	= 'Jocob'
%             .val	= 1	
%             .flag	= []
%       st2(2).name	= 'Jocob'
%             .val	= 2	
%             .flag	= []
%
% % example 3. assign values of certain items of a struct array
% st3 = struct('name','Tom','id',num2cell(3:4));
% st4 = assign_struct(st3,{'name','val'},st2);
%
%   --> st4(1).name	= 'Jocob'
%             .id	= 3	
%             .val	= 1	
%       st4(2).name	= 'Jocob'
%             .id	= 4	
%             .val	= 2
% % example 4. reserve the original field values
% st3 = struct('name','Tom','id',num2cell(3:4));
% st4 = assign_struct(st3,{'name','val'},st2,'reserve');
%
%   --> st4(1).name	= 'Tom'
%             .id	= 3	
%             .val	= 1	
%       st4(2).name	= 'Tom'
%             .id	= 4	
%             .val	= 2
% See also:  cell2struct();


% set defalut mode
if nargin<=3 || isempty(mod)
    mod ='update';
end
flag_mod_update = strcmpi(mod,'update');

%  deal with the case that the 2nd input is empty;
if isempty(field_name) 
    if isstruct(var2)
        field_name = fieldnames(var2);
    else
        warning('field_name is required to set if var2 is not a struct.');
        return;
    end
end

% check whether the number of elements  of var2  equal the length of
%   field_name
n_field_name = length(field_name);
if iscell(var2) && length(var2)~=n_field_name
	warning('var2 should have same length as the number of fields to assign.');   
    return;
end

% deal with case that the cell members of var2 are  strings
if iscell(var2) 
    for ii=1:numel(var2)
        if ischar(var2{ii})
            var2{ii} = var2(ii); % i.e.: var2{ii} = {var2{ii}}: add '{ }' on the string, 
        end
    end
end

% whether each element of var2 is a cell if var2 is a cell vector
if iscell(var2)
    is_cell_members_var2 = cellfun(@iscell,var2,'UniformOutput',true);
    len_members_var2 = cellfun(@length,var2,'UniformOutput',true);
end

is_empty_var1 = isempty(var1);
is_empty_var2 = isempty(var2);
is_field_of_var1 = zeros(length(field_name),1);
is_field_of_var2 = zeros(length(field_name),1);
if ~is_empty_var1    
    is_field_of_var1 = isfield(var1,field_name);     
end
if ~is_empty_var2 && isstruct(var2) 
    is_field_of_var2 = isfield(var2,field_name);    
end

% initialize var3
if isempty(var1)
    if isstruct(var2)        
        str = 'var3(';
        size_var2 = size(var2);
        n_size_var2 = length(size_var2);
        for ii=1:n_size_var2-1
            str = sprintf('%s%d,',str,size_var2(ii));
        end
        str = sprintf('%s%d)=struct();',str,size_var2(n_size_var2));
        eval(str); % str has format like 'var3(3,2,..,2) = struct()'        
    elseif iscell(var2) % var2 is cell
        n_var2 = max(len_members_var2); 
        var3(n_var2) = struct();
    elseif isempty(var2)
        var3 = struct();
    else
        warning('var2 should be a cell or a struct array');
        return;        
    end
else
    var3 = var1; % assign var1 to var3
end

if is_empty_var2 % var2 is empty
    for k = 1:numel(var3)      
        for ii=1:n_field_name
            fieldName = field_name{ii};
            if flag_mod_update || ~is_field_of_var1(ii)                                    
                var3(k).(fieldName) = [];  
            end
        end
    end     
elseif isstruct(var2)
    is_scalar_var2 = isscalar(var2);    
    for k = 1:numel(var3)      
        for ii=1:n_field_name
            fieldName = field_name{ii};          
            if flag_mod_update || ~is_field_of_var1(ii)
                if  is_scalar_var2  
                    if is_field_of_var2(ii) 
                        var3(k).(fieldName) = var2.(fieldName);     
                    else
                        var3(k).(fieldName) = []; 
                    end
                else % length(var2)>1                    
                    if is_field_of_var2(ii)
                        var3(k).(fieldName) = var2(k).(fieldName); 
                    else
                        var3(k).(fieldName) = []; 
                    end    
                end
            end
        end
    end    
elseif iscell(var2)    
    for k = 1:numel(var3)      
        for ii=1:n_field_name
            fieldName = field_name{ii};          
            if flag_mod_update || ~is_field_of_var1(ii)
                if  len_members_var2(ii)==1
                    if is_cell_members_var2(ii)
                        var3(k).(fieldName) = var2{ii}{1}; 
                            % {..., {*}, ...}  (i-th element is a cell with length 1)
                    else
                        var3(k).(fieldName) = var2{ii};
                    end
                else % len_members_var2(ii)>1
                    if is_cell_members_var2(ii)
                        var3(k).(fieldName) = var2{ii}{k};   
                    else
                        var3(k).(fieldName) = var2{ii}(k);   
                    end
                end
            end
        end
    end    
end

end

