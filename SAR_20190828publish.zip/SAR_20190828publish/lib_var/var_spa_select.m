function [sol,rho_min,dev, varargout] = var_spa_select(X,y,y_reg,parModel,par_alg)
% variable selection for spatial regression
%   Inputs:
%       X: n-by-dim data matrix, with n the number of samples, dim the number of
%          features/attributes
%       y: n-by-1  observation vector
%       y_reg: n-by-1 vector, y_reg = W  * y  
%           with W the spatial weighting matrix 
%       parModel: struct of model parmeters (see function var_select for details), in addition,
%           it has the following fields
%          .W: optional, n-by-n spatial weight matrix, only used to estimate the variance of the noise
%               default value [];  
%       par_alg: struct of CCCP algorithm parameters (see function var_select for details)
%           .ite_max_spa: maximum iteration number of the iterations of var_spa_select()
%           .ite_max:    maximum iteration number of the iterations the solver for var_select()
%           .TolRho:  tolerence of the difference of rho of two iterations
%           .TolFun
%           .TolX
%            .x0: initial point 
%   Outputs:
%       sol: dim_case-by-1 coefficient  
%       rho_min: spatial autoregression coefficient
%       dev: estimated variance of the noise which is supposed to satisfy normal distribution, 
%           if parModel.W is not provided, dev would be output as []; 
%       varargout{1}: iteInf
%           iteInf.resNorm:  residual norm,  norm(y-rho*W*y-X*sol)  
%           iteInf.MAPE: the mean absolute prediction error (MAPE):   1/n* norm(y-rho*W*y-X*sol,1);  
%           iteInf.gamma: the calculated parameter value of the Exponential-square loss,
%                   for other loss functions it would be set []
%           iteInf.exitflag_spa : 
%               0:  iteration exceeds the specified maximum number 
%               1:  iteration terminates reaching the specified TolX
%               2:  iteration terminates reaching the specified TolRho
%               3:  iteration terminates reaching the specified TolFun
%         iteInf.iter_CCCP_subprob: the iterated number of solving the convex subproblems (of
%             CCCP ) for  the exponential-square loss;  
%         iteInf.iter_rho:  the iterated number of updating rho;    
% version
%   * 2019.8.13
%    ** set sol as the initial point for the next iteration
%   * 2019.8.6
%       ** add iteInf.MAPE
%   * 2019.8.5 
%       ** add iteInf.iter_CCCP_subprob
%       ** add iteInf.iter_rho

%debug_on = 1;

[n,dim] = size(X);
par_alg = completeArg(par_alg,{'ite_max_spa','TolX','TolFun','TolRho'},{20,1E-4,1E-4,0.05});
parModel = completeArg(parModel,{'W'},{[]});
ite_max_spa_var_select = par_alg.ite_max_spa;
TolX = par_alg.TolX;
TolFun  = par_alg.TolFun;

[thresh_nnz_beta] = problemArg('thresh_nnz_beta');

W_multi_y = y_reg; % W*y;
W_multi_y_norm = norm(W_multi_y);
sol = zeros(dim,1);
rho_min = 0.5; % initial weight value of the spatial matrix
loss_ave = 0;
%options = optimoptions(@fminunc,'GradObj','on','Algorithm','trust-region');
%options = optimset('Display','off');

if par_alg.verbose>=3
    options = optimset('Display','notify');
else
    options = optimset('Display','off');
end

count = 0;

parModel.loss = lower(strtrim(parModel.loss));
switch parModel.loss
    case 'exp-square'
        loss_id = 1;
    case 'square'
        loss_id = 2;
    case 'lad'
        loss_id = 3;
    otherwise
        loss_id = -1;
        error('Unexpected loss functions specified.');
end


iter_CCCP_subprob = 0;

while true
    sol_temp = sol;
    rho = rho_min;
    loss_ave0 = loss_ave;
    % (1) update solution sol
    Y = y - rho*W_multi_y;
    [sol,resNorm,iteInf] = var_select(X,Y,parModel,par_alg);
    
    par_alg.x0 = sol; % set sol as the initial point for the next iteration
    parModel.gamma = iteInf.gamma;
    
    % count the iterated number of solving the convex subproblems (of  CCCP ) for  the
    % exponential-square loss; 
    if loss_id == 1        
        iter_CCCP_subprob = iter_CCCP_subprob + iteInf.iter;              
    end
 
    % (2) update the weight rho   
    if strcmpi(parModel.loss,'square')
        r_v = y  - X*sol;
        rho_min =  proj(dot(r_v, W_multi_y)/(W_multi_y_norm^2),0,1);
    else
        [rho_min,~] = fminbnd(@fun_rho,0,1,options); % 0< rho <1
    end
    % terminate condition    
    sol_diff =  norm(sol-sol_temp,1);
    loss_ave = fun_rho(rho_min); % average experiantial loss   
    fun_diff = abs(loss_ave-loss_ave0);    
    if par_alg.verbose>=1
        fwritef(1,'ite_var_spa',count,'%d\t','resNorm',resNorm,'','sol_diff',sol_diff,'','rho_min',rho_min,'',...
            'rho_diff',abs(rho_min-rho),'','fun_diff',fun_diff,'');
        if strcmpi(parModel.loss,'exp-square')
            fwritef(1,'gamma',iteInf.gamma,'');
        end
    end
    if par_alg.verbose>=3
        res = y-rho_min*W_multi_y-X*sol;
        resNorm = norm(res);
        fwritef(1,'resNorm',resNorm,'','sol',sol','');
    end
        
    if sol_diff < TolX
        exitFlag_spa_select = 1;
        break;
    end
     if abs(rho_min-rho) < par_alg.TolRho
        exitFlag_spa_select = 2;
        break;
    end         
        
    if fun_diff < TolFun
        exitFlag_spa_select = 3;
        break;
    end      
    if count > ite_max_spa_var_select
        exitFlag_spa_select = 0;
        break;
    end
    count = count + 1;    
    parModel.gamma = []; % reset parModel.gamma as [], the value would be re-calculated 
    
end



iteInf.iter_CCCP_subprob = 0; 
if loss_id == 1        
    iteInf.iter_CCCP_subprob = iter_CCCP_subprob;              
end 
iteInf.iter_rho = count; 

% estimate the variance of the noise, suppose the noise has normal distribution

% sigma^2 = 1/n* (y-G*X*beta)' * inv(G*G') * (y-G*X*beta)
%   with G = inv(I_n - rho* W)
%  Note that
%   (G*G')^{-1} =   (I_n - \rho* W)' *(I_n - \rho* W)
%  then 
%   sigma^2 = 1/n * \|(I_n - \rho* W)*(y-G*X*beta)\|_2^2;
dev = [];
if ~isempty(parModel.W) 
    %  calculate G*X*beta
    n_sample = length(y);
    M = eye(n_sample)-rho_min* parModel.W;
       u =  mldivide(M,X*sol); 
        %    calculate the variance of the error
    dev = 1/n_sample * norm(M*(y-u))^2;  % dev: sigma^2     
end

% calculate BIC criteria 

% BIC(lambda) = -2*ln Ln + alpha(lambda) log n 
BIC = [];
if ~isempty(parModel.W)     
    n_sample = length(y);
    M = eye(n_sample)-rho_min* parModel.W;
    log_likelihood = -n_sample*0.5 *log(2*pi) - n_sample*0.5* log(dev) + log(trace(M)) ...
        - 0.5/dev * resNorm*resNorm; 
    BIC = -2* log_likelihood + log(n_sample)* nnz(abs(sol)>=thresh_nnz_beta);
end



% outputs 

res = y-rho_min*W_multi_y-X*sol;
resNorm = norm(res);
MAPE = norm(res,1)/ length(res);
 
n_fix_output = 3;
if nargout>n_fix_output
    iteInf.resNorm = resNorm;
    iteInf.MAPE = MAPE; 
    iteInf.exitflag_spa  = exitFlag_spa_select;    
    iteInf.BIC = BIC;
    varargout{1} = iteInf;
end

    %function [y,gd] = fun_rho(rho,X,Y,sol,W,parModel)
    function [fval,gd] = fun_rho(rho)      
        gamma = parModel.gamma;             
        if loss_id ==2 % parModel.loss =='square'
           loss_fun = @fun_grad_square;
        elseif loss_id==1 % parModel.loss=='exp-square' 
            loss_fun = @(x) fun_grad_exp_square(x,gamma);
        elseif loss_id ==3 %  parModel.loss == 'lad'
            loss_fun =  @fun_grad_l1;
        end         
        err_v = y - rho*W_multi_y - X*sol; % W_multi_y = W*y is a vector with the same length as y
        [val_loss,grad_loss] = loss_fun(err_v);
        fval = 1/n * sum(val_loss);  
        gd = 1/n * sum(grad_loss.*W_multi_y );          
    end % end function of fun_rho

end % end function of var_spa_select 