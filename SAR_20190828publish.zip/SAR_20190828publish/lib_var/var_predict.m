 function [result_test ] = var_predict(matTrainFile,matTestFile, par_alg)
%      matTrainFile, matTestFile: mat file name for traing and test,
%       it contain  the same data variables;
%      par_alg: a struct of algorithm  parameters
%      result_test: a struct of the predicted results on test sets 
%          Each field  of result_test is a numeric scalar.
% Version
%   2019.1.31 15:14
%       * revise for general models


 
    gamma = 8.0; 
   
    fileName =  matTrainFile;
    d = load(fileName,  'X',  'y_fix' );  

    y = d.y_fix; 
    [sol] = var_select(d.X,y, par_alg,par_alg);
    
    % on test file 
    t  = load(matTestFile,  'X',   'y_fix' );   
    
    y_test = t.y_fix; 
    error_v = abs(y_test - t.X *  sol);
    
    
    result_test.err_norm = norm(error_v); 
    result_test.err_norm1 = norm(error_v,1); 
    result_test.err_median = median(error_v);
    result_test.err_exp_square = sum(exp_square(error_v,gamma));
 end
    

 