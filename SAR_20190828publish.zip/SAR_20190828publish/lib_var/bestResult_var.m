function i_opt = bestResult_var(result_st,mode)
%  default function handle to  find the maximum value of the first  item of result_st
%  Inputs:
%   result_st: a struct array size n_parVal_total  * k_fold   of the result output by ALG()
%  Outputs:
%   i_opt: an index of the best result

i_opt = [];
names = fieldnames(result_st);
[n_result,k] = size(result_st);
result_c = cell(n_result,k);

% if ~isempty(names)
%     [result_c{:,:}] = result_st(:,:).(names{1});
%     result_m = cell2mat(result_c);
%     [~,i_opt] = min(mean(result_m,2));
% end

% if ~isempty(names)
%     key_field = names{1};
% end

key_field = 'err_exp_square';
[result_c{:,:}] = result_st(:,:).(key_field);    
result_m = cell2mat(result_c);
    [~,i_opt] = min(mean(result_m,2));
end