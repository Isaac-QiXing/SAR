function [sol,fval,exitflag] = fmin_lasso(fun,x0, w, arg)
% minimize a differentiable function with adaptive-l1 norm
% i.e.         min_x   f(x) + C sum_i w_i*|x_i|
% Inputs:
%   fun:  a function handle of the form
%           [fval, gd] = fun(x)
%       with fval and gd the objective fucntion value and the gradient of fun at x
%   x0: the initial point;
%   w: a  vector with  size of d-by-1, with d the length of x,
%       consisting of nonnegative weights;
%   arg: a struct of parameters, with the following fields:
%   arg.C: a positive scalar of the weight of regularization term
%   arg.maxIter: optional, maximum loops number 
%   arg.TolFun: optioanl, tolerance of iterated difference of  function values
%   arg.TolX: optional, tolerance of iterated difference of  solutions
%   arg.verbose: optional, 1 or 0, whether print iteration information
% Outputs:
%  sol: a d-by-1 vector of the solved solution
%  fval: objective function value at sol
%  exitflag

d = length(w);


% z = [x; t] in R^(2d)
%   min_z   f(x) + C <w,t>
%   s.t.    x_i - t_i <=0
%           -x_i-t_i  <=0
I_d = eye(d,d);

A=[I_d -I_d
    -I_d -I_d ];
b=zeros(2*d,1);
Aeq=[];
beq=[];
A_v=[];
B_v=[];
nonlcon=[];
z0 = [x0; zeros(d,1)];
algorithm_fmincon = 'sqp'; % 'interior-point'; 'sqp' next, and 'active-set' l
% options = optimset('TolFun',arg.TolFun, 'TolX',arg.TolX,'Display','on', ...
%     'GradObj','on','Algorithm',algorithm_fmincon   );
if arg.verbose>=2
    options = optimset('TolFun',1E-5, 'TolX',1E-5,'Display','notify', ...
        'GradObj','on','Algorithm',algorithm_fmincon   );
else % arg.verbose ==0
    options = optimset('TolFun',1E-5, 'TolX',1E-5,'Display','off', ...
        'GradObj','on','Algorithm',algorithm_fmincon   );
end

[z_v,fval,exitflag] =  fmincon(@myfun,z0,A,b,Aeq,beq,A_v,B_v,nonlcon,options);

sol = z_v(1:d);

if arg.verbose >=2 
    [~,grad ] = myfun(z_v);
    grad_x = grad(1:d);
    grad_proj =   proj_subdiff_l1(-grad_x,sol,arg.C, w);
    dist =  norm(columnVec(-grad_x) -grad_proj); 
    fwritef(1,'sol',sol','%.4f\t','-grad_x',-grad_x','%.4f\t','grad_prog',grad_proj','%.4f\t' );
    fwritef(1,'dist_fmin_lasso',dist,'');
end

    function [fval2,grad2] = myfun(z)
        %   min_z   f(x) + C <w,d>
        x = z(1:d);
        t = z(d+1:end);
        [fval0,grad0] = fun(x);
        fval2 = fval0 + arg.C*dot(w,t);
        grad2 = [grad0; arg.C* w];
    end
end