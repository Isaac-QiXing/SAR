function call_CCCP_reg(dataFile,parModel)
% call CCCP_reg with specified model parameter
 
arg.C = parModel.C;
arg.TolFun = 1.0E-8;
arg.TolX = 1.0E-8;
arg.verbose  =0;
%%%arg.maxIter = 200;

% make fun
[loss_cvx,loss_cav]= make_dc_fun(@fun_grad_exp_square,@exp_square_cvx,parModel.gamma);
[regular_cvx,regular_cav]= make_dc_fun(@fun_grad_SCAD,@SCAD_cvx,parModel);




    d = load(dataFile,'arg', 'X', 'y','beta', 'rho', 'epsilon', 'W','y_fix' );
    y = d.y_fix; 
    
% % %     y = d.y - d.rho*(d.W*d.y);
% % %     err= norm(y-d.X*d.beta);
% % %     %%fwritef(1,'err',err,'');
% % %     obj =  @(beta) sum(loss_cvx(d.y - d.X*beta)) +  arg.C * sum(regular_cvx(beta))...
% % %                + sum(loss_cav(d.y - d.X*beta)) +  arg.C * sum(regular_cav(beta));
% % %  
    [sol, fval,iteInf] = CCCP_reg(d.X, y,loss_cvx,loss_cav,regular_cvx,regular_cav,arg);
    
     err_2= norm(y-d.X*sol);
     fwritef(1,'err',err,'','err_2',err_2,'','obj',obj(d.beta),'','obj_2',obj(sol),'');
     
end

end