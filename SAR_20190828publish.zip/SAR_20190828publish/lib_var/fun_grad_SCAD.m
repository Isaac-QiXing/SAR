function [y,gd]= fun_grad_SCAD(x,arg)

 
 
lambda = arg.lambda;
if isfield(arg,'w_regularizer') && ~isempty(arg.w_regularizer)
    %%%lambda = lambda.*arg.w_regularizer; 
    lambda = arg.w_regularizer; 
end
if isscalar(lambda)
    lambda = lambda * ones(size(x));
end
    
[y,gd]= fun_grad_SCAD_0(x,lambda,arg.a);
end

function [y,gd]= fun_grad_SCAD_0(x,lambda,a)
% function and gradient of SCAD
% note that lambda is a vector with the same size as x
    sgn_x = sign(x);
    x = abs(x);
    ind1 = (x<lambda);
    ind3 = x>a*lambda;
    ind2 = ~ind1 & ~ind3; 
    
    lambda_square = lambda.*lambda; 
    
    y = zeros(size(x));
    %y(ind1) = lambda * x(ind1);
    y(ind1) = lambda(ind1) .* x(ind1);
    %y(ind3) = (a+1)*lambda*lambda*0.5;
    y(ind3) = 0.5*(a+1)*lambda_square(ind3);
    %y(ind2) = -(x(ind2).*x(ind2)-2*a*lambda*x(ind2)+lambda*lambda)/(2*(a-1));
    y(ind2) = -( x(ind2).*x(ind2) - 2*a*lambda(ind2).*x(ind2) +lambda_square(ind2))/(2*(a-1));
    
    gd = zeros(size(x));
    %gd(ind1) = lambda;
    gd(ind1) = lambda(ind1);
    gd(ind3) = 0;
    %gd(ind2) = -(2*x(ind2)-2*a*lambda)/(2*(a-1));
    gd(ind2) = -(2*x(ind2)-2*a*lambda(ind2))/(2*(a-1));
    gd = gd.*sgn_x;
end