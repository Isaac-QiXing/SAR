function y = SCAD(x,lambda,a)
    x = abs(x);
    ind1 = (x<lambda);
    ind3 = x>a*lambda;
    ind2 = ~ind1 & ~ind3;  
    
    y = zeros(size(x));
    y(ind1) = lambda * x(ind1);
    y(ind3) = (a+1)*lambda*lambda*0.5;
    y(ind2) = -(x(ind2).*x(ind2)-2*a*lambda*x(ind2)+lambda*lambda)/(2*(a-1));
end