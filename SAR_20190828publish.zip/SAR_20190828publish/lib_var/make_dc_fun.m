function [h_cvx,h_cav]= make_dc_fun(f_obj,f_cvx,arg)
% make DC function handle
% Inputs:
%   f_obj: function handle of interested function
%   f_cvx: function handle of a convex function such that f_obj + f_cvx is a convex function
%       both of f_obj and f_cvx has the following form
%       [y,gd] = fun(x,arg)
%   with y,gd the function value(s) and gradient values (s) at x, 
%   arg:
%       a parameter value or a struct of parameter values

% Outputs:
%   h_cvx, h_cav: function handles such that f_obj(x) = h_cvx(x) + h_cav(x)
%       both of  h_cvx, h_cav has  the form
%       [y,gd] = h(x)

% f_obj = (f_obj+f_cvx) - f_cvx:= h_cvx + h_cav
%       with h_cvx = f_obj+f_cvx, and h_cav = -f_cvx;

if ~isempty(f_cvx)
    h_cvx = @fun_cvx;
    h_cav = @fun_cav;
else % f_cvx is empty
    h_cvx = @fun_cvx2;
    h_cav = [];
end

    function [y,gd]=fun_cvx(x)
        [y1,gd1]=f_obj(x,arg);
        [y2,gd2]=f_cvx(x,arg);
        y = y1+y2;
        gd = gd1 + gd2;
    end
    function [y,gd]=fun_cav(x)        
        [y,gd]= f_cvx(x,arg);
        y = -y;
        gd = -gd;
    end

    function [y,gd]=fun_cvx2(x)
        % for empty f_cvx
        [y,gd]=f_obj(x,arg);        
    end
end

 