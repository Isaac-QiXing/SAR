function  v = decimal2general(size_v,ind)
% transfrom a decimal integer to a general digit
%  Inputs: 
%   size_v: a vector consists positive integers, indicating the n-ary digits
%      e.g. size_v(i) = 3 means 3-1 = 2  is the maximum number for the i-th digits
%  Outputs:
%   v: a vector with the same length as SIVE_V consisting nonnegative
%       integers
n = length(size_v);
v = zeros(n,1);
base = prod(size_v);
for ii=n:-1:1 %  ii iterates from the high (right) digit to low (left) digit    
    base = base/size_v(ii);    
    v(ii) = floor(ind/base);
    ind = ind - v(ii)*base;    
end    
end