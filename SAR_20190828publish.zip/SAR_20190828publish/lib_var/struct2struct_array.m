function [par_tv,index_tb] = struct2struct_array(par, varargin )
% transform a struct with each field a cell to a struct array
% Inputs:
%   par: a struct, each field value is a cell vector;
%   varargin{1}: par_style, optional, a struct, with the field names contained in those of par,
%      each field value a string, such as 'A*', 'B+', ...
%     e.g.,
%       par_style = struct('n1','A*','n2','A*','r0', 'B+', 'r1', 'B+',  'r2', 'B+');
%            n1, n2 is in group A, traversing style: *
%            r0, r1, r2 is in group B, traversing style: +
%     traverse style: '*'  :  traverse each possible combinations
%    (par.n1{1}, par.n2{1}),  (par.n1{1}, par.n2{2}), ... (par.n1{1}, par.n2{N2})
%     ...
%    (par.n1{N1}, par.n2{1}),  (par.n1{N1}, par.n2{2}), ... (par.n1{N1}, par.n2{N2})
%
%    with N1 = length(par.n1), n2 = length(par.n2);
%
%    traverse style '+' : traverse corresponding parameters:
%    (par.r0{1},par.r1{1}, par.r2{1}),  (par.r0{2},par.r1{2}, par.r2{2}), ... (par.r0{N},par.r1{N}, par.r2{N})
%    with N = length(par.r0);
%    By default, all the fields are in a common group, with the traversing style '*";
%   varargin{2}, par_baseline:  a struct with  default settings of the fields;
%%%%%%%%%
%     By default, if par_baseline is not set, then it will generate all possible combinations
%     of each group values. (for future version to set the default value of par_baseline)
%%%%%%%%%%
%   varargin{3}, parameter combinatorial mode among groups, possible values:  '*' or '+'
%           suppose group A has the  number of parameter settings as   numA
%                   group B has the  number of parameter settings as   numB
%                   group C has the  number of parameter settings as   numC
%       mode '*':   generate parameter settings with the number of numA * numB * numC
%       mode '+':   generate parameter settings with the number of numA + numB + numC
%           in mode '+', PAR_BASELINE must be set;
%       default value '*';
% Outputs:
%   par_tv: a struct array, with the same field names as par, by traversing each field value (a cell);
%   index_tb: an table, with row number == length(par_tv),
%    it has  VariableNames as the fieldnames of the input struct PAR
%    each column of it consists of the indices of the specified candidate values;
%
%  Eg. 1  no specified groups and style,
%   par.n1 = {10, 20};
%	par.n2 = {50,  180};
%   par_tv = struct2struct_array(par);
%  then par_tv is a struct array having length 4:
%      par_tv(1).n1 = 10;
%      par_tv(1).n2 = 50;
%      par_tv(2).n1 = 10;
%      par_tv(2).n2 = 180;
%      par_tv(3).n1 = 20;
%      par_tv(3).n2 = 50;
%      par_tv(4).n1 = 20;
%      par_tv(4).n2 = 180;
%
%   Eg.2  two groups with no specified baseline parameter,
%		group 1: 2*2 = 4 parameter settings
%	      group 2: 2  parameter settings
%		output a parameter struct array with length 4 * 2 = 8
%   par.n1 = {10, 20};
%	par.n2 = {50,  180};
%	par.r0 = {1.0,  0.5};
%	par.r1 = {0.8,  0.3};
%	par.r2 = {0.6,  0.1};
%   par_style = struct('n1','A*','n2','A*','r0', 'B+', 'r1', 'B+',  'r2', 'B+');
%   par_tv = struct2struct_array(par,par_style);
%   Then,
%      par_tv(1).n1 = 10;
%      par_tv(1).n2 = 50;
%      par_tv(1).r0 = 1.0;
%      par_tv(1).r1 = 0.8;
%      par_tv(1).r2 = 0.6;
%
%      par_tv(2).n1 = 20;
%      par_tv(2).n2 = 50;
%      par_tv(1).r0 = 1.0;
%      par_tv(1).r1 = 0.8;
%      par_tv(1).r2 = 0.6;
%  ...
%      par_tv(4).n1 = 20;
%      par_tv(4).n2 = 180;
%      par_tv(1).r0 = 1.0;
%      par_tv(1).r1 = 0.8;
%      par_tv(1).r2 = 0.6;
%
%      par_tv(5).n1 = 10;
%      par_tv(5).n2 = 50;
%      par_tv(5).r0 = 1.0;
%      par_tv(5).r1 = 0.8;
%      par_tv(5).r2 = 0.6;
%  ...
%      par_tv(8).n1 = 20;
%      par_tv(8).n2 = 180;
%      par_tv(8).r0 = 0.5;
%      par_tv(8).r1 = 0.3;
%      par_tv(8).r2 = 0.1;
%
%   Eg.3  two groups with specified baseline parameter,
%		group 1: 2*2 = 4 parameter settings
%	      group 2: 2  parameter settings
%		output:  a parameter struct array with length 4 + 2 = 6
%   par.n1 = {10, 20};
%	par.n2 = {50,  180};
%	par.r0 = {1.0,  0.5};
%	par.r1 = {0.8,  0.3};
%	par.r2 = {0.6,  0.1};
% 	par_baseline = struct('n1',30,'n2',60,'r0', 0.8, 'r1', 0.6,  'r2',	0.4);
%   par_style = struct('n1','A*','n2','A*','r0', 'B+', 'r1', 'B+',  'r2', 'B+');
%   par_tv = struct2struct_array(par,par_style,par_baseline);
%   Then,
%      par_tv(1).n1 = 10;
%      par_tv(1).n2 = 50;
%      par_tv(1).r0 = 0.8;
%      par_tv(1).r1 = 0.6;
%      par_tv(1).r2 = 0.4;
%
%      par_tv(2).n1 = 20;
%      par_tv(2).n2 = 50;
%      par_tv(2).r0 = 0.8;
%      par_tv(2).r1 = 0.6;
%      par_tv(2).r2 = 0.4;
%  ...
%      par_tv(4).n1 = 20;
%      par_tv(4).n2 = 180;
%      par_tv(4).r0 = 0.8;
%      par_tv(4).r1 = 0.6;
%      par_tv(4).r2 = 0.4;
%
%      par_tv(5).n1 = 30;
%      par_tv(5).n2 = 60;
%      par_tv(5).r0 = 1.0;
%      par_tv(5).r1 = 0.8;
%      par_tv(5).r2 = 0.6;
%
%      par_tv(6).n1 = 30;
%      par_tv(6).n2 = 60;
%      par_tv(6).r0 = 0.5;
%      par_tv(6).r1 = 0.3;
%      par_tv(6).r2 = 0.1;
%
%  Version:
%   * 2019.5.5
%       ** allow merely setting a part of style  of the fields, the remaining fields are dealt with
%           baseline settings
%       ** Add a parameter of the group combinatorial style: '*' or '+'
%       ** Add output index_tb
%     * 2019.4.28
%		The default combination style of the groups are changed to `multiplication' rather than `additon'
%
%	* First version. 2014.1.15

debug_on = 0;

% 0.1 get input parameter
par_style = [];
if nargin>=2
    par_style = varargin{1};
end

par_baseline = [];
if nargin>=3
    par_baseline = varargin{2};
end

among_group_mode = '*';
if nargin>=4
    among_group_mode = varargin{3};
end
% 0.2 identify the fields that specified par_styles

% check if there are  fieldnames of par_style not contained in par
isempty_style = isempty(par_style);

if ~isempty_style
    field_style = fieldnames(par_style);
    field_par = fieldnames(par);
    ind0 = ismember(field_style,field_par);
    if  nnz(ind0) < length(field_style)
        warning('Some of the specified field of PAR_STYLE is not contained in the struct PAR');
        field_style = field_style(ind0);  % only preserve those effective styles
        par_style = assign_struct('',field_style,par_style); % update par_style, remove inactive fields
        isempty_style = isempty(par_style);
    end
end
if ~isempty_style
    par_act = assign_struct([],field_style,par); % consisting of the fields that specified par_styles
else
    par_act = par;
end

% 0.3 set the default parameter values
% 0.3.1 set default parameter values as par_baseline_total
par_baseline_total = par; % par_baseline_total: struct consisting  the default values of all parameters (fields)
% 0.3.2 employ those specified default values  if they had been set  by the input parameter  par_baseline
if ~isempty(par_baseline)
    par_baseline_total = assign_struct(par_baseline_total, fieldnames(par_baseline), par_baseline);
    % par_baseline_total may contain fields that not contained in the struct PAR
end
% 0.3.3
isempty_baseline = isempty(par_baseline_total);

% 0.4 order the fields

% ensure that the fieldnames obtained by fieldnames() corresponds to the cell obtained by struct2cell(par)
if ~isempty_style
    par_style = orderfields(par_style,par_act);
end
if isempty_style
    [par_tv,index_tv] = struct2struct_array0(par_act); % no style and group specified
    index_tb = struct2table(index_tv);
    return
end

% 1.1 preprocessing: get the number of assigned values
par_c = struct2cell(par_act);
len_par_v = cellfun(@length,par_c,'UniformOutput',1); % number of elements in each cell of par_act

% 1.2 preprocessing: identify the number of groups according to the specified styles
fieldname_c = fieldnames(par_style);
style_c = struct2cell(par_style);
style_v   = cellfun(@str2int,style_c,'UniformOutput',1);
[a, iv,ia] = unique(style_v);

num_group = length(a); % number of groups
style_group_c = cellfun(@(str) str(end),style_c(iv)); % style character

% 1.3 preprocessing:  calculate the number of the combinatorial parameter values of each group
n_par_group_v = zeros(num_group,1);
for ii = 1:num_group
    % deal with the ii - th group
    style_s = style_group_c(ii); % style character
    ind = (ia == ii); % indices of the fields
    if strcmpi(style_s,'*')
        n_par_group_v(ii) = max(prod(len_par_v(ind)),1); % max(..,1): deal with the case of empty parameter values
    else % style_s=='+'
        m = unique(len_par_v(ind));
        if length(m)~=1
            str = sprintf(' the number of elements of the fields: ');
            str = [str  sprintf('%s,  ',fieldname_c{find(ind)}) ];
            str = [str 'should equal.'];
            error(str);
        end
        n_par_group_v(ii) =  m;
    end
end
if strcmpi(among_group_mode,'+')
    n_par_tv = sum(n_par_group_v); % n_par_tv: length of the struct array of par_tv
elseif strcmpi(among_group_mode,'*')
    n_par_tv = prod(n_par_group_v);
else     
     error('Unsupported AMONG_GROUP_MODE. Only ''*'' or ''+'' is supported.');
end

% 1.4 preprocessing: generate the combinatorial parameter values and indices of each group
par_group_c = cell(1,num_group);
index_group_c = cell(1,num_group);
for ii = 1:num_group
    % deal with the ii - th group
    style_s = style_group_c(ii); % style character
    ind = (ia == ii); % indices of the fields
    if strcmpi(style_s,'*')
        par_sub = assign_struct('',fieldname_c(ind),par_act);
        [par_sub_tv,index_sub_tv] = struct2struct_array0(par_sub);
    else % style_s=='+'
        par_sub_tv = assign_struct('',fieldname_c(ind),par_c(ind));
        n_field = nnz(ind);
        n_par_group  = n_par_group_v(ii); % n_par_group: number of settings contained in ii-th group
        Tmp = [1:n_par_group]'*ones(1,n_field); % Tmp: a matrix with the number of rows as n_par_group
        Tmp_c = num2cell(Tmp,1); % Tmp_c: a 1-by-n_field cell array
        index_sub_tv = assign_struct('',fieldname_c(ind),Tmp_c);
    end
    par_group_c{ii} = par_sub_tv;
    index_group_c{ii} = index_sub_tv;
end

% if debug_on
%     for ii=1:num_group
%         index_sub_tv =  index_group_c{ii};
%         fwritef(1,'i_group',ii,'','index_sub_tv',index_sub_tv,'');
%     end
% end

% 2.1  generate the struct array under the group combinatorial style '+'
if strcmpi(among_group_mode,'+')  && isempty_baseline
    error('In mode ''+'', PAR_BASELINE must be set.');
end

if strcmpi(among_group_mode,'+')
    % initialize par_tv and index_tv
    par_tv(1:n_par_tv) = par_baseline_total;
    field_total_c = fieldnames(par_baseline_total);
    index0_t = assign_struct([],field_total_c,num2cell(ones(1,length(field_total_c)) ));
    index_tv(1:n_par_tv) = index0_t;
    % assign the struct array: par_tv
    p = 1;
    for i_group = 1:num_group
        % deal with the ii - th group         
        len_group =  n_par_group_v(i_group);
        par_sub_tv = par_group_c{i_group};        
        index_sub_tv = index_group_c{i_group};       
        par_tv(p:p+len_group-1)   = assign_struct(par_tv(p:p+len_group-1),   [],  par_sub_tv);
        index_tv(p:p+len_group-1) = assign_struct(index_tv(p:p+len_group-1), [],  index_sub_tv);
        p = p+len_group;
    end
    index_tb = struct2table(index_tv);
    return
end

% 2.2  generate the struct array under the group combinatorial style '*'

% 2.2.1 initialize par_tv and index_tv
par_tv(1:n_par_tv) = par_baseline_total;
field_total_c = fieldnames(par_baseline_total);
index0_t = assign_struct([],field_total_c,num2cell(ones(1,length(field_total_c)) ));
index_tv(1:n_par_tv) = index0_t;

% 2.2.2 generate index matrix of the values of each group
%   Index_group:  a n_par_tv-by-num_group matrix
%        Index_group(i,j):  the index of the combinatorial settings of the j-th group for the i-th parameter setting:
%   E.g.,  group 1: 2  set of values
%          group 2: 3 set of values
%          group 3: 2 set of values
%   then
%      Index_group = [ ...
%           1      1    1   <-- the 1st parameter: consists  the 1st-settings  of group 1, ... 1st-settings of group 3
%           2      1    1
%           1      2    1
%           2      2    1
%       ...
%           2      3    2  <-- the 12th parameter: consists  the 2nd-settings  of group1, ... 2nd-settings of group 3
%           ];

index2_group_c = cell(1,num_group);
if debug_on
    fwritef(1,'n_par_group_v',n_par_group_v,'','num_group',num_group,'');
end

n_par_group_reverse_v = n_par_group_v(end:-1:1);
% reverse the vector n_par_group_v, such that the index of the settings of the original
% last group would vary first

[index2_group_c{1:num_group}] = ind2sub(rowVec(n_par_group_reverse_v),[1:n_par_tv]');  
index2_group_c = cellfun(@columnVec,index2_group_c,'uniformOutput',false);

index2_group_c = index2_group_c(end:-1:1);
% reverse the cells of index2_group_c to recover the original order
Index_group  = cell2mat(index2_group_c);

if debug_on
    fwritef(1,'n_par_group_reverse_v',n_par_group_reverse_v,'','Index_group',Index_group,'');
end
% 2.2.3 assign the struct array: par_tv and index_tv
for i_group = 1:num_group
    for i_val = 1:n_par_group_v(i_group)
        ind = find(Index_group(:,i_group)== i_val); % i_val: index of the parameter settings of the current group
        par_sub_tv = par_group_c{i_group};
        % par_group_c: a cell array consisting of the value settings of each group
        index_sub_tv = index_group_c{i_group};        
        % index_group_c: a cell array consisting of the indices  of each group
        fieldname_sub = fieldnames(par_sub_tv);
        if debug_on
            save('temp.mat','par_tv','index_tv','ind','par_sub_tv','i_val');
            aa1 = assign_struct(par_tv(ind),fieldname_sub,par_sub_tv(i_val));
            aa0 = par_tv(ind);
            save('temp.mat','aa1','aa0','par_tv','index_tv','ind');
        end
        par_tv(ind) = assign_struct(par_tv(ind),fieldname_sub,par_sub_tv(i_val));
        index_tv(ind) = assign_struct(index_tv(ind),fieldname_sub,index_sub_tv(i_val));
    end
end
index_tb = struct2table(index_tv);
end % end of the function struct2struct_array()


function t = str2int(str)
% transform a string to an integer
v = double(str);
t = 0;
pow = 0;
for ii=1:length(v)
    pow = pow + 2;
    t = t+v(ii) * 10^pow;
end
end

function [var2, index_tv ]= struct2struct_array0(var1)
% recast a struct with cell array item values to a struct vector
% Inputs:
%    var1: a scalar struct, some of the field values may be cell array;
% Outputs:
%    var2: the generated struct vector, traversing all the values of each
%          cell array;
%       E.g.,
%        var1 = struct('name',{{'Job','Marry','Cate'}},'id',{{11,22;33 44}});
%        var2 = struct2struct_vector(var1);
%        then the generated struct array var2 has 3 * 4 = 12 element:
%          var2(1).name = 'Job',
%                  .id = 11;
%          var2(2).name = 'Marry',
%                  .id = 11;
%          var2(3).name = 'Cate',
%                  .id = 11;
%           ...
%          var2(12).name = 'Cate',
%                  .id = 44;
% index_tv: a struct array consisting of the indices of the candidate values for each field

index_tv = struct();
if ~isscalar(var1) || ~isstruct(var1)
    warning('It is required that the input is a scalar struct.');
    var2 = var1;
    return;
end

field_c = fieldnames(var1);
n_field = length(field_c);  % number of items of the struct

% number of the length of the cell values
size_field_v= zeros(n_field,1);
% each element stores the number of given values in the cell of the
%   item value, set 0 if the corresponding item value is not a cell
for ii = 1:n_field
    if iscell(var1.(field_c{ii}))
        size_field_v(ii) = numel(var1.(field_c{ii}));
    end
end

% generate a struct array traversing all the values of the cells
iscell_item_v = size_field_v>0; % whether the value of each item is cell
size_field_v = max(size_field_v,1);
len_var2 = prod(size_field_v); % total length of the struct array
var2 = cell2struct(cell(len_var2,n_field),field_c,2);  % initilize var2

index_tv = assign_struct('',field_c,[]);

for i_var =  len_var2:-1:1 %%% 1:len_var2
    % assign each struct
    id_arg_v = decimal2general(size_field_v,i_var-1)+1; % indices to traverse the cells
    for i_item = 1:n_field
        % assign each item of the struct var2
        if size_field_v(i_item)>1 || iscell_item_v(i_item)
            var2(i_var).(field_c{i_item}) = ...
                var1.(field_c{i_item}){id_arg_v(i_item)};
        else % size_field_v(i_item)==1
            var2(i_var).(field_c{i_item}) = var1.(field_c{i_item});
        end
        % assign index_tv
        index_tv(i_var).(field_c{i_item})  = id_arg_v(i_item);
    end
end

end

