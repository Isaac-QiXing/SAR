function [y,gd] = SCAD_cvx(x,arg)
    a = arg.a;
    y =  1/(2*(a-1)) * x.*x;  
    gd = 1/(a-1) * x;   % derivative of y at x
end
