function saveData(fileName,varargin)
%#function save
% save data to a specified file
% for i=1,2,...
%   varargin{2*i-1}: the varaible name
%   varargin{2*i}: the varaible value
%   the last inputs can also be the parameters:
%
% usage
%  A1=ones(2,2); B1 = 1:5;
%   saveData(matFileName, 'A',A1, 'B',B1);
% versions
%   2019.8.8: support the parameters '-append'

debug_on = 0;
% % %varargin = cellfun(@strtrim,varargin,'UniformOutput',false);
ispar_v = cellfun(@isParameter,varargin,'UniformOutput',true);

% find the first occurance of the parameter (if any)
%ind = 0;
ind = find(ispar_v);
%n_par = length(ind);
existPar = ~isempty(ind);
if existPar
    % check whether the remaing inputs are all parameters
    if nnz(~ispar_v(ind:end))>0
        error('All the input parameters (with leading character ''-'' ) should be put at the end of the inputs');
    end
else % ind is empty
    ind = nargin;
end

str = '';

n_par = ind -1; % n_par: the number of input variable names and values, excluding the first input of FILENAME

if mod(n_par,2) == 1
    error('The inputs variables should be pairs of the variable name and value.');
end

%%%for ii=1:floor((nargin-1)/2)
for ii=1:floor(n_par/2)
    eval(sprintf('%s=varargin{2*ii};',varargin{2*ii-1}));
    str = sprintf('%s,''%s''',str,varargin{2*ii-1});
end

strPar = '';
if existPar
    strPar = [',''', strjoin(varargin(ind:end),''','''), ''''];
end

if debug_on
    disp(ispar_v);
    disp(strPar);
end

if ~isempty(str)
    if ~existPar
        eval(sprintf('save(''%s''%s);',fileName,str));        
    else
        eval(sprintf('save(''%s''%s%s);',fileName,str,strPar));
        if debug_on
            fprintf(sprintf('save(''%s''%s%s);',fileName,str,strPar));
        end
    end
else
    warning('Both the variable name and value is needed.');
end

end

function flag = isParameter(str)

flag = int32(0);
if ~ischar(str)
    return
end
str = strtrim(str);
if ~isempty(str)
    flag = strcmp(str(1),'-'); % whether the leading character is '-'
    flag = int32(flag);
end
end