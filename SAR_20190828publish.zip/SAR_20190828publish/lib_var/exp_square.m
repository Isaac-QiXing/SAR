function y = exp_square(x,gamma)
    y = 1- exp(-x.*x/gamma);
end