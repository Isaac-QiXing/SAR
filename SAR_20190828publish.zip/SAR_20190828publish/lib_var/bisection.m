function [p,exitflag] = bisection(f,a,b)
% 
% Outputs:
%   exitflag:
%   2: terminate as the change in  x  was less than specified tolerance 
%   1: terminate as iterated function value   was less than specified tolerance 
%   0: Number of iterations exceeded maximum iterations
%   -1: initial points are illegal: f(a)*f(b)>0
%   
% provide the equation you want to solve with R.H.S = 0 form.
% Write the L.H.S by using inline function
% Give initial guesses.
% Solves it by method of bisection.
% A very simple code. But may come handy
%
%
% Versions:
%   2019.5.23 adds maximum iteration number

p = (a + b)/2;
exitflag = -1;
tolFun = 1E-5;
tolX = 1E-5;

if f(a)*f(b)>0
    disp('Wrong choice bro')
else
    %%%err = abs(f(p));
    max_ite = 30;
    ite = 0;
    while 1
        if f(a)*f(p)<0
            b = p;
        else
            a = p;
        end
        p = (a + b)/2;
        err = abs(f(p));
        
        if err < tolFun
            exitflag = 1;
            break;
        end
        if abs(b-a)< tolX
             exitflag = 2;
            break;
        end            
        ite = ite+1;
        if ite >=max_ite
            break
        end
    end
end

