function [x,fval,exitflag] = lad(A,b)
% LAD: min_x ||Ax-b||1
% Inputs: 
%   A: n-by-dim matrix 
%   b: n-by-1 column vector 
 

% LAD-TO-LP REFORMULATION with suppression trick

dim = size(A,2); % dimension
n = length(b);
c = [zeros(dim,1);ones(n,1)];

F = [A -eye(size(b,1)); -A -eye(size(b,1))];
g = [b; -b];
 

% z = [x,u];  x in R^d, u in R^n
% |x|_1 = <c,z> = sum_i u_i
%   Ax - b <= u  
%   -(Ax-b) <= u for each element


% Run the LP solver
[z,fval,exitflag] = linprog(c,F,g); %min_x c'x subject to Fx < g

x = z(1:dim);

end