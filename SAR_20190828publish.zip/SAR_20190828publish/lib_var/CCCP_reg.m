function [sol, fval,iteInf] = CCCP_reg(X,y,loss_cvx,loss_cav,regular_cvx,regular_cav,arg)
% CCCP algorithm to solve regression coefficients such that
%       X* beta near  y
% Inputs:
%   X: n-by-p matrix, with n samples, p features
%   y: n-by-1 vector
%   loss_cvx, loss_cav, regular_cvx, regular_cav:   function handels with the form
%           [fx, grad] = fun(t)
%   where
%       t: a scalar number or a vector (the function should support vector-operation)
%       fx: function value(s), a scalar number or a column vector of function values, with same length as t;
%       grad: derivative value(s), a scalar number or a column vector of function values, with same length as t;
%
%    the loss function has the form
%           loss(t) = loss_cvx (t) + loss_cav(t)
%    the regularization term has the form
%           regular(t) = regular_cvx(t) + regular_cav(t)
%    If either of the function handle is empty, set it []
%  arg: optional, struct of parameters
%   arg.C: a positive scalar of the weight of regularization term
%   arg.x0: initial point
%   arg.maxIter: optional, maximum loops number of CCCP algorithm
%   arg.TolFun: optioanl, tolerance of iterated difference of  function values
%   arg.TolX: optional, tolerance of iterated difference of  solutions
%   arg.verbose: optional, 1 or 0, whether print iteration information
%   arg.w_l1:   optional, the weighted vector of the adaptive l1  norm, default value [];
%       It is recommend to provided this weighted vector if the regularizer is 'l1' or
%       'adaptive-l1' norm; 
%       Note that if arg.w_l1 the algorithm would deal with the regularizer as l1 or
%       adaptive-l1 norm;
%   arg.FixInitialPoint: 1 or 0, whether to fix the inital point at each call
%       such that the result are repeatable
%   the function solves the model:
%       min_beta  1/n * Sum_[i=1..n] loss( y(i)-<X_i,beta> ) + C*Sum_[j=1..p] regular(beta_j)
% Outputs:
%   sol: a vector of solution of the model
%   fval: objective function value
%   iteInf: iteration information
% Versions
%   * 2019.7.24
%    **   adjust the default parameter value arg.TolFun, arg.TolX  of fmincon() 
%    ** replace fmin_lasso() with fmin_lasso_ista()
%   * 2019.3.16  specially deal with the case of l1 or adaptive-l1 regularizer
%  2019.1.29  add weight 1/n

if nargin<=2
    arg = struct();
end
if isfield(arg,'verbose') && arg.verbose>=2
    display_str_default = 'notify';
    %display_str_default = 'off';
else
    display_str_default = 'off';
end
arg = completeArg(arg,{'C','maxIter','TolFun','TolX','FixInitialPoint','verbose','Display','w_l1'},...
                        {1.0, 200, 1.0E-5,      1E-4,1,                 1, display_str_default, []});
n_max_iter = arg.maxIter;

isempty_w_l1 = isempty(arg.w_l1);

isempty_loss_cvx = isempty(loss_cvx);
isempty_loss_cav = isempty(loss_cav);
isempty_regular_cvx = isempty( regular_cvx);
isempty_regular_cav = isempty( regular_cav);



if isempty_loss_cvx && isempty_loss_cav
    error('Either the function handle loss_cvx or loss_cav should be non-empty');
end
% if isempty_regular_cvx && isempty_regular_cav
%     error('Either the function handle regular_cvx or regular_cav should be non-empty');
% end

flag_convex_model = isempty_loss_cav && isempty_regular_cav; % whether the model is convex

if flag_convex_model && arg.verbose
    fprintf('Convex model is given. CCCP would be only iterated once.');
end

[n,p] = size(X);
y = columnVec(y);
if length(y)~=n
    error('Input y should be a column vector with the same number of rows as X.');
end
% transpose X
X_tran = X';

% initialization
if arg.FixInitialPoint
    rng(1,'twister');
else
    rng('shuffle');
end

if isfield(arg,'x0') && ~isempty(arg.x0)
    beta_0 = arg.x0;
    beta_0 = beta_0 + 0.01*(rand(size(beta_0))-0.5)*2; % add a small perturbation
else
%     beta_0 = 0.5*(rand(p,1)-0.5)*2;
    beta_0 = 0.1*(rand(p,1)-0.5)*2;
end

if arg.verbose>=3 
    fwritef(1,'',arg,'','beta_0',beta_0','');
end

%beta_0 = zeros(p,1);
beta_k = beta_0;

A=[];
b=[];
Aeq=[];
beq=[];
A_v=[];
B_v=[];
nonlcon=[];
algorithm_fmincon = 'interior-point';
  options = optimset('TolFun',arg.TolFun, 'TolX',arg.TolX,'Display',display_str_default, ... 
                  'GradObj','on','Algorithm',algorithm_fmincon   );
% options = optimset('TolFun',1E-6, 'TolX',1E-6,'Display',display_str_default, ... 
%                  'GradObj','on','Algorithm',algorithm_fmincon   );             
% options = optimoptions('fminunc','GradObj','on','Algorithm','trust-region','Display',display_str_default);

fval = 0;

% obj =  @(beta) 1/n*sum(loss_cvx(y - X*beta)) + arg.C* sum(regular_cvx(beta))...
%     + 1/n*sum(loss_cav(y - X*beta)) + arg.C* sum(regular_cav(beta));
    function [fx,loss_val,reg_val,grad_v]= obj(beta)
        % grad_v: a p-by-1 vector,  the gradient of the loss   at beta
        
        err_v = y - X*beta  ;
        sum_f_loss_cvx = 0;
        sum_f_loss_cav = 0;
        sum_f_regular_cvx = 0 ;
        sum_f_regular_cav = 0;
        g_loss_cvx = zeros(size(beta));
        g_loss_cav = zeros(size(beta));
        if ~isempty_loss_cvx
            [f_loss_cvx,g_loss_cvx]= loss_cvx(err_v);
            sum_f_loss_cvx  = sum(f_loss_cvx);
        end
        if ~isempty_loss_cav
            [f_loss_cav,g_loss_cav]= loss_cav(err_v);
            sum_f_loss_cav  = sum(f_loss_cav);
        end
        if ~isempty_regular_cvx
            [f_regular_cvx,~]= regular_cvx(beta);
            sum_f_regular_cvx = sum(f_regular_cvx);
        end
        if ~isempty_regular_cav
            [f_regular_cav,~]= regular_cav(beta);
            sum_f_regular_cav = sum(f_regular_cav);
        end
        loss_val =1/n* sum_f_loss_cvx + 1/n* sum_f_loss_cav;  % loss 
        reg_val =arg.C* sum_f_regular_cvx +  arg.C* sum_f_regular_cav;  % regularization term
        fx = loss_val + reg_val;
        g_loss = g_loss_cvx  + g_loss_cav;
        grad_v =  -sum(diag(g_loss)*X,1)/n;
        %fx = 1/n* sum_f_loss_cvx + arg.C* sum_f_regular_cvx +  ...
        %    1/n* sum_f_loss_cav + arg.C* sum_f_regular_cav;
    end

for iter = 1: n_max_iter
    
    if isempty_w_l1
        %[beta2,fval2,exitflag] =  fmincon(@fun,beta_k,A,b,Aeq,beq,A_v,B_v,nonlcon,options);
        [beta2,fval2,exitflag] =  fminunc(@fun,beta_k,options);
    else % l1 or adaptive-l1 regularizer
         %  Min_{beta}       obj(beta):= loss_cvx(beta) +   arg.C * sum_i arg.w_l1(i)*|beta(i)|
        %                           + <grad L_cav(beta_k),beta>
        %  with        
        %       L_cav(beta) =  loss_cav(beta) 
        [beta2,fval2,exitflag] = fmin_lasso(@fun_l1,beta_k, arg.w_l1, arg);
        %[beta2,fval2,exitflag] = fmin_lasso_ista(@fun_l1,beta_k, arg.w_l1, arg);
    end
   
    % print iteinforamtion
    if arg.verbose>=2
        [fval_obj, loss_val,reg_val ] = obj(beta2);
        fprintf(1,'iter: %d\t | fval_sub: %.4f | fval: %.4f\t loss: %.4f\t reg: %.4f\t | \t norm(sol): %.4f  | exitflag: %d \n',...
            iter, fval2, fval_obj, loss_val,reg_val,norm(beta2),exitflag);
        %         fprintf(1,'iter: %d\t | fval_sub: %.4f |   \t norm(sol): %.4f  | exitflag: %d \n',...
        %             iter, fval2,  norm(beta2),exitflag);
        fwritef(1,'diff sol:', norm(beta2-beta_k,1),'', 'diff fval:', abs(fval-fval2),'');
    end
    if arg.verbose>=3
        fwritef(1,'sol',rowVec(beta2),'%.2f\t');
        [fx22,gd22] = fun(beta2);
        fwritef(1,'fx',fx22,'','gd',rowVec(gd22),'%.2f\t');
        [fx33,gd33] = fun_l1(beta2);
        fwritef(1,'gd_loss',rowVec(gd33),'%.2f\t');
    end
    % stopping criteria
    if norm(beta2-beta_k,1)<arg.TolX || (iter>1 && abs(fval-fval2)<arg.TolFun)
        break;
    end
    if flag_convex_model
        break;
    end
    
    beta_k = beta2;
    fval = fval2;
    
end % end iter
iteInf.flag =  1.0*(iter<n_max_iter);
iteInf.iter = iter;

% calculate the distance of the -1/n*sum_i {nabla Loss(y_i-<x_i,sol>)}  and   C* partial |sol|_1
%[~, ~,~,grad_v ] = obj(beta2);
[~,grad_v] = fun_l1(beta2);
grad_proj =   proj_subdiff_l1(-grad_v,beta2,arg.C);
%%%
% % % grad_proj
% % % grad_v
%%%
iteInf.dist =  norm(columnVec(-grad_v) -grad_proj); 

sol = beta2;
%%%error_v = y-X*sol;
fval = obj(sol);

if arg.verbose>=2
    fwritef(1,'dist',iteInf.dist,'');
end


    function [fx,gd] = fun(beta)
        % objective function and gradient of the subproblem of CCCP
        %  Min_{beta}       obj(beta):= L_cvx(beta) + <grad L_cav(beta_k),beta>
        %  with
        %       L_cvx(beta) =  loss_cvx(beta) + arg.C * regular_cvx(beta)
        %       L_cav(beta) =  loss_cav(beta) + arg.C * regular_cav(beta)
        
        % initialization
        
        gd_loss_cvx_2 = zeros(p,1);
        gd_loss_cav_2 = zeros(p,1);
        gd_regular_cvx = zeros(p,1);
        gd_regular_cav = zeros(p,1);
        sum_f_loss_cvx = 0;
        sum_f_regular_cvx = 0;
        
        % calulate errors
        err_v = y - X*beta  ;
        err_k_v = y - X*beta_k  ;
        
        % calculate function values and gradient
        if ~isempty_loss_cvx
            [f_loss_cvx, gd_loss_cvx]= loss_cvx(err_v);
            sum_f_loss_cvx  = sum(f_loss_cvx);
            
            gd_loss_cvx = columnVec(gd_loss_cvx);
            gd_loss_cvx_2 = -1* sum(X_tran*spdiags(gd_loss_cvx,0,n,n),2);
        end
        if ~isempty_loss_cav
            [~, gd_loss_cav]= loss_cav(err_k_v);
            
            gd_loss_cav = columnVec(gd_loss_cav);
            gd_loss_cav_2 = -1* sum(X_tran*spdiags(gd_loss_cav,0,n,n),2);
        end
        if ~isempty_regular_cvx
            [f_regular_cvx, gd_regular_cvx]= regular_cvx(beta);
            sum_f_regular_cvx = sum(f_regular_cvx);
            gd_regular_cvx = columnVec(gd_regular_cvx);
            
        end
        if ~isempty_regular_cav
            [~, gd_regular_cav]= regular_cav(beta_k);
            gd_regular_cav = columnVec(gd_regular_cav);
        end
        
        fx = 1/n* sum_f_loss_cvx + arg.C* sum_f_regular_cvx + dot( 1/n* gd_loss_cav_2 + arg.C* gd_regular_cav,beta);
        if nargout>=2
            gd =  1/n* gd_loss_cvx_2 +  arg.C* gd_regular_cvx +   1/n* gd_loss_cav_2 +arg.C* gd_regular_cav;
        end
        
        %%%%
        %           fwritef(1,'beta  (inner)',beta','','err_v',err_v','',  'err_k_v', err_k_v','');
        %           fwritef(1,'gd_loss_cvx',gd_loss_cvx','', 'gd_loss_cvx_2',gd_loss_cvx_2','');
        %           fwritef(1,'gd_loss_cav',gd_loss_cav','', 'gd_loss_cav_2',gd_loss_cav_2','');
        %           fwritef(1,'gd_regular_cvx',gd_regular_cvx','','gd_regular_cav',gd_regular_cav','');
        %           F=@(beta) sum(loss_cvx(y - X*beta)) + arg.C* sum(regular_cvx(beta))...
        %               + dot(gd_loss_cav_2+arg.C* gd_regular_cav,beta);
        %
        %           arg_dev.pre = 1.0E-12;
        %           gd_diff = derivative(F,beta,arg_dev);
        %           fwritef(1,'gd_diff',gd_diff','');
        %%%%
    end % end function of fun


    function [fx,gd] = fun_l1(beta)
        % objective function and gradient of the subproblem of CCCP with l1 or adaptive-l1
        % regularizer
        %    obj(beta):= loss_cvx(beta) +   <grad L_cav(beta_k),beta>
        %  with        
        %       L_cav(beta) =  loss_cav(beta) 
        
        % initialization        
        gd_loss_cvx_2 = zeros(p,1);
        gd_loss_cav_2 = zeros(p,1);        
        sum_f_loss_cvx = 0;  
        % calulate errors
        err_v = y - X*beta  ;
        err_k_v = y - X*beta_k  ;
        
        % calculate function values and gradient
        if ~isempty_loss_cvx
            [f_loss_cvx, gd_loss_cvx]= loss_cvx(err_v);
            sum_f_loss_cvx  = sum(f_loss_cvx);            
            gd_loss_cvx = columnVec(gd_loss_cvx);
            gd_loss_cvx_2 = -1* sum(X_tran*spdiags(gd_loss_cvx,0,n,n),2);
        end
        if ~isempty_loss_cav
            [~, gd_loss_cav]= loss_cav(err_k_v);            
            gd_loss_cav = columnVec(gd_loss_cav);
            gd_loss_cav_2 = -1* sum(X_tran*spdiags(gd_loss_cav,0,n,n),2);
        end
        
        fx = 1/n* sum_f_loss_cvx + 1/n*dot(gd_loss_cav_2,beta);
        if nargout>=2
            gd =  1/n* gd_loss_cvx_2 + 1/n* gd_loss_cav_2 ;
        end
    end % end function of fun_l1
end