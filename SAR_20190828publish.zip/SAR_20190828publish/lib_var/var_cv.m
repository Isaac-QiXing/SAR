function par_opt = var_cv(trainFile,lossFun,regularizer,par_alg,varargin)
% cross validation for variable selection
%   par_alg: algorithm parameter, a struct with the following fields
%       .search_rho: 1 or 0 indicating whether to search rho
%       .search_gamma: 1 or 0 indicating whether to search gamma (parameter of the exp-square
%       loss)
%       .search_lambda: 1 or 0 indicting whether to search lambda (regularization parameter)
%       .alg: function handle indicating the  algorithm for crossValidate() function,
%           refer to the Input parameters of crossValidate() for detail;
%   varargin{1}: an optional parameter, a struct indicating the searching values of rho, gamma
%      and lambda  and other cross-validation parameters, a struct with the following fields
%       .k:  a positive integer,  k>=2, indicating the number of folds for k-folds
%          cross-validation, defaut value 3;
%       .rho: a vector consisting of the searching values of rho, effective if
%       par_alg.search_rho==1
%       .gamma: a vector consisting of the searching values of gamma,  effective if
%       par_alg.search_gamma==1
%       .lambda: a vector consisting of the searching values of lambda,  effective if
%       par_alg.search_lambda==1
%       .verbose: 0, or 1, or 2, 3, indicating whether to print detailed
%          iterated information
%  Versions
%   * 2019.5.7
%       ** add optional input parameter par_search
%   * 2019.4.5
%       ** add parameters for searching rho
%   * 2019.2.1 16:03
%       * add parameter par_alg.search_rho for  indicating whether to searching rho
%           (parameter of spatial weight matrix W)
%   * 1st version. 2019.1.31
%

% 0. set prameters
debug_on = 0;
flag_have_a_try = 0;

par_search0 = [];
if nargin>=5
    par_search0 = varargin{1};
end

% set fold_k
fold_k = 3; % default value of the number of folds for k-fold cross validation
if ~isempty(par_search0) && isfield(par_search0,'k') && ~isempty(par_search0.k)
    fold_k = par_search0.k;
end

par_search0 = completeArg(par_search0, {'verbose'},{0});

flag_search_rho = isfield(par_alg,'search_rho') && par_alg.search_rho;
flag_search_gamma = isfield(par_alg,'search_gamma') && par_alg.search_gamma;
flag_search_lambda = isfield(par_alg,'search_lambda') && par_alg.search_lambda;
% % % if  flag_search_rho
% % %     alg = @var_predict_spa;
% % % else
% % %     alg = @var_predict;
% % % end
if isfield(par_alg,'alg') && ~isempty(par_alg.alg)    
    alg = par_alg.alg;
else
    alg = @var_predict;
end

d = load(trainFile,'y');
n_case = length(d.y);
lambda = log(n_case)/n_case;

if flag_have_a_try
    max_sample_cv = 100;
else
    max_sample_cv = n_case;
end

% 0.2 set par_search
par_search = [];
if  strcmpi( lossFun,'exp-square') && flag_search_gamma
    if flag_have_a_try
        par_search.gamma = [   2^3  ];
    else
        par_search.gamma = [  2^(0)   2^3  2^5];
    end
    % else     the other loss function has no parameter for cv
end


if  strcmpi(regularizer,'SCAD') && flag_search_lambda
    par_search.lambda = [  2^(-5)  2^(-3)  2^0 ]*lambda;
elseif   ~strcmpi(regularizer,'null') && flag_search_lambda
    % specified other regularizer, such as 'l1' or 'adpative-l1', etc.
    par_search.lambda = [  2^(-5)  2^(-3)  2^0 2^2]*lambda;
    % else null regularizer or user has specified do not search values of lambda
end

if flag_have_a_try && ~strcmpi(regularizer,'null') && flag_search_lambda
    par_search.lambda = [   2^(-3)  2^0  ]*lambda;
end

if flag_search_rho
    if flag_have_a_try
        par_search.rho = [ 0.4  0.6];
    else
        par_search.rho = [0.1 0.2 0.4 0.45 0.5 0.6 0.8];
    end
end


% 1. cross validation
% set par_search
par_opt = [];
if isempty(par_search)
    return
end
par_search2 = completeArg( par_search0,{'rho','gamma','lambda'},par_search);

% remove empty fields
field_c = fieldnames(par_search2);
for ii=1:length(field_c)
    field = field_c{ii};
    if isempty(par_search2.(field))
        par_search2 = rmfield(par_search2,field);
    end
end

par_alg.adaptive_regularizer = 0;

if debug_on
    fwritef(1,'par_search2',par_search2,'');
end

[~,par_opt]= crossValidate(alg,trainFile, par_alg, par_search2,...
    'k',fold_k, 'n',max_sample_cv, 'bestResult',@bestResult_var,'verbose',par_search0.verbose);

end

