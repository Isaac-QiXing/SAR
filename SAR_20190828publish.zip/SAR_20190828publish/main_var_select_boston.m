% main_var_select_boston
% versions
%   * 2019.8.13 by Xijun Liang 
%%%%     ** cross validation algorithm:  
% % %       par_alg2.alg = @var_predict_spa  -->      @var_predict (default value)
%     ** set initial solution as zero vector;    
%
%   * 2019.6.10  by Yanji Zhu
%   * 2019.4.30 Yanji Zhu
%   * First version.  2019.2.1 20:36

clc
clear

flag_have_a_try = 0;  % 1 or 0, 
%   1:   just have a try to see whether the code run well
%   0:  formal running 

% file_cv = 'result_cv_20190130T104810_396767.mat';

time_str = timeStamp();
dataPath ='.\result\';
%dataFile = '.\data\boston_distanceW.mat';
dataFile = '.\data\data_boston.mat' ;
dataset = 'boston';

resultFile = [dataPath 'result_var_' dataset '_' time_str '.mat'];
cvFile = [dataPath 'result_cv_' dataset '_' datestr(now,29) '.mat'];

if ~exist(dataPath,'dir')
    mkdir(dataPath);
end

if flag_have_a_try
    max_ite_CCCP_batch = 500;
    verbose = 3; %1;    
    n_parModel0 = 1; % 1;
    n_repeat = 1;    
    flag_cv = 0;  % whether to operate cross-validation
else
    max_ite_CCCP_batch = 500;
    verbose =  0; % 1;
    n_repeat = 1 ;
    flag_cv = 1;  %0; %
end

[thresh_nnz_beta] = problemArg('thresh_nnz_beta');
%thresh_nnz_beta = 0.2;

% 1.1 generate model parameter
loss_c = {'exp-square','square','lad'};
regularizer_c = {'l1', 'adaptive-l1', 'null'};
n_parModel =  length(loss_c)*length(regularizer_c);


parModel_c = cell(1,n_parModel);
i_model = 1;
for i_loss = 1:length(loss_c)
    for i_reg = 1:length(regularizer_c)
        parModel.loss = loss_c{i_loss};
        parModel.regularizer = regularizer_c{i_reg};
        parModel.a=  3.7; % 2.0
        parModel_c{i_model} = parModel;
        i_model = i_model + 1;
    end    
end
 
% 1.2 algorithm parameter 
d = load(dataFile, 'X',  'y','y_reg','W' );

par_alg.TolFun = 1.0E-5; %1.0E-6;
par_alg.TolX = 1.0E-5; % 1.0E-6;
par_alg.verbose  = verbose;
par_alg.maxIter = max_ite_CCCP_batch;
% % % par_alg.adaptive_regularizer = 1;
par_alg.search_lambda = 1; %1;
par_alg.search_rho = 0; %1; % search rho for cross validation
 par_alg.x0 = zeros(size(d.X,2),1);

%noiseW_mode = {'null','sparse' ,'sparse' , 'sparse' ,'dense' , 'dense' ,'dense' ,'dense'};
%noiseW_ratioRow = [0,ones(1,5),0.1*ones(1,2)];  %noiseW_ratioRow = [0,ones(1,5),0.1,0.1];
%noiseW_ratioColumn = [0,0.3,0.5,0.8,0.5,1,1,2];
noiseW_mode = {'null','sparse' ,  'dense'};
noiseW_ratioRow = [0,   1,       0.1];   
noiseW_ratioColumn = [0 0.5,     1.0];

% 3 variable selection
n_parModel = length(parModel_c);
if flag_have_a_try
    n_parModel = n_parModel0;
end
if flag_have_a_try
    n_test_case = 1;
else
    n_test_case = length(noiseW_mode);
end

% 3.0 initialize the accuracy measures
zeros3 = zeros(n_test_case,n_parModel,n_repeat);
sol_c = cell(n_test_case,n_parModel,n_repeat);
par_opt_c = cell(n_test_case,n_parModel,n_repeat);

acc.TP = zeros3;
acc.FP = zeros3;
acc.TN= zeros3;
acc.FN= zeros3;
acc.resNorm = zeros3;
acc.MSE = zeros3;
acc.sol_1= zeros3;
acc.sol_2= zeros3;
acc.sol_3= zeros3;
acc.time  = zeros3; % elapsed time


if ~flag_cv
    cv = load(cvFile,'par_opt_c');
end



noiseW_arg.W = d.W;


noiseW = cell(1,n_test_case);
  
BIC = zeros(n_test_case,n_parModel);
rho_min_m = zeros(n_test_case,n_parModel);
dev_m = zeros(n_test_case,n_parModel);
for i_case = 1 :n_test_case 
% for i_case = 1 :1     
    % Generate Noised W
    noiseW_arg.mode = noiseW_mode{i_case};
    noiseW_arg.ratioRow = noiseW_ratioRow(i_case);
    noiseW_arg.ratioColumn = noiseW_ratioColumn(i_case);
    [~,noiseW{i_case}] = getW(noiseW_arg);

    for i_model =  1:n_parModel %1%
        fprintf(1,'(i_case,i_model): (%d,   %d)/(%d,  %d)\n',...
            i_case,i_model,n_test_case,n_parModel);
        
        % 3.1 cross validation        
        parModel = parModel_c{i_model};        
        if flag_cv            
            par_alg2 = completeArg(par_alg,fieldnames(parModel),parModel);
            par_alg2.search_gamma = 0;
            % the parameter gamma (of the Exponential-square loss) is calculated manually
            par_alg2.search_rho = 0;
            % the parameter rho is updated iteratively            
            par_alg2.alg = @var_predict_spa;            
            n_sample = length(d.y); 
            lambda = log(n_sample)/n_sample;
            %par_search.lambda = [ 2^(-6) 2^(-4)  2^(-1)  ]*lambda;    % 2^(-9)
            par_search.lambda = [ 2^(-9) 2^(-5)  2^(-2)  ]*lambda;    % 2^(-9)
            par_search.k = 3; % k-fold cross validation 
            par_opt = var_cv(dataFile,parModel.loss,parModel.regularizer,par_alg2,par_search);
            par_opt_c{i_case,i_model} = par_opt;
            save(cvFile,'par_opt_c');
        else
            par_opt = cv.par_opt_c{i_case,i_model};
        end
        % 3.1.2 put out par_opt.lambda
        if isfield(par_opt,'lambda') && ~isempty(par_opt.lambda)
            fprintf(1,'  par_opt.lambda: %e\n',par_opt.lambda);
        end
        
        % 3.2 variable  selection
        % 3.2.1 initialization and assign parameters
        
        par_opt2 = completeArg(par_opt,fieldnames(parModel),parModel);
% % %         par_opt2.adaptive_regularizer = par_alg.adaptive_regularizer;
        par_opt2.W = noiseW{i_case};
        
        acc_t = struct('MSE',cell(1,n_repeat),'TP',[],'FP',[],'TN',[],'FN',[]);
        sol0_c = cell(1,n_repeat);
        resNorm_v = zeros(1,n_repeat);
        time_v = zeros(1,n_repeat);   
        
 
        fprintf(1,'=');
        
        y_reg = noiseW{i_case}*d.y;
         
        % 3.2.2 variable selection
        tic
        [sol,rho_min,dev,iteInf] = var_spa_select(d.X, d.y, y_reg, par_opt2,par_alg);
        t = toc;
        rho_min_m(i_case,i_model) = rho_min;
        if ~isempty(dev)
            dev_m(i_case,i_model) = dev;
        end
        resNorm_v(n_repeat) = iteInf.resNorm;
        BIC(i_case,i_model) = iteInf.BIC;
        sol0_c{n_repeat} = sol;
        time_v(n_repeat) = t;
        
        % 3.2.4 assign results
        %  (1) assign acc
        
        acc.resNorm(i_case,i_model,:) = resNorm_v;
        acc.time(i_case,i_model,:) = time_v;
        acc.BIC = BIC;
        acc.dev = dev_m;
        acc.rho_min  =rho_min_m; 
        %   (2) assign sol_c
        sol_c(i_case,i_model,:) = sol0_c;
        for iii_repeat=1:n_repeat
            sol_i = sol0_c{iii_repeat};
            acc.sol_1(i_case,i_model,iii_repeat) = sol_i(1);
            acc.sol_2(i_case,i_model,iii_repeat) = sol_i(2);
            acc.sol_3(i_case,i_model,iii_repeat) = sol_i(3);
        end
        fprintf(1,'\n');
    %    save(resultFile,'acc','sol_c' );
    end
    % put out the main result for presentation (not that n_prepeat ==1)
            % solutions 
    sol_m = cell2mat(sol_c(i_case,:,1));
            % append the claculated rho, sigma^2, and BIC values
    A = [rho_min_m(i_case,:)
        dev_m(i_case,:)
        BIC(i_case,:)];
    
    acc.sol_present{i_case} = [sol_m
                                A ];
    save(resultFile,'acc','sol_c' );                            
end

 
