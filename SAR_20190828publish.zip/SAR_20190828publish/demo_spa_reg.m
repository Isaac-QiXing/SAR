% demo of spatial auto-regression
clc
clear

% 0. generate (or read ) data : X, y, W (spatial weighting matrix)

%========== replace the following data of X, y and W with your own data ==
%     y is the vector of the observed values, W is the weighting matrix
%     X is the matrix, each column consisting of the values of a independent variable
n_feature = 3;
n_sample  = 200;
% generate X
X = rand(n_sample,n_feature);
beta = randn(n_feature,1);
epsilon_v  = randn(n_sample,1); % noise
rho = 0.6;
% generate weighting matrix W
W = sprand(n_sample,n_sample,0.05);
W = (W+W')*0.5;
W = diag(1./sum(W,2))*W;
W = full(W);
% generate y
y = linsolve(eye(n_sample)-rho*W,   X*beta + epsilon_v); % y - rho*W*y = X* beta + epsilon_v
% ============================ end of data setting ================================

% set y_reg
y_reg = W* y ;    % please provide y_reg = W* y
 
 % 1.1  model parameter
parModel.loss =  'exp-square'; %'square'; 
    % 'square': square loss  
    % 'exp-square': exponential squared loss 
parModel.regularizer =  'null'; % no regularization term
parModel.a=  3.7;  
 parModel.W = W;

% 1.2 algorithm parameter

par_alg.TolFun = 1.0E-5;
par_alg.TolX = 1.0E-5;
par_alg.verbose  = 1;
par_alg.maxIter = 200;
par_alg.adaptive_regularizer = 0;
par_alg.search_lambda = 0; %1;
par_alg.search_rho = 0; %1; % search rho for cross validation

%  2  spatial auto-regression
[ sol,rho_solve,dev,iteInf] = var_spa_select(X, y, y_reg,parModel,par_alg);
err_reg = norm(y - rho_solve*W*y - X* sol);
fprintf(1,'the calculated value of rho: %.4f\n',rho_solve);
fprintf(1,'spatial regression error: %.4f\n', err_reg);
if ~isempty(iteInf.BIC)
    fprintf(1,'BIC: %.4f\n',iteInf.BIC);
end
%  err_true = norm(y - rho*W*y - X* beta)

